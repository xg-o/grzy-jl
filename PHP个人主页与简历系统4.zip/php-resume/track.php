<?php
/**
 * 访问信息上报接口（由 assets/pref.js 调用）
 * 接受 POST JSON 或 sendBeacon 表单
 */
require_once __DIR__ . '/includes/app.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!is_installed()) {
    echo json_encode(array('ok' => 0));
    exit;
}

// 简单限流：同一 IP 3 秒内只记一次
$ip = client_ip();
$key = 'track_' . md5($ip);
$last = isset($_SESSION[$key]) ? (int)$_SESSION[$key] : 0;
if (time() - $last < 3) {
    echo json_encode(array('ok' => 2, 'msg' => 'throttled'));
    exit;
}
$_SESSION[$key] = time();

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    // sendBeacon 的文本/plain 或表单
    if (!empty($_POST)) {
        $data = $_POST;
    } else {
        $tmp = array();
        parse_str($raw, $tmp);
        $data = $tmp;
    }
}

// 轻量人机判断：必须有 UA
if (empty($_SERVER['HTTP_USER_AGENT'])) {
    echo json_encode(array('ok' => 0));
    exit;
}

$ok = track_record($data);
echo json_encode(array('ok' => $ok ? 1 : 0));
