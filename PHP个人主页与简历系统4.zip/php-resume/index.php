<?php
/**
 * 前台：个人主页
 * 支持后台预览参数：?preview_tpl=home_dark（仅登录后台时生效）
 * 支持语言参数：?lang=en
 */
require_once __DIR__ . '/includes/app.php';

if (!is_installed()) {
    redirect('install.php');
}

// 语言切换（URL 参数优先，同时写入 Cookie）
if (!empty($_GET['lang']) && isset(lang_list()[$_GET['lang']])) {
    set_lang($_GET['lang']);
}

$GLOBALS['__page'] = 'home';

$profile = get_data('profile', default_profile());
$settings = get_data('settings', default_settings());

$tpl = valid_template($settings['home_template'], 'home');
if (is_admin() && !empty($_GET['preview_tpl'])) {
    $tpl = valid_template($_GET['preview_tpl'], 'home');
    // 预览模式（后台缩略图 iframe）：不输出右上角偏好控件
    $GLOBALS['__preview'] = true;
}
$file = template_path($tpl);
if (!$file) {
    exit('模板文件不存在：' . e($tpl));
}

require $file;
