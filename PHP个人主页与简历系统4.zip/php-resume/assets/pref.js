/**
 * 右上角偏好控件：显示模式 / 主题面板 / 自定义主色 / 语言
 * 附带访客信息采集（设备、屏幕、网络、电量等）
 */
(function () {
    var P = window.PR_PREF || {};
    var root = document.documentElement;
    window.__prefReady = true;

    var ICONS = {
        sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
        moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
        auto: '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8"/><path d="M12 8.5v4.5l3 1.8"/>'
    };

    function setCookie(n, v) {
        document.cookie = n + '=' + encodeURIComponent(v) + ';path=/;max-age=' + (60 * 60 * 24 * 365) + ';SameSite=Lax';
    }
    function delCookie(n) {
        document.cookie = n + '=;path=/;max-age=0;SameSite=Lax';
    }
    function getCookie(n) {
        var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
        return m ? decodeURIComponent(m[1]) : '';
    }

    /* ---------- 显示模式 ---------- */
    function applyMode(mode, persist) {
        root.classList.remove('dark', 'light', 'auto-mode');
        if (mode === 'dark') root.classList.add('dark');
        else if (mode === 'light') root.classList.add('light');
        else root.classList.add('auto-mode');
        if (persist) setCookie('pr_mode', mode);
        var btn = document.querySelector('[data-panel-btn="mode"]');
        if (btn) {
            var svg = btn.querySelector('svg');
            if (svg) svg.innerHTML = mode === 'dark' ? ICONS.moon : (mode === 'light' ? ICONS.sun : ICONS.auto);
        }
        document.querySelectorAll('[data-set-mode]').forEach(function (b) {
            b.classList.toggle('active', b.getAttribute('data-set-mode') === mode);
        });
    }
    applyMode(getCookie('pr_mode') || P.mode || 'auto', false);

    /* ---------- 主题面板 ---------- */
    function applyPanel(key, persist) {
        root.setAttribute('data-panel', key);
        if (persist) {
            setCookie('pr_panel', key);
            delCookie('pr_theme'); // 换面板时清掉自定义主色
            root.style.removeProperty('--primary');
        }
        document.querySelectorAll('[data-set-panel]').forEach(function (b) {
            b.classList.toggle('active', b.getAttribute('data-set-panel') === key);
        });
    }
    applyPanel(getCookie('pr_panel') || P.panel || 'azure', false);

    /* ---------- 自定义主色 ---------- */
    function applyColor(c, persist) {
        if (c) {
            root.style.setProperty('--primary', c);
            if (persist) setCookie('pr_theme', c);
        } else {
            root.style.removeProperty('--primary');
            if (persist) delCookie('pr_theme');
        }
        document.querySelectorAll('[data-set-color]').forEach(function (b) {
            b.classList.toggle('active', !!c && (b.getAttribute('data-set-color') || '').toLowerCase() === c.toLowerCase());
        });
    }
    applyColor(getCookie('pr_theme') || P.color || '', false);

    /* ---------- 语言 ---------- */
    document.querySelectorAll('[data-set-lang]').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-set-lang') === (P.lang || 'zh'));
    });

    /* ---------- 面板开合 ---------- */
    var pref = document.getElementById('pref');

    /* ---------- 面板搜索 ---------- */
    (function () {
        var input = document.getElementById('pp-search');
        if (!input) return;
        var items = document.querySelectorAll('.pp-panel[data-set-panel]');
        var groups = document.querySelectorAll('[data-group-block]');
        var empty = document.getElementById('pp-empty');
        input.addEventListener('input', function () {
            var q = (input.value || '').toLowerCase().trim();
            items.forEach(function (b) {
                var hay = (b.getAttribute('data-search') || '') + ' ' + (b.textContent || '').toLowerCase();
                b.style.display = (!q || hay.indexOf(q) !== -1) ? '' : 'none';
            });
            groups.forEach(function (g) {
                var vis = g.querySelectorAll('.pp-panel[data-set-panel]').length;
                var any = false;
                g.querySelectorAll('.pp-panel[data-set-panel]').forEach(function (b) { if (b.style.display !== 'none') any = true; });
                g.style.display = (vis > 0 && any) ? '' : 'none';
            });
            var shown = 0;
            items.forEach(function (b) { if (b.style.display !== 'none') shown++; });
            if (empty) empty.style.display = (q && shown === 0) ? 'block' : 'none';
        });
        // 在输入框里回车不触发表单
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
    })();

    if (pref) {
        pref.querySelectorAll('.pref-btn').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                var name = btn.getAttribute('data-panel-btn');
                var willOpen = false;
                pref.querySelectorAll('.pref-panel').forEach(function (p) {
                    var open = p.getAttribute('data-for') === name && !p.classList.contains('open');
                    p.classList.toggle('open', open);
                    if (open) willOpen = true;
                });
                pref.querySelectorAll('.pref-btn').forEach(function (b) {
                    b.classList.toggle('on', b === btn && willOpen);
                });
                if (willOpen && name === 'theme') {
                    var s = document.getElementById('pp-search');
                    if (s) setTimeout(function () { s.focus(); }, 30);
                }
            });
        });
        pref.querySelectorAll('[data-set-mode]').forEach(function (b) {
            b.addEventListener('click', function () { applyMode(b.getAttribute('data-set-mode'), true); });
        });
        pref.querySelectorAll('[data-set-panel]').forEach(function (b) {
            b.addEventListener('click', function () { applyPanel(b.getAttribute('data-set-panel'), true); });
        });
        pref.querySelectorAll('[data-set-color]').forEach(function (b) {
            b.addEventListener('click', function () { applyColor(b.getAttribute('data-set-color'), true); });
        });
        pref.querySelectorAll('[data-reset-color]').forEach(function (b) {
            b.addEventListener('click', function () { applyColor('', true); });
        });
        pref.querySelectorAll('[data-set-lang]').forEach(function (b) {
            b.addEventListener('click', function () {
                setCookie('pr_lang', b.getAttribute('data-set-lang'));
                location.reload();
            });
        });
        pref.addEventListener('click', function (e) { e.stopPropagation(); });
        document.addEventListener('click', closeAll);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeAll(); });
    }
    function closeAll() {
        if (!pref) return;
        pref.querySelectorAll('.pref-panel').forEach(function (p) { p.classList.remove('open'); });
        pref.querySelectorAll('.pref-btn').forEach(function (b) { b.classList.remove('on'); });
    }

    /* ---------- 访客信息采集 ---------- */
    function send(d) {
        var url = P.endpoint || 'track.php';
        try {
            if (navigator.sendBeacon) {
                var fd = new FormData();
                for (var k in d) { if (d[k] !== '' && d[k] !== null && d[k] !== undefined) fd.append(k, d[k]); }
                if (navigator.sendBeacon(url, fd)) return;
            }
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(d),
                keepalive: true
            }).catch(function () { });
        } catch (e) { }
    }

    function collect() {
        var d = {
            page: location.pathname,
            ref: document.referrer || '',
            lang: navigator.language || '',
            tz: '',
            sw: screen.width,
            sh: screen.height,
            dpr: window.devicePixelRatio || 1,
            cores: navigator.hardwareConcurrency || '',
            mem: navigator.deviceMemory || '',
            online: navigator.onLine ? 1 : 0,
            dark: 0
        };
        try { d.tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { }
        try { d.dark = window.matchMedia('(prefers-color-scheme: dark)').matches ? 1 : 0; } catch (e) { }

        var c = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (c) {
            d.net = c.effectiveType || c.type || '';
            d.dl = c.downlink || '';
            d.rtt = c.rtt || '';
        }
        var finish = function () { send(d); };
        if (navigator.getBattery) {
            navigator.getBattery().then(function (b) {
                d.bat = b.level;
                d.chg = b.charging ? 1 : 0;
                finish();
            }).catch(finish);
        } else if (navigator.battery) {
            d.bat = navigator.battery.level;
            d.chg = navigator.battery.charging ? 1 : 0;
            finish();
        } else {
            finish();
        }
    }

    if (P.track === 1) {
        if (document.readyState === 'complete') setTimeout(collect, 400);
        else window.addEventListener('load', function () { setTimeout(collect, 400); });
    }
})();
