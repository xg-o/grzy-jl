/**
 * 后台通用脚本：重复组增删、模板切换显示、表单确认
 */
(function () {
    // 重复组：添加一条
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest('[data-add]');
        if (btn) {
            var group = btn.getAttribute('data-add');
            addRow(group);
        }
        var del = ev.target.closest('[data-del]');
        if (del) {
            var item = del.closest('.rep-item');
            var list = item.parentNode;
            item.remove();
            renumber(list);
        }
    });

    function addRow(group) {
        var tpl = document.getElementById('tpl-' + group);
        var list = document.getElementById('list-' + group);
        if (!tpl || !list) return;
        var i = list.querySelectorAll('.rep-item').length;
        var html = tpl.innerHTML.replace(/__i__/g, i);
        var wrap = document.createElement('div');
        wrap.innerHTML = html;
        var node = wrap.firstElementChild;
        list.appendChild(node);
        renumber(list);
        var first = node.querySelector('input,textarea');
        if (first) first.focus();
        node.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function renumber(list) {
        var items = list.querySelectorAll('.rep-item');
        items.forEach(function (item, idx) {
            var span = item.querySelector('.rep-bar .idx');
            if (span) span.textContent = span.textContent.replace(/#\d+/, '#' + (idx + 1));
        });
        if (items.length === 0) {
            // 保留一个空行，避免用户无从下手
            var btn = list.parentNode.querySelector('[data-add]');
            if (btn) addRow(btn.getAttribute('data-add'));
        }
    }

    // 存储方式切换显示
    var drivers = document.querySelectorAll('input[name="storage_driver"]');
    drivers.forEach(function (r) {
        r.addEventListener('change', function () {
            document.querySelectorAll('[data-driver-box]').forEach(function (box) {
                box.style.display = (box.getAttribute('data-driver-box') === r.value) ? 'block' : 'none';
            });
        });
    });

    // 删除确认
    document.addEventListener('submit', function (ev) {
        var form = ev.target;
        if (form.hasAttribute('data-confirm') && !confirm(form.getAttribute('data-confirm'))) {
            ev.preventDefault();
        }
    });
})();
