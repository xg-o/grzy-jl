<?php
/**
 * 后台登录
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';

if (!is_installed()) {
    redirect('../install.php');
}
if (is_admin()) {
    redirect('index.php');
}
if (!empty($_GET['lang']) && isset(lang_list()[$_GET['lang']])) {
    set_lang($_GET['lang']);
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $user = trim(isset($_POST['user']) ? $_POST['user'] : '');
    $pass = isset($_POST['pass']) ? $_POST['pass'] : '';
    if (verify_admin_login($user, $pass)) {
        session_regenerate_id(true);
        $_SESSION['admin_user'] = $user;
        redirect('index.php');
    } else {
        $error = t('login_failed');
    }
}
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= te('login_title') ?></title>
    <link rel="stylesheet" href="../assets/pref.css">
    <?= theme_head_css() ?>
    <link rel="stylesheet" href="../assets/admin.css">
    <style>
        body { display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .login-box { width: 360px; background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 28px; box-shadow: var(--shadow-lg); }
        .login-box h2 { margin: 0 0 6px; font-size: 20px; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .login-box .sub { text-align: center; color: var(--text-2); font-size: 13px; margin-bottom: 20px; }
        .login-box .f { margin-bottom: 14px; }
        .login-box .btn { width: 100%; justify-content: center; }
        .back-link { text-align: center; margin-top: 14px; font-size: 13px; }
    </style>
</head>
<body>
<div class="login-box">
    <h2><?= icon('key') ?><?= te('login_title') ?></h2>
    <div class="sub"><?= t('login_sub') ?></div>
    <?php if ($error): ?><div class="alert alert-error"><?= icon('shield') ?><span><?= e($error) ?></span></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="f"><label><?= icon('user') ?><?= te('username') ?></label><input type="text" name="user" autofocus required></div>
        <div class="f"><label><?= icon('key') ?><?= te('password') ?></label><input type="password" name="pass" required></div>
        <button class="btn" type="submit"><?= te('login_btn') ?></button>
    </form>
    <div class="back-link"><a href="../index.php"><?= icon('arrow-left') ?><?= te('back_home') ?></a></div>
</div>
<?= theme_assets() ?>
</body>
</html>
