<?php
/**
 * 后台：系统设置（站点信息 / 外观语言 / 修改密码 / 存储方式 / 访问采集 / 数据备份）
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();
csrf_check();

$settings = get_data('settings', default_settings());
$cfg = load_config();
$action = $_POST['action'] ?? '';

/* ---------- 站点设置 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'site') {
    $settings['site_title'] = trim($_POST['site_title'] ?? '');
    $settings['meta_keywords'] = trim($_POST['meta_keywords'] ?? '');
    $settings['meta_description'] = trim($_POST['meta_description'] ?? '');
    $settings['show_resume'] = !empty($_POST['show_resume']) ? 1 : 0;
    $settings['footer_text'] = trim($_POST['footer_text'] ?? '');
    $settings['icp'] = trim($_POST['icp'] ?? '');
    $settings['updated_at'] = now_str();
    save_data('settings', $settings);
    flash(t('save_settings') . ' · OK');
    redirect('settings.php#site');
}

/* ---------- 外观与语言 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'appearance') {
    $lang = $_POST['language'] ?? 'zh';
    $settings['language'] = isset(lang_list()[$lang]) ? $lang : 'zh';
    $mode = $_POST['default_mode'] ?? 'auto';
    $settings['default_mode'] = in_array($mode, array('light', 'dark', 'auto'), true) ? $mode : 'auto';
    $panel = $_POST['theme_panel'] ?? 'azure';
    $settings['theme_panel'] = isset(theme_panels()[$panel]) ? $panel : 'azure';
    $color = trim($_POST['theme_color'] ?? '');
    // 留空 = 跟随面板主色
    $settings['theme_color'] = preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color)
        ? $color : theme_panels()[$settings['theme_panel']]['primary'];
    $settings['updated_at'] = now_str();
    save_data('settings', $settings);
    // 让管理员当前会话立即跟随新默认值
    setcookie('pr_lang', $settings['language'], time() + 86400 * 365, '/', '', false, false);
    setcookie('pr_mode', $settings['default_mode'], time() + 86400 * 365, '/', '', false, false);
    setcookie('pr_panel', $settings['theme_panel'], time() + 86400 * 365, '/', '', false, false);
    // 自定义主色与面板主色一致时，清掉 cookie 让面板生效
    if (strtolower($settings['theme_color']) === strtolower(theme_panels()[$settings['theme_panel']]['primary'])) {
        setcookie('pr_theme', '', time() - 3600, '/', '', false, false);
        unset($_COOKIE['pr_theme']);
    } else {
        setcookie('pr_theme', $settings['theme_color'], time() + 86400 * 365, '/', '', false, false);
        $_COOKIE['pr_theme'] = $settings['theme_color'];
    }
    $_COOKIE['pr_lang'] = $settings['language'];
    $_COOKIE['pr_mode'] = $settings['default_mode'];
    $_COOKIE['pr_panel'] = $settings['theme_panel'];
    unset($GLOBALS['__lang']);
    flash(t('appearance') . ' · OK');
    redirect('settings.php#look');
}

/* ---------- 访问采集 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'tracking') {
    $settings['track_enable'] = !empty($_POST['track_enable']) ? 1 : 0;
    $settings['ip_mask'] = !empty($_POST['ip_mask']) ? 1 : 0;
    $settings['track_keep'] = max(50, min(5000, (int)($_POST['track_keep'] ?? 500)));
    $settings['updated_at'] = now_str();
    save_data('settings', $settings);
    flash(t('visit_tracking') . ' · OK');
    redirect('settings.php#track');
}

/* ---------- 修改管理员密码 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'password') {
    $old = $_POST['old_pass'] ?? '';
    $new = $_POST['new_pass'] ?? '';
    $new2 = $_POST['new_pass2'] ?? '';
    if (!password_verify($old, $cfg['admin']['hash'])) {
        flash(t('old_password') . ' 不正确', 'error');
    } elseif (strlen($new) < 6) {
        flash(t('new_password'), 'error');
    } elseif ($new !== $new2) {
        flash(t('confirm_password') . ' 不一致', 'error');
    } else {
        $cfg['admin']['hash'] = password_hash($new, PASSWORD_DEFAULT);
        save_config($cfg);
        flash('密码已修改，下次登录请使用新密码');
    }
    redirect('settings.php#password');
}

/* ---------- 切换存储方式（含数据迁移） ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'storage') {
    $driver = ($_POST['storage_driver'] ?? 'file') === 'db' ? 'db' : 'file';
    $scfg = array('driver' => $driver);
    $dbcfg = array();
    if ($driver === 'file') {
        $scfg['format'] = isset(FileStore::$formats[$_POST['file_format'] ?? '']) ? $_POST['file_format'] : 'json';
        $scfg['dir'] = trim($_POST['file_dir'] ?? '') ?: DATA_DIR;
    } else {
        $dbdriver = (($_POST['db_driver'] ?? '') === 'sqlite') ? 'sqlite' : 'mysql';
        $dbcfg = array(
            'driver' => $dbdriver,
            'prefix' => preg_replace('/[^A-Za-z0-9_]/', '', trim($_POST['db_prefix'] ?? 'pr_')),
        );
        if ($dbdriver === 'sqlite') {
            $dbcfg['file'] = trim($_POST['sqlite_file'] ?? '') ?: (DATA_DIR . '/resume.db');
        } else {
            $dbcfg['host'] = trim($_POST['db_host'] ?? 'localhost');
            $dbcfg['port'] = (int)($_POST['db_port'] ?? 3306);
            $dbcfg['name'] = trim($_POST['db_name'] ?? '');
            $dbcfg['user'] = trim($_POST['db_user'] ?? '');
            $dbcfg['pass'] = $_POST['db_pass'] ?? '';
        }
    }
    list($ok, $msg) = StorageFactory::test($scfg, $dbcfg);
    if (!$ok) {
        flash('切换失败：' . $msg, 'error');
        redirect('settings.php#storage');
    }
    // 切换前自动备份 → 写新配置 → 写入新存储
    $oldProfile = get_data('profile', default_profile());
    $oldSettings = get_data('settings', default_settings());
    $oldVisits = track_list();
    $oldThemes = get_data(THEME_DATA_KEY, array());
    $oldTpl = get_data(TPL_DATA_KEY, array());
    $bakFile = DATA_DIR . '/backup-' . date('Ymd-His') . '.json';
    @file_put_contents($bakFile, json_encode(array(
        'app'      => 'php-resume',
        'time'     => date('Y-m-d H:i:s'),
        'profile'  => $oldProfile,
        'settings' => $oldSettings,
        'visits'   => $oldVisits,
        'themes'   => $oldThemes,
        'tplmeta'  => $oldTpl,
    ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    $cfg['storage'] = $scfg;
    $cfg['db'] = $dbcfg;
    save_config($cfg);
    storage()->set('profile', $oldProfile);
    storage()->set('settings', $oldSettings);
    if ($oldVisits) {
        storage()->set('visits', $oldVisits);
    }
    if ($oldThemes) {
        storage()->set(THEME_DATA_KEY, $oldThemes);
    }
    if ($oldTpl) {
        storage()->set(TPL_DATA_KEY, $oldTpl);
    }
    flash('存储方式已切换并完成数据迁移：' . $msg);
    redirect('settings.php#storage');
}

/* ---------- 导出备份 ---------- */
if (isset($_GET['export'])) {
    $data = array(
        'app'      => 'php-resume',
        'version'  => APP_VERSION,
        'time'     => date('Y-m-d H:i:s'),
        'profile'  => get_data('profile', default_profile()),
        'settings' => get_data('settings', default_settings()),
        'themes'   => get_data(THEME_DATA_KEY, array()),
        'tplmeta'  => get_data(TPL_DATA_KEY, array()),
    );
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="resume-backup-' . date('Ymd-His') . '.json"');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/* ---------- 导入备份 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'import') {
    $raw = '';
    if (!empty($_FILES['backup']['tmp_name']) && is_uploaded_file($_FILES['backup']['tmp_name'])) {
        $raw = file_get_contents($_FILES['backup']['tmp_name']);
    } elseif (!empty($_POST['backup_text'])) {
        $raw = $_POST['backup_text'];
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['profile'])) {
        flash('导入失败：文件内容不是有效的备份 JSON', 'error');
    } else {
        $profile = array_merge(default_profile(), (array)$data['profile']);
        $settings = array_merge(default_settings(), isset($data['settings']) ? (array)$data['settings'] : array());
        save_data('profile', $profile);
        save_data('settings', $settings);
        if (isset($data['themes']) && is_array($data['themes'])) {
            save_data(THEME_DATA_KEY, $data['themes']);
        }
        if (isset($data['tplmeta']) && is_array($data['tplmeta'])) {
            // 模板元数据：仅恢复 custom（文件不存在时会自动忽略）
            $tpl = $data['tplmeta'];
            $cur = get_data(TPL_DATA_KEY, array('custom' => array(), 'hidden' => array()));
            $cur['custom'] = isset($tpl['custom']) && is_array($tpl['custom']) ? $tpl['custom'] : array();
            if (isset($tpl['hidden']) && is_array($tpl['hidden'])) {
                $cur['hidden'] = $tpl['hidden'];
            }
            save_data(TPL_DATA_KEY, $cur);
        }
        flash('数据已导入');
    }
    redirect('settings.php#backup');
}

admin_header(t('settings'), 'settings');
$store = storage();
?>
<div class="card" id="look">
    <h3><?= icon('palette') ?><?= te('appearance') ?>
        <a class="btn btn-sm btn-line" style="margin-left:auto" href="themes.php"><?= icon('sliders') ?><?= te('theme_manage') ?></a>
    </h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="appearance">
        <input type="hidden" name="theme_panel" id="panel-input" value="<?= e($settings['theme_panel'] ?? 'azure') ?>">
        <div class="grid">
            <div class="f f-1"><label><?= icon('globe') ?><?= te('default_lang') ?></label>
                <select name="language">
                    <?php foreach (lang_list() as $code => $name): ?>
                        <option value="<?= e($code) ?>" <?= ($settings['language'] ?? 'zh') === $code ? 'selected' : '' ?>><?= e($name) ?></option>
                    <?php endforeach; ?>
                </select></div>
            <div class="f f-1"><label><?= icon('moon') ?><?= te('default_mode') ?></label>
                <select name="default_mode">
                    <option value="light" <?= ($settings['default_mode'] ?? 'auto') === 'light' ? 'selected' : '' ?>><?= te('mode_light') ?></option>
                    <option value="dark" <?= ($settings['default_mode'] ?? 'auto') === 'dark' ? 'selected' : '' ?>><?= te('mode_dark') ?></option>
                    <option value="auto" <?= ($settings['default_mode'] ?? 'auto') === 'auto' ? 'selected' : '' ?>><?= te('mode_auto') ?></option>
                </select></div>
            <div class="f f-1"><label><?= icon('palette') ?><?= te('theme_color') ?></label>
                <input type="text" name="theme_color" id="color-input"
                       value="<?= e($settings['theme_color'] ?? '#2563eb') ?>" placeholder="#2563eb"></div>
        </div>

        <div class="pp-title pp-title-2" style="padding-left:0;border-top:0;margin-top:14px"><?= te('panel_default') ?></div>
        <div class="pp-search" style="max-width:260px;margin:2px 0 8px">
            <?= icon('search') ?>
            <input type="text" id="set-panel-search" placeholder="<?= te('panel_search_ph') ?>" autocomplete="off">
        </div>
        <div class="panel-picker">
            <?php $curPanel = $settings['theme_panel'] ?? 'azure'; ?>
            <?php foreach (theme_panel_groups() as $gk => $g): ?>
                <div class="pp-group">
                    <div class="pp-gname"><?= e($g[current_lang()] ?? $g['zh']) ?></div>
                    <div class="pp-gitems">
                        <?php foreach ($g['items'] as $key):
                            $p = theme_panels()[$key]; ?>
                            <button type="button" class="pp-panel <?= $key === $curPanel ? 'active' : '' ?>"
                                    data-panel-pick="<?= e($key) ?>" data-panel-color="<?= e($p['primary']) ?>"
                                    data-search="<?= e(strtolower(($p[current_lang()] ?? $p['zh']) . ' ' . $key . ' ' . $p['en'] . ' ' . $p['zh'])) ?>">
                                <i style="background:linear-gradient(135deg,<?= e($p['primary']) ?>,<?= e($p['accent']) ?>)"></i>
                                <span><?= e($p[current_lang()] ?? $p['zh']) ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="pp-empty" id="set-no-match" style="display:none"><?= te('panel_no_match') ?></div>
        </div>

        <div class="pp-title pp-title-2" style="padding-left:0"><?= te('pref_theme') ?></div>
        <div class="pp-colors" style="grid-template-columns:repeat(8,1fr);max-width:340px;margin:2px 0 4px">
            <?php foreach (theme_swatches() as $hex => $lb): ?>
                <button type="button" class="pp-color <?= ($settings['theme_color'] ?? '') === $hex ? 'active' : '' ?>"
                        style="background:<?= e($hex) ?>" title="<?= e($lb[current_lang()] ?? $lb['zh']) ?>"
                        onclick="document.getElementById('color-input').value='<?= e($hex) ?>'"><span></span></button>
            <?php endforeach; ?>
        </div>
        <div class="pp-reset" style="padding-left:0">
            <button type="button" class="pp-linkbtn" onclick="var p=document.querySelector('[data-panel-pick].active');document.getElementById('color-input').value=p?p.getAttribute('data-panel-color'):'#2563eb';"><?= icon('refresh') ?><?= te('pref_reset') ?></button>
        </div>
        <p class="muted" style="margin-top:6px"><?= te('panel_hint') ?></p>
        <p class="muted" style="margin-top:2px">访客可在页面右上角自行切换语言、主题面板、主色与明暗模式，这里设置的是默认值。</p>
        <div style="margin-top:10px"><button class="btn" type="submit"><?= icon('check') ?><?= te('save') ?></button></div>
    </form>
</div>

<div class="card" id="track">
    <h3><?= icon('gauge') ?><?= te('visit_tracking') ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="tracking">
        <label class="checkline" style="margin-bottom:8px">
            <input type="checkbox" name="track_enable" value="1" <?= !empty($settings['track_enable']) ? 'checked' : '' ?>>
            <?= te('track_enable') ?>
        </label>
        <label class="checkline" style="margin-bottom:12px">
            <input type="checkbox" name="ip_mask" value="1" <?= !empty($settings['ip_mask']) ? 'checked' : '' ?>>
            <?= te('ip_mask') ?>
        </label>
        <div class="grid">
            <div class="f f-1"><label><?= te('keep_records') ?></label>
                <input type="number" name="track_keep" value="<?= (int)($settings['track_keep'] ?? 500) ?>" min="50" max="5000"></div>
        </div>
        <p class="muted" style="margin-top:8px"><?= te('track_privacy') ?></p>
        <div style="margin-top:10px">
            <button class="btn" type="submit"><?= icon('check') ?><?= te('save') ?></button>
            <a class="btn btn-line" href="visits.php"><?= icon('chart') ?><?= te('visit_list') ?></a>
        </div>
    </form>
</div>

<div class="card" id="site">
    <h3><?= icon('sliders') ?><?= te('site_settings') ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="site">
        <div class="grid">
            <div class="f f-2"><label><?= te('site_title') ?></label>
                <input type="text" name="site_title" value="<?= e($settings['site_title']) ?>"></div>
            <div class="f f-1"><label>&nbsp;</label>
                <label class="checkline">
                    <input type="checkbox" name="show_resume" value="1" <?= !empty($settings['show_resume']) ? 'checked' : '' ?>>
                    <?= te('show_resume_link') ?>
                </label></div>
            <div class="f f-2"><label><?= te('meta_keywords') ?></label>
                <input type="text" name="meta_keywords" value="<?= e($settings['meta_keywords']) ?>"></div>
            <div class="f f-1"><label>&nbsp;</label></div>
            <div class="f f-3"><label><?= te('meta_description') ?></label>
                <input type="text" name="meta_description" value="<?= e($settings['meta_description']) ?>"></div>
            <div class="f f-2"><label><?= te('footer_text') ?></label>
                <input type="text" name="footer_text" value="<?= e($settings['footer_text']) ?>"></div>
            <div class="f f-1"><label><?= te('icp') ?></label>
                <input type="text" name="icp" value="<?= e($settings['icp']) ?>"></div>
        </div>
        <div style="margin-top:14px"><button class="btn" type="submit"><?= icon('check') ?><?= te('save_settings') ?></button></div>
    </form>
</div>

<div class="card" id="password">
    <h3><?= icon('key') ?><?= te('change_password') ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="password">
        <div class="grid">
            <div class="f f-1"><label><?= te('old_password') ?></label><input type="password" name="old_pass" required></div>
            <div class="f f-1"><label><?= te('new_password') ?></label><input type="password" name="new_pass" required></div>
            <div class="f f-1"><label><?= te('confirm_password') ?></label><input type="password" name="new_pass2" required></div>
        </div>
        <div style="margin-top:14px"><button class="btn" type="submit"><?= icon('check') ?><?= te('change_pwd_btn') ?></button></div>
    </form>
</div>

<div class="card" id="storage">
    <h3><?= icon('database') ?><?= te('storage') ?></h3>
    <div class="alert alert-info"><?= icon('database') ?><span><?= te('storage') ?>：<?= e($store->label()) ?>。切换时会自动把现有数据迁移到新的存储中，无需担心丢失。</span></div>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="storage">
        <label class="radio-card">
            <input type="radio" name="storage_driver" value="file" <?= $cfg['storage']['driver'] === 'file' ? 'checked' : '' ?>>
            <span class="rc-title"><?= icon('folder') ?>文件存储</span>
            <div class="rc-desc">JSON / PHP / TXT 三种文件格式任选</div>
        </label>
        <div class="sub-box" data-driver-box="file" style="display:<?= $cfg['storage']['driver'] === 'file' ? 'block' : 'none' ?>">
            <div class="form-row">
                <div class="f f-1"><label>文件格式</label>
                    <select name="file_format">
                        <?php foreach (FileStore::$formats as $k => $v): ?>
                            <option value="<?= e($k) ?>" <?= ($cfg['storage']['format'] ?? 'json') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div class="f f-2"><label>数据目录</label>
                    <input type="text" name="file_dir" value="<?= e($cfg['storage']['dir'] ?? DATA_DIR) ?>"></div>
            </div>
        </div>
        <label class="radio-card">
            <input type="radio" name="storage_driver" value="db" <?= $cfg['storage']['driver'] === 'db' ? 'checked' : '' ?>>
            <span class="rc-title"><?= icon('database') ?>数据库存储</span>
            <div class="rc-desc">MySQL / MariaDB 或 SQLite</div>
        </label>
        <div class="sub-box" data-driver-box="db" style="display:<?= $cfg['storage']['driver'] === 'db' ? 'block' : 'none' ?>">
            <?php $db = $cfg['db']; ?>
            <div class="form-row">
                <div class="f f-1"><label>类型</label>
                    <select name="db_driver" id="db_driver">
                        <option value="mysql" <?= ($db['driver'] ?? 'mysql') === 'mysql' ? 'selected' : '' ?>>MySQL</option>
                        <option value="sqlite" <?= ($db['driver'] ?? '') === 'sqlite' ? 'selected' : '' ?>>SQLite</option>
                    </select></div>
                <div class="f f-1"><label>表前缀</label><input type="text" name="db_prefix" value="<?= e($db['prefix'] ?? 'pr_') ?>"></div>
            </div>
            <div id="mysql-box" style="display:<?= ($db['driver'] ?? 'mysql') === 'mysql' ? 'block' : 'none' ?>">
                <div class="form-row">
                    <div class="f f-1"><label>主机</label><input type="text" name="db_host" value="<?= e($db['host'] ?? 'localhost') ?>"></div>
                    <div class="f f-1"><label>端口</label><input type="text" name="db_port" value="<?= e($db['port'] ?? 3306) ?>"></div>
                    <div class="f f-1"><label>数据库名</label><input type="text" name="db_name" value="<?= e($db['name'] ?? '') ?>"></div>
                    <div class="f f-1"><label>用户名</label><input type="text" name="db_user" value="<?= e($db['user'] ?? '') ?>"></div>
                    <div class="f f-2"><label>密码</label><input type="password" name="db_pass" placeholder="留空则不修改"></div>
                </div>
            </div>
            <div id="sqlite-box" style="display:<?= ($db['driver'] ?? '') === 'sqlite' ? 'block' : 'none' ?>">
                <div class="f"><label>SQLite 文件路径</label>
                    <input type="text" name="sqlite_file" value="<?= e($db['file'] ?? (DATA_DIR . '/resume.db')) ?>"></div>
            </div>
        </div>
        <div style="margin-top:14px">
            <button class="btn" type="submit"><?= icon('refresh') ?><?= te('switch_storage') ?></button>
        </div>
    </form>
</div>

<div class="card" id="backup">
    <h3><?= icon('download') ?><?= te('data_backup') ?></h3>
    <p class="muted" style="margin-top:0">备份文件为标准 JSON，包含全部资料与设置，可用于迁移到其他站点或还原。</p>
    <p><a class="btn btn-line" href="settings.php?export=1"><?= icon('download') ?><?= te('download_backup') ?></a></p>
    <form method="post" enctype="multipart/form-data" style="margin-top:16px">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="import">
        <div class="f" style="margin-bottom:10px"><label>选择备份文件上传</label>
            <input type="file" name="backup" accept=".json,application/json"></div>
        <div class="f"><label>或直接粘贴备份内容</label>
            <textarea name="backup_text" placeholder='{"profile":{...},"settings":{...}}'></textarea></div>
        <div style="margin-top:10px"><button class="btn btn-gray" type="submit"><?= icon('refresh') ?><?= te('import_data') ?></button></div>
    </form>
</div>

<div class="card">
    <h3><?= icon('shield') ?><?= te('security_tips') ?></h3>
    <ul class="muted" style="padding-left:18px;margin:0">
        <li>安装完成后请删除 <code>install.php</code>。</li>
        <li>若使用 Nginx，请在配置中禁止访问 <code>/config/</code> 与 <code>/data/</code> 目录。</li>
        <li>文件存储若放在 Web 可访问目录，务必确认 <code>data/.htaccess</code> 生效。</li>
        <li>访问记录含 IP 等个人信息，建议开启 IP 脱敏并定期清理。</li>
    </ul>
</div>

<script>
    // 面板搜索
    (function () {
        var si = document.getElementById('set-panel-search');
        if (!si) return;
        var items = document.querySelectorAll('[data-panel-pick]');
        var groups = document.querySelectorAll('.panel-picker .pp-group');
        var none = document.getElementById('set-no-match');
        si.addEventListener('input', function () {
            var q = (si.value || '').toLowerCase().trim();
            items.forEach(function (b) {
                var hay = (b.getAttribute('data-search') || '') + ' ' + (b.textContent || '').toLowerCase();
                b.style.display = (!q || hay.indexOf(q) !== -1) ? '' : 'none';
            });
            groups.forEach(function (g) {
                var any = false;
                g.querySelectorAll('[data-panel-pick]').forEach(function (b) { if (b.style.display !== 'none') any = true; });
                g.style.display = any ? '' : 'none';
            });
            var shown = 0;
            items.forEach(function (b) { if (b.style.display !== 'none') shown++; });
            if (none) none.style.display = (q && shown === 0) ? 'block' : 'none';
        });
    })();
    // 主题面板选择
    (function () {
        var input = document.getElementById('panel-input');
        var color = document.getElementById('color-input');
        if (!input) return;
        document.querySelectorAll('[data-panel-pick]').forEach(function (b) {
            b.addEventListener('click', function () {
                document.querySelectorAll('[data-panel-pick]').forEach(function (x) { x.classList.remove('active'); });
                b.classList.add('active');
                input.value = b.getAttribute('data-panel-pick');
                // 若当前主色等于旧面板主色，则同步为新面板主色
                var cur = (color.value || '').toLowerCase();
                var changed = false;
                document.querySelectorAll('[data-panel-pick]').forEach(function (x) {
                    if (x !== b && cur === (x.getAttribute('data-panel-color') || '').toLowerCase()) changed = true;
                });
                if (changed || cur === '') {
                    color.value = b.getAttribute('data-panel-color');
                }
            });
        });
    })();
    var sel = document.getElementById('db_driver');
    if (sel) {
        sel.addEventListener('change', function () {
            document.getElementById('mysql-box').style.display = sel.value === 'mysql' ? 'block' : 'none';
            document.getElementById('sqlite-box').style.display = sel.value === 'sqlite' ? 'block' : 'none';
        });
    }
</script>
<?php
admin_footer();
