<?php
/**
 * 后台：个人资料编辑（基本信息 + 各区块）
 * 项目区块额外支持从 GitHub / Gitee / GitLab / Gitea 自动导入
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();
csrf_check();

$profile = get_data('profile', default_profile());
$repos = isset($_SESSION['platform_repos']) ? (array)$_SESSION['platform_repos'] : array();
$action = isset($_POST['action']) ? $_POST['action'] : 'save';

/* ---------------- 拉取平台仓库 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'fetch') {
    $sort = (string)($_POST['platform_sort'] ?? 'time_desc');
    if (!isset(platform_sorts()[$sort])) {
        $sort = 'time_desc';
    }
    $limit = (int)($_POST['platform_limit'] ?? 20);
    $limit = max(5, min(100, $limit ?: 20));

    // 收集所有「平台 + 用户名」组合（可多平台拼接）
    $rows = isset($_POST['platforms']) && is_array($_POST['platforms']) ? $_POST['platforms'] : array();
    $queries = array();
    $seenPair = array();
    foreach ($rows as $row) {
        $pf = isset($row['pf']) ? (string)$row['pf'] : '';
        $user = trim((string)($row['user'] ?? ''));
        if ($pf === '' || $user === '') {
            continue;
        }
        if (!isset(platform_list()[$pf])) {
            continue;
        }
        $pair = $pf . '/' . strtolower($user);
        if (isset($seenPair[$pair])) {
            continue;
        }
        $seenPair[$pair] = true;
        $queries[] = array(
            'platform' => $pf,
            'user'     => $user,
            'token'    => trim((string)($row['token'] ?? '')),
            'base'     => trim((string)($row['base'] ?? '')),
        );
    }
    if (empty($queries)) {
        flash(t('import_failed', t('import_need_target')), 'error');
        redirect('profile.php#import');
    }
    list($okCount, $errors, $list) = platform_fetch_multi($queries, $sort, $limit);
    if (empty($list)) {
        unset($_SESSION['platform_repos']);
        $_SESSION['platform_meta'] = array('queries' => $queries, 'sort' => $sort, 'limit' => $limit);
        flash(t('import_failed', $errors ? implode('；', $errors) : t('import_none_repo')), 'error');
        redirect('profile.php#import');
    }
    $_SESSION['platform_repos'] = $list;
    $_SESSION['platform_meta'] = array('queries' => $queries, 'sort' => $sort, 'limit' => $limit);
    $msg = t('import_fetched', count($list)) . '（' . t('import_from_n', $okCount) . ' · ' . platform_sort_name($sort) . '）';
    if ($errors) {
        $msg .= '；' . implode('；', $errors);
    }
    flash($msg, $errors && $okCount === 0 ? 'error' : 'success');
    redirect('profile.php#import');
}

/* ---------------- 导入选中的仓库 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'import_repos') {
    $picks = isset($_POST['pick']) ? (array)$_POST['pick'] : array();
    $mode = (isset($_POST['mode']) && $_POST['mode'] === 'replace') ? 'replace' : 'append';
    if (empty($picks)) {
        flash(t('import_none'), 'error');
        redirect('profile.php#import');
    }
    $items = platform_to_projects($repos, array_keys($picks));
    if ($mode === 'replace') {
        $profile['projects'] = $items;
    } else {
        $profile['projects'] = array_values(array_merge($profile['projects'], $items));
    }
    $profile['updated_at'] = now_str();
    save_data('profile', $profile);
    unset($_SESSION['platform_repos']);
    flash(t('import_done', count($items)));
    redirect('profile.php');
}

/* ---------------- 保存资料 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save') {
    $basic = isset($_POST['basic']) ? (array)$_POST['basic'] : array();
    $basic = trim_deep($basic);

    $up = handle_upload('avatar_file');
    if (is_array($up) && isset($up['error'])) {
        flash($up['error'], 'error');
        redirect('profile.php');
    }
    if (is_array($up) && !empty($up['path'])) {
        $basic['avatar'] = $up['path'];
    } elseif (!empty($_POST['avatar_remove'])) {
        $basic['avatar'] = '';
    } elseif (isset($basic['avatar'])) {
        $basic['avatar'] = trim($basic['avatar']);
    } else {
        $basic['avatar'] = isset($profile['basic']['avatar']) ? $profile['basic']['avatar'] : '';
    }

    $profile['basic'] = array_merge($profile['basic'], $basic);

    foreach (profile_schema() as $group => $meta) {
        $rows = isset($_POST[$group]) ? (array)$_POST[$group] : array();
        $profile[$group] = normalize_rows(trim_deep($rows));
    }

    $profile['custom_title'] = trim(isset($_POST['custom_title']) ? $_POST['custom_title'] : '');
    if ($profile['custom_title'] === '') {
        $profile['custom_title'] = current_lang() === 'en' ? 'More' : '其他经历';
    }
    $profile['updated_at'] = now_str();

    save_data('profile', $profile);
    flash(t('profile_saved'));
    redirect('profile.php');
}

admin_header(t('profile'), 'profile');
$basic = $profile['basic'];
$avatar = isset($basic['avatar']) ? $basic['avatar'] : '';
$meta = isset($_SESSION['platform_meta']) ? (array)$_SESSION['platform_meta'] : array();
$metaQueries = isset($meta['queries']) && is_array($meta['queries']) ? $meta['queries'] : array();
$metaSort = isset($meta['sort']) ? $meta['sort'] : 'time_desc';
$metaLimit = isset($meta['limit']) ? (int)$meta['limit'] : 20;
?>
<!-- ============ 平台导入（支持多平台拼接 + 排序） ============ -->
<div class="card" id="import">
    <h3><?= icon('github') ?><?= te('import_title') ?></h3>
    <p class="muted" style="margin-top:0"><?= te('import_desc') ?></p>
    <form method="post" action="profile.php#import">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="fetch">
        <div id="pf-rows">
            <?php
            $rows = $metaQueries;
            if (empty($rows)) {
                $rows = array(array('platform' => 'github', 'user' => '', 'token' => '', 'base' => ''));
            }
            foreach ($rows as $i => $row):
                $pf = isset($row['platform']) ? $row['platform'] : 'github'; ?>
                <div class="pf-row">
                    <select name="platforms[<?= (int)$i ?>][pf]" class="pf-select">
                        <?php foreach (platform_list() as $k => $v): ?>
                            <option value="<?= e($k) ?>" <?= $pf === $k ? 'selected' : '' ?>><?= e(platform_name($k)) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="platforms[<?= (int)$i ?>][user]" class="pf-user"
                           value="<?= e(isset($row['user']) ? $row['user'] : '') ?>" placeholder="<?= te('import_user') ?>">
                    <input type="password" name="platforms[<?= (int)$i ?>][token]" class="pf-token"
                           value="<?= e(isset($row['token']) ? $row['token'] : '') ?>" placeholder="<?= te('import_token') ?>">
                    <input type="text" name="platforms[<?= (int)$i ?>][base]" class="pf-base"
                           style="display:<?= $pf === 'gitea' ? 'block' : 'none' ?>"
                           value="<?= e(isset($row['base']) ? $row['base'] : '') ?>" placeholder="https://git.example.com/api/v1">
                    <button type="button" class="btn btn-sm btn-danger pf-remove" title="<?= te('delete') ?>"><?= icon('trash') ?></button>
                </div>
            <?php endforeach; ?>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0 12px">
            <button type="button" class="btn btn-sm btn-line" id="pf-add"><?= icon('add') ?><?= te('import_add_platform') ?></button>
            <label class="muted" style="margin-left:auto"><?= te('platform_sort') ?>
                <select name="platform_sort" style="margin-left:6px">
                    <?php foreach (platform_sorts() as $sk => $sv): ?>
                        <option value="<?= e($sk) ?>" <?= $metaSort === $sk ? 'selected' : '' ?>><?= e($sv[current_lang()] ?? $sv['zh']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="muted"><?= te('import_count') ?>
                <select name="platform_limit" style="margin-left:6px">
                    <?php foreach (array(10, 20, 50, 100) as $n): ?>
                        <option value="<?= $n ?>" <?= $metaLimit === $n ? 'selected' : '' ?>><?= $n ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button class="btn" type="submit"><?= icon('download') ?><?= empty($repos) ? te('import_fetch') : te('import_refetch') ?></button>
        </div>
        <p class="muted" style="margin:0"><?= te('import_tip_token') ?></p>
    </form>

    <?php if (!empty($repos)): ?>
        <form method="post" action="profile.php#import">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="import_repos">
            <div class="alert alert-info" style="margin-top:16px">
                <?= icon('check') ?><span><?= e(t('import_result', count($repos))) ?>
                    · <?= e(platform_sort_name($metaSort)) ?></span>
            </div>
            <div class="tbl-wrap" style="max-height:340px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
                <table class="list">
                    <thead>
                    <tr>
                        <th style="width:36px"><input type="checkbox" id="pick-all" checked></th>
                        <th><?= te('col_repo') ?></th>
                        <th><?= te('col_platform') ?></th>
                        <th><?= te('col_lang') ?></th>
                        <th><?= te('col_star') ?></th>
                        <th><?= te('col_updated') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($repos as $i => $r): ?>
                        <tr>
                            <td><input type="checkbox" class="pick" name="pick[<?= (int)$i ?>]" value="1" checked></td>
                            <td>
                                <div style="font-weight:600"><?= e($r['name']) ?></div>
                                <div class="muted" style="max-width:340px"><?= e(str_cut($r['desc'] ?? '', 80, '…')) ?></div>
                            </td>
                            <td><span class="badge"><?= e(platform_name($r['platform'] ?? '')) ?></span></td>
                            <td><?= e($r['tech'] ?? '') ?></td>
                            <td><?= (int)($r['star'] ?? 0) > 0 ? '★ ' . (int)$r['star'] : '—' ?></td>
                            <td style="white-space:nowrap"><?= e($r['end'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                <button class="btn" type="submit" name="mode" value="append"><?= icon('add') ?><?= te('import_append') ?></button>
                <button class="btn btn-line" type="submit" name="mode" value="replace"><?= icon('refresh') ?><?= te('import_replace') ?></button>
                <span class="muted" id="pick-count"></span>
                <a class="btn btn-sm btn-line" href="#projects-block" style="margin-left:auto"><?= icon('add') ?><?= te('import_manual') ?></a>
            </div>
            <p class="muted" style="margin:8px 0 0"><?= te('import_tip_cache') ?></p>
        </form>
    <?php endif; ?>
</div>

<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <div class="card">
        <h3><?= icon('user') ?><?= te('basic_info') ?></h3>
        <div style="display:flex;gap:20px;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap">
            <div>
                <?php if ($avatar): ?>
                    <img src="../<?= e(ltrim(str_replace('\\', '/', $avatar), '/')) ?>" alt="头像"
                         style="width:96px;height:96px;object-fit:cover;border-radius:50%;border:1px solid var(--border)">
                <?php else: ?>
                    <div style="width:96px;height:96px;border-radius:50%;background:var(--chip);display:flex;align-items:center;justify-content:center;color:var(--text-3);font-size:12px;text-align:center"><?= te('no_avatar') ?></div>
                <?php endif; ?>
            </div>
            <div style="flex:1;min-width:260px">
                <div class="f" style="margin-bottom:10px">
                    <label><?= icon('image') ?><?= te('upload_avatar') ?>（jpg / png / webp，≤3MB）</label>
                    <input type="file" name="avatar_file" accept="image/*">
                </div>
                <div class="grid">
                    <div class="f f-2">
                        <label><?= te('avatar_url') ?></label>
                        <input type="text" name="basic[avatar]" value="<?= e($avatar) ?>" placeholder="如 https://... 或 data/uploads/xxx.png">
                    </div>
                    <div class="f f-1">
                        <label>&nbsp;</label>
                        <label class="checkline" style="margin-top:6px">
                            <input type="checkbox" name="avatar_remove" value="1"> <?= te('remove_avatar') ?>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="grid">
            <?php foreach (basic_schema() as $key => $field): ?>
                <?= field_control('basic[' . $key . ']', $field, isset($basic[$key]) ? $basic[$key] : '') ?>
            <?php endforeach; ?>
        </div>
    </div>

    <?php foreach (profile_schema() as $group => $meta2): ?>
        <?php
        if ($group === 'custom_items') {
            echo '<div class="card"><h3>' . icon('target') . te('custom_section') . '</h3>';
            echo '<div class="f" style="margin-bottom:14px"><label>' . te('f_section_title') . '</label>';
            echo '<input type="text" name="custom_title" value="' . e($profile['custom_title']) . '" placeholder="' . e(t('custom_section')) . '"></div>';
            repeater($group, t('f_entry'), $meta2['fields'], isset($profile[$group]) ? $profile[$group] : array(), $meta2['icon']);
            echo '</div>';
        } else {
            $label = t($meta2['label']);
            if ($group === 'projects') {
                $label = t('projects') . '（' . (current_lang() === 'en' ? 'manual entry' : '手动填写') . '）';
            $GLOBALS['__projects_anchor'] = true;
            }
            repeater($group, $label, $meta2['fields'], isset($profile[$group]) ? $profile[$group] : array(), $meta2['icon']);
        }
        ?>
    <?php endforeach; ?>

    <div style="margin:6px 0 40px">
        <button class="btn" type="submit"><?= icon('check') ?><?= te('save_all') ?></button>
        <a class="btn btn-line" href="../index.php" target="_blank"><?= icon('eye') ?><?= te('preview') ?></a>
    </div>
</form>

<script>
    (function () {
        // 平台行：新增 / 删除 / 自建地址显隐
        var wrap = document.getElementById('pf-rows');
        function bindRow(row) {
            var sel = row.querySelector('.pf-select'), base = row.querySelector('.pf-base');
            if (sel && base) {
                sel.addEventListener('change', function () {
                    base.style.display = sel.value === 'gitea' ? 'block' : 'none';
                });
            }
            var del = row.querySelector('.pf-remove');
            if (del) {
                del.addEventListener('click', function () {
                    var rows = wrap.querySelectorAll('.pf-row');
                    if (rows.length <= 1) {
                        row.querySelectorAll('input').forEach(function (i) { i.value = ''; });
                        return;
                    }
                    row.remove();
                    reindex();
                });
            }
        }
        function reindex() {
            wrap.querySelectorAll('.pf-row').forEach(function (row, idx) {
                row.querySelectorAll('select,input').forEach(function (el) {
                    var n = el.getAttribute('name') || '';
                    el.setAttribute('name', n.replace(/platforms\[\d+\]/, 'platforms[' + idx + ']'));
                });
            });
        }
        if (wrap) {
            wrap.querySelectorAll('.pf-row').forEach(bindRow);
            var addBtn = document.getElementById('pf-add');
            if (addBtn) {
                addBtn.addEventListener('click', function () {
                    var first = wrap.querySelector('.pf-row');
                    if (!first) return;
                    var clone = first.cloneNode(true);
                    clone.querySelectorAll('input').forEach(function (i) { i.value = ''; });
                    var sel = clone.querySelector('.pf-select');
                    if (sel) { sel.selectedIndex = 0; }
                    var base = clone.querySelector('.pf-base');
                    if (base) { base.style.display = 'none'; }
                    wrap.appendChild(clone);
                    bindRow(clone);
                    reindex();
                    var u = clone.querySelector('.pf-user');
                    if (u) u.focus();
                });
            }
        }
        var all = document.getElementById('pick-all');
        var picks = document.querySelectorAll('input.pick');
        var counter = document.getElementById('pick-count');
        function refresh() {
            var n = 0;
            picks.forEach(function (p) { if (p.checked) n++; });
            if (counter) counter.textContent = '<?= e(t('import_selected', '__N__')) ?>'.replace('__N__', n);
        }
        if (all) {
            all.addEventListener('change', function () {
                picks.forEach(function (p) { p.checked = all.checked; });
                refresh();
            });
        }
        picks.forEach(function (p) { p.addEventListener('change', refresh); });
        refresh();
    })();
</script>
<?php
admin_footer();
