<?php
/**
 * 后台：访问记录
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();
csrf_check();

$settings = get_data('settings', default_settings());

/* ---------- 清空 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clear') {
    track_clear();
    flash(t('clear_log') . ' · OK');
    redirect('visits.php');
}

/* ---------- 导出 CSV ---------- */
if (isset($_GET['export'])) {
    $list = track_list();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="visits-' . date('Ymd-His') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array(
        t('col_time'), t('col_ip'), t('col_page'), 'OS', 'Browser', t('col_screen'),
        'DPR', 'CPU', 'Mem(GB)', t('col_network'), 'Downlink(Mb/s)', 'RTT(ms)',
        t('col_battery') . '(%)', 'Charging', t('col_lang'), 'TZ', t('col_referer'), 'UA'
    ));
    foreach ($list as $r) {
        fputcsv($out, array(
            $r['time'] ?? '', $r['ip'] ?? '', $r['page'] ?? '', $r['os'] ?? '', $r['browser'] ?? '',
            $r['screen'] ?? '', $r['dpr'] ?? '', $r['cores'] ?? '', $r['mem'] ?? '',
            $r['net'] ?? '', $r['downlink'] ?? '', $r['rtt'] ?? '',
            $r['bat'] ?? '', isset($r['charging']) && $r['charging'] !== '' ? ((int)$r['charging'] ? t('battery_charging') : t('battery_discharg')) : '',
            $r['lang'] ?? '', $r['tz'] ?? '', $r['referer'] ?? '', $r['ua'] ?? ''
        ));
    }
    fclose($out);
    exit;
}

$all = track_list();
$stats = track_stats($all);
$maskIp = !empty($settings['ip_mask']);

/* ---------- 分页 ---------- */
$perPage = 30;
$total = count($all);
$pages = max(1, (int)ceil($total / $perPage));
$p = isset($_GET['p']) ? max(1, min($pages, (int)$_GET['p'])) : 1;
$rows = array_slice($all, ($p - 1) * $perPage, $perPage);

admin_header(t('visits'), 'visits');
?>
<div class="stats">
    <div class="stat">
        <div class="k"><?= icon('chart') ?><?= te('total_visits') ?></div>
        <div class="v"><?= (int)$stats['total'] ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('clock') ?><?= te('today_visits') ?></div>
        <div class="v"><?= (int)$stats['today'] ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('globe') ?><?= te('unique_ip') ?></div>
        <div class="v"><?= (int)$stats['ips'] ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('battery') ?><?= te('avg_battery') ?></div>
        <div class="v"><?= $stats['avg_bat'] === null ? '—' : (int)$stats['avg_bat'] . '%' ?></div>
        <div class="s"><?= te('battery_charging') ?> <?= (int)$stats['charging'] ?></div>
    </div>
</div>

<div class="card">
    <h3><?= icon('gauge') ?><?= te('visit_list') ?></h3>
    <?php if (!$settings['track_enable']): ?>
        <div class="alert alert-info" style="margin-bottom:14px">
            <?= icon('shield') ?><span><?= te('track_enable') ?> — 当前已关闭，新访问不会被记录。</span>
        </div>
    <?php endif; ?>
    <p class="muted" style="margin-top:0">
        <?= te('track_privacy') ?> ·
        <a href="visits.php?export=1"><?= icon('download') ?><?= te('export_csv') ?></a>
    </p>

    <?php if (empty($rows)): ?>
        <p class="muted"><?= te('no_data') ?></p>
    <?php else: ?>
        <div class="tbl-wrap">
            <table class="list">
                <thead>
                <tr>
                    <th><?= te('col_time') ?></th>
                    <th><?= te('col_ip') ?></th>
                    <th><?= te('col_device') ?></th>
                    <th><?= te('col_screen') ?></th>
                    <th><?= te('col_network') ?></th>
                    <th><?= te('col_battery') ?></th>
                    <th><?= te('col_lang') ?></th>
                    <th><?= te('col_referer') ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td style="white-space:nowrap"><?= e(substr($r['time'] ?? '', 5)) ?></td>
                        <td><code><?= e($maskIp ? mask_ip($r['ip'] ?? '') : ($r['ip'] ?? '')) ?></code></td>
                        <td>
                            <?= icon(device_icon($r['ua'] ?? '')) ?>
                            <?= e($r['os'] ?? '-') ?>
                            <span class="muted">· <?= e($r['browser'] ?? '-') ?></span>
                            <?php if (!empty($r['cores'])): ?><span class="badge"><?= e(t('cores', (int)$r['cores'])) ?></span><?php endif; ?>
                        </td>
                        <td><?= e($r['screen'] ?? '-') ?><?php if (!empty($r['dpr'])): ?> <span class="muted">@<?= e($r['dpr']) ?>x</span><?php endif; ?></td>
                        <td>
                            <?php if (!empty($r['net'])): ?>
                                <span class="badge"><?= icon('wifi') ?><?= e($r['net']) ?></span>
                                <?php if (!empty($r['downlink'])): ?><span class="muted"> <?= e($r['downlink']) ?>Mb/s</span><?php endif; ?>
                            <?php else: ?>
                                <span class="muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (isset($r['bat']) && $r['bat'] !== ''): ?>
                                <span class="badge <?= (int)$r['bat'] < 20 ? 'badge-orange' : 'badge-green' ?>">
                                    <?= icon('battery') ?><?= (int)$r['bat'] ?>%
                                </span>
                                <span class="muted"><?= !empty($r['charging']) ? te('battery_charging') : te('battery_discharg') ?></span>
                            <?php else: ?>
                                <span class="muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= e($r['lang'] ?? '-') ?><?php if (!empty($r['tz'])): ?><br><span class="muted"><?= e($r['tz']) ?></span><?php endif; ?></td>
                        <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                            <?php if (!empty($r['referer'])): ?>
                                <a href="<?= e($r['referer']) ?>" target="_blank" title="<?= e($r['referer']) ?>"><?= e(parse_url($r['referer'], PHP_URL_HOST) ?: $r['referer']) ?></a>
                            <?php else: ?>
                                <span class="muted"><?= te('direct') ?></span>
                            <?php endif; ?>
                            <br><span class="muted"><?= e($r['page'] ?? '') ?></span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pages > 1): ?>
            <div style="margin-top:14px;display:flex;gap:6px;flex-wrap:wrap">
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a class="btn btn-sm <?= $i === $p ? '' : 'btn-line' ?>" href="visits.php?p=<?= $i ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="card">
    <h3><?= icon('trash') ?><?= te('clear_log') ?></h3>
    <form method="post" data-confirm="<?= te('clear_log') ?>？">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="clear">
        <button class="btn btn-danger" type="submit"><?= icon('trash') ?><?= te('clear_log') ?></button>
        <span class="muted" style="margin-left:10px"><?= te('total') ?> <?= (int)$total ?> · <?= te('keep_records') ?> <?= (int)track_keep_limit() ?></span>
    </form>
</div>
<?php
admin_footer();
