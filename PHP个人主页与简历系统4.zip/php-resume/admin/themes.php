<?php
/**
 * 主题面板管理：搜索 / 新建 / 编辑 / 删除（内置为停用可恢复）/ 导入 / 导出
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();
csrf_check();

$lang = current_lang();
$settings = get_data('settings', array());
$editing = isset($_GET['edit']) ? (string)$_GET['edit'] : '';

/* ---------------- 导出 ---------------- */
if (isset($_GET['export'])) {
    $scope = (string)$_GET['export'];
    $payload = theme_export_payload($scope);
    if (empty($payload['panels'])) {
        flash(t('theme_export_empty'), 'error');
        redirect('themes.php');
    }
    $name = ($scope === 'all' ? 'all-panels' : ($scope === 'custom' ? 'custom-panels' : 'panel-' . preg_replace('/[^a-z0-9_\-]/i', '', $scope)))
        . '-' . date('Ymd') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/* ---------------- 保存（新建 / 编辑） ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_panel') {
    $origKey = trim((string)($_POST['orig_key'] ?? ''));
    $input = array(
        'key'     => trim((string)($_POST['panel_key'] ?? '')),
        'zh'      => trim((string)($_POST['zh'] ?? '')),
        'en'      => trim((string)($_POST['en'] ?? '')),
        'primary' => trim((string)($_POST['primary'] ?? '')),
        'accent'  => trim((string)($_POST['accent'] ?? '')),
        'neutral' => (int)($_POST['neutral'] ?? 220),
        'group'   => trim((string)($_POST['group'] ?? 'custom')),
    );
    list($ok, $msg, $panel) = theme_normalize_panel($input);
    if (!$ok) {
        flash(t('theme_save_failed', $msg), 'error');
        redirect('themes.php');
    }
    $key = $panel['key'];
    $isBuiltin = isset(theme_builtin_panels()[$key]);

    if ($isBuiltin) {
        // 内置面板不可覆盖：自动改名
        $key = theme_unique_key($key);
        $panel['key'] = $key;
        flash(t('theme_renamed', $key), 'error');
    }
    if ($origKey !== '' && $origKey !== $key) {
        // 改名：删掉旧 key
        $meta = theme_meta();
        if (isset($meta['custom'][$origKey])) {
            unset($meta['custom'][$origKey]);
            theme_meta_save($meta);
        }
    }
    list($ok2, $m2) = theme_put_panel($panel);
    if (!$ok2) {
        flash(t('theme_save_failed', $m2), 'error');
    } else {
        flash($origKey === '' ? t('theme_added', $key) : t('theme_updated', $key));
    }
    redirect('themes.php');
}

/* ---------------- 删除 / 停用 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $key = trim((string)($_POST['panel_key'] ?? ''));
    list($ok, $result) = theme_delete_panel($key);
    if (!$ok) {
        flash(t('theme_del_failed', $result), 'error');
    } else {
        flash($result === 'hidden' ? t('theme_hidden', $key) : t('theme_deleted', $key));
        // 若默认面板被移除，回退到 azure
        if (($settings['theme_panel'] ?? '') === $key) {
            $settings['theme_panel'] = 'azure';
            $settings['theme_color'] = theme_panels()['azure']['primary'];
            save_data('settings', $settings);
        }
    }
    redirect('themes.php');
}

/* ---------------- 恢复内置 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'restore') {
    $key = trim((string)($_POST['panel_key'] ?? ''));
    list($ok, $m) = theme_restore_panel($key);
    flash($ok ? t('theme_restored', $key) : t('theme_del_failed', $m), $ok ? 'success' : 'error');
    redirect('themes.php');
}

/* ---------------- 导入 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import') {
    $mode = in_array(($_POST['mode'] ?? ''), array('skip', 'overwrite', 'rename'), true) ? $_POST['mode'] : 'rename';
    $raw = trim((string)($_POST['json_text'] ?? ''));
    if ($raw === '' && !empty($_FILES['json_file']['name'])) {
        $f = $_FILES['json_file'];
        if (empty($f['error']) && $f['size'] <= 1024 * 1024) {
            $raw = (string)@file_get_contents($f['tmp_name']);
        } else {
            flash(t('theme_import_failed', '文件读取失败或超过 1MB'), 'error');
            redirect('themes.php#import');
        }
    }
    if ($raw === '') {
        flash(t('theme_import_failed', t('theme_import_need')), 'error');
        redirect('themes.php#import');
    }
    list($added, $updated, $renamed, $skipped, $errors) = theme_import_payload($raw, $mode);
    $parts = array();
    if ($added) {
        $parts[] = t('theme_import_added', $added);
    }
    if ($updated) {
        $parts[] = t('theme_import_updated', $updated);
    }
    if ($renamed) {
        $parts[] = t('theme_import_renamed', $renamed);
    }
    if ($skipped) {
        $parts[] = t('theme_import_skipped', $skipped);
    }
    if (!$added && !$updated && !$renamed) {
        // 一个都没导入成功：直接报错
        $why = $errors ? implode('；', array_slice($errors, 0, 3)) : t('theme_import_none');
        flash(t('theme_import_failed', $why), 'error');
    } else {
        flash(t('theme_import_done', implode('，', $parts)) . ($errors ? '（' . implode('；', array_slice($errors, 0, 3)) . '）' : ''), 'success');
    }
    redirect('themes.php');
}

/* ---------------- 列表 ---------------- */
$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$all = theme_panels();
$hidden = theme_hidden_panels();
$groups = theme_panel_groups();
$curPanel = $settings['theme_panel'] ?? 'azure';
$editPanel = ($editing !== '' && isset($all[$editing]) && $all[$editing]['source'] === 'custom') ? $all[$editing] : null;
$editKey = $editPanel ? $editing : '';

$match = function ($key, $p) use ($q) {
    if ($q === '') {
        return true;
    }
    $hay = strtolower($key . ' ' . $p['zh'] . ' ' . $p['en']);
    return strpos($hay, strtolower($q)) !== false;
};

admin_header(t('theme_panels'), 'themes');
?>
<div class="page-title">
    <h2><?= icon('palette') ?><?= te('theme_panels') ?></h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-line" href="themes.php?export=all"><?= icon('download') ?><?= te('theme_export_all') ?></a>
        <a class="btn btn-line" href="themes.php?export=custom"><?= icon('download') ?><?= te('theme_export_custom') ?></a>
        <a class="btn btn-line" href="themes.php#import"><?= icon('upload') ?><?= te('theme_import') ?></a>
        <a class="btn" href="themes.php#new"><?= icon('add') ?><?= te('theme_new') ?></a>
    </div>
</div>

<div class="card">
    <form method="get" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <div class="pp-search" style="flex:1;min-width:220px;margin:0">
            <?= icon('search') ?>
            <input type="text" name="q" id="theme-search" value="<?= e($q) ?>" placeholder="<?= te('panel_search_ph') ?>">
        </div>
        <button class="btn btn-line" type="submit"><?= icon('search') ?><?= te('search') ?></button>
        <?php if ($q !== ''): ?><a class="btn btn-gray" href="themes.php"><?= te('reset') ?></a><?php endif; ?>
    </form>
    <p class="muted" style="margin:10px 0 0">
        <?= e(t('theme_count', count($all))) ?><?php if ($hidden): ?> · <?= e(t('theme_hidden_count', count($hidden))) ?><?php endif; ?>
    </p>
</div>

<?php foreach ($groups as $gk => $g): ?>
    <?php
    $items = array_values(array_filter($g['items'], function ($k) use ($all, $match) {
        return isset($all[$k]) && $match($k, $all[$k]);
    }));
    if (empty($items)) {
        continue;
    }
    ?>
    <div class="card" data-group-block="<?= e($gk) ?>">
        <h3><?= icon('style') ?><?= e($g[$lang] ?? $g['zh']) ?> <span class="muted" style="font-weight:400">（<?= count($items) ?>）</span></h3>
        <div class="panel-cards">
            <?php foreach ($items as $key):
                $p = $all[$key];
                $nm = $p[$lang] ?? $p['zh'];
                $isCur = ($key === $curPanel);
                $isCustom = $p['source'] === 'custom'; ?>
                <div class="panel-card <?= $isCur ? 'on' : '' ?>"
                     data-search="<?= e(strtolower($nm . ' ' . $key . ' ' . $p['zh'] . ' ' . $p['en'])) ?>">
                    <div class="pc-swatch" style="background:linear-gradient(135deg,<?= e($p['primary']) ?>,<?= e($p['accent']) ?>)"></div>
                    <div class="pc-body">
                        <div class="pc-name">
                            <?= e($nm) ?>
                            <?php if ($isCustom): ?>
                                <span class="badge badge-orange"><?= te('theme_custom') ?></span>
                            <?php else: ?>
                                <span class="badge"><?= te('theme_builtin') ?></span>
                            <?php endif; ?>
                            <?php if ($isCur): ?><span class="badge badge-green"><?= te('in_use') ?></span><?php endif; ?>
                        </div>
                        <div class="pc-meta">
                            <code><?= e($key) ?></code>
                            <span><?= e($p['primary']) ?> / <?= e($p['accent']) ?> · H<?= (int)$p['neutral'] ?></span>
                        </div>
                        <div class="pc-actions">
                            <?php if ($isCustom): ?>
                                <a class="btn btn-sm btn-line" href="themes.php?edit=<?= e($key) ?>#new"><?= icon('edit') ?><?= te('edit') ?></a>
                                <a class="btn btn-sm btn-line" href="themes.php?export=<?= e($key) ?>"><?= icon('download') ?><?= te('theme_export') ?></a>
                            <?php else: ?>
                                <span class="muted" style="font-size:12px"><?= te('theme_builtin_tip') ?></span>
                            <?php endif; ?>
                            <form method="post" style="margin:0" onsubmit="return confirm('<?= e(t('theme_del_confirm', $nm)) ?>')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="panel_key" value="<?= e($key) ?>">
                                <button class="btn btn-sm btn-danger" type="submit"><?= icon('trash') ?><?= $isCustom ? te('delete') : te('theme_hide') ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>

<div class="pp-empty" id="no-match" style="display:none;padding:30px 0"><?= te('panel_no_match') ?></div>

<?php if ($hidden): ?>
    <div class="card">
        <h3><?= icon('trash') ?><?= te('theme_hidden_title') ?></h3>
        <p class="muted" style="margin-top:0"><?= te('theme_hidden_desc') ?></p>
        <div class="panel-cards">
            <?php foreach ($hidden as $key => $p):
                $nm = $p[$lang] ?? $p['zh']; ?>
                <div class="panel-card off">
                    <div class="pc-swatch" style="background:linear-gradient(135deg,<?= e($p['primary']) ?>,<?= e($p['accent']) ?>)"></div>
                    <div class="pc-body">
                        <div class="pc-name"><?= e($nm) ?> <span class="badge"><?= te('theme_builtin') ?></span></div>
                        <div class="pc-meta"><code><?= e($key) ?></code><span><?= e($p['primary']) ?></span></div>
                        <div class="pc-actions">
                            <form method="post" style="margin:0">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="restore">
                                <input type="hidden" name="panel_key" value="<?= e($key) ?>">
                                <button class="btn btn-sm" type="submit"><?= icon('refresh') ?><?= te('theme_restore') ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- ============ 新建 / 编辑 ============ -->
<div class="card" id="new">
    <h3><?= icon($editPanel ? 'edit' : 'add') ?><?= $editPanel ? te('theme_edit') : te('theme_new') ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_panel">
        <input type="hidden" name="orig_key" value="<?= e($editKey) ?>">
        <div class="grid">
            <div class="f f-1"><label><?= te('theme_key') ?></label>
                <input type="text" name="panel_key" value="<?= e($editKey) ?>" placeholder="my_theme" <?= $editPanel ? '' : 'required' ?>></div>
            <div class="f f-1"><label><?= te('theme_zh') ?></label>
                <input type="text" name="zh" value="<?= e($editPanel['zh'] ?? '') ?>" placeholder="如 落日橙" required></div>
            <div class="f f-1"><label><?= te('theme_en') ?></label>
                <input type="text" name="en" value="<?= e($editPanel['en'] ?? '') ?>" placeholder="Sunset"></div>
            <div class="f f-1"><label><?= te('theme_primary') ?></label>
                <input type="text" name="primary" id="in-primary" value="<?= e($editPanel['primary'] ?? '#2563eb') ?>" placeholder="#2563eb" required></div>
            <div class="f f-1"><label><?= te('theme_accent') ?></label>
                <input type="text" name="accent" id="in-accent" value="<?= e($editPanel['accent'] ?? '') ?>" placeholder="留空则与主色相同"></div>
            <div class="f f-1"><label><?= te('theme_neutral') ?></label>
                <input type="number" name="neutral" value="<?= e((string)($editPanel['neutral'] ?? 220)) ?>" min="0" max="360"></div>
            <div class="f f-1"><label><?= te('theme_group') ?></label>
                <select name="group">
                    <?php foreach (array('classic', 'vivid', 'nature', 'calm', 'custom') as $gk2):
                        $lb = isset(theme_builtin_groups()[$gk2]) ? (theme_builtin_groups()[$gk2][$lang] ?? theme_builtin_groups()[$gk2]['zh']) : te('theme_custom');
                        if ($gk2 === 'custom') {
                            $lb = $lang === 'en' ? 'Custom' : '自定义';
                        } ?>
                        <option value="<?= e($gk2) ?>" <?= ($editPanel['group'] ?? 'custom') === $gk2 ? 'selected' : '' ?>><?= e($lb) ?></option>
                    <?php endforeach; ?>
                </select></div>
        </div>
        <div class="pp-colors" style="grid-template-columns:repeat(8,1fr);max-width:340px;margin:6px 0 4px">
            <?php foreach (theme_swatches() as $hex => $lb): ?>
                <button type="button" class="pp-color" data-pick-primary="<?= e($hex) ?>"
                        style="background:<?= e($hex) ?>" title="<?= e($lb[$lang] ?? $lb['zh']) ?>"><span></span></button>
            <?php endforeach; ?>
        </div>
        <p class="muted" style="margin-top:0"><?= te('theme_new_tip') ?></p>
        <div style="margin-top:10px;display:flex;gap:8px">
            <button class="btn" type="submit"><?= icon('check') ?><?= te('save') ?></button>
            <?php if ($editPanel): ?><a class="btn btn-gray" href="themes.php#new"><?= te('cancel') ?></a><?php endif; ?>
        </div>
    </form>
</div>

<!-- ============ 导入 ============ -->
<div class="card" id="import">
    <h3><?= icon('upload') ?><?= te('theme_import') ?></h3>
    <p class="muted" style="margin-top:0"><?= te('theme_import_desc') ?></p>
    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="import">
        <div class="grid">
            <div class="f f-1"><label><?= te('theme_import_file') ?></label>
                <input type="file" name="json_file" accept=".json,application/json,text/plain"></div>
            <div class="f f-1"><label><?= te('theme_import_mode') ?></label>
                <select name="mode">
                    <option value="rename"><?= te('theme_mode_rename') ?></option>
                    <option value="overwrite"><?= te('theme_mode_overwrite') ?></option>
                    <option value="skip"><?= te('theme_mode_skip') ?></option>
                </select></div>
        </div>
        <div class="f" style="margin-top:10px">
            <label><?= te('theme_import_paste') ?></label>
            <textarea name="json_text" rows="6" placeholder='{"panels":[{"key":"sunset","zh":"落日橙","en":"Sunset","primary":"#f97316","accent":"#fb923c","neutral":30,"group":"vivid"}]}'></textarea>
        </div>
        <p class="muted" style="margin-top:8px"><?= te('theme_import_tip') ?></p>
        <div style="margin-top:10px"><button class="btn" type="submit"><?= icon('upload') ?><?= te('theme_import') ?></button></div>
    </form>
</div>

<script>
    (function () {
        // 主色快捷选择
        document.querySelectorAll('[data-pick-primary]').forEach(function (b) {
            b.addEventListener('click', function () {
                var hex = b.getAttribute('data-pick-primary');
                var p = document.getElementById('in-primary');
                if (p) { p.value = hex; }
                var a = document.getElementById('in-accent');
                if (a && !a.value) { a.value = hex; }
            });
        });
        // 实时搜索
        var input = document.getElementById('theme-search');
        if (!input) return;
        var cards = document.querySelectorAll('.panel-card[data-search]');
        var blocks = document.querySelectorAll('[data-group-block]');
        var none = document.getElementById('no-match');
        input.addEventListener('input', function () {
            var q = (input.value || '').toLowerCase().trim();
            cards.forEach(function (c) {
                c.style.display = (!q || (c.getAttribute('data-search') || '').indexOf(q) !== -1) ? '' : 'none';
            });
            blocks.forEach(function (g) {
                var any = false;
                g.querySelectorAll('.panel-card[data-search]').forEach(function (c) { if (c.style.display !== 'none') any = true; });
                g.style.display = any ? '' : 'none';
            });
            var shown = 0;
            cards.forEach(function (c) { if (c.style.display !== 'none') shown++; });
            if (none) none.style.display = (q && shown === 0) ? 'block' : 'none';
        });
    })();
</script>
<?php
admin_footer();
