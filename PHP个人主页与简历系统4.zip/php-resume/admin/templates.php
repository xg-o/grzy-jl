<?php
/**
 * 后台：模板管理
 * 选择使用 / 搜索 / 新建（含复制）/ 编辑源码 / 删除（内置为停用可恢复）/ 导入导出
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();
csrf_check();

$lang = current_lang();
$settings = get_data('settings', default_settings());

/* ---------------- 导出 ---------------- */
if (isset($_GET['export'])) {
    $scope = (string)$_GET['export'];
    $payload = tpl_export_payload($scope);
    if (empty($payload['templates'])) {
        flash(t('tpl_export_empty'), 'error');
        redirect('templates.php');
    }
    $name = ($scope === 'all' ? 'all-templates' : ($scope === 'custom' ? 'custom-templates' : 'template-' . preg_replace('/[^a-z0-9_\-]/i', '', $scope)))
        . '-' . date('Ymd') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/* ---------------- 下载单个模板源码（.php） ---------------- */
if (isset($_GET['download'])) {
    $key = (string)$_GET['download'];
    $file = template_path($key);
    if (!$file) {
        flash(t('tpl_export_empty'), 'error');
        redirect('templates.php');
    }
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Cache-Control: no-store');
    readfile($file);
    exit;
}

/* ---------------- 使用此模板 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'use') {
    $key = (string)($_POST['tpl_key'] ?? '');
    $type = (($_POST['tpl_type'] ?? '') === 'resume') ? 'resume' : 'home';
    $field = $type === 'resume' ? 'resume_template' : 'home_template';
    $settings[$field] = valid_template($key, $type);
    $settings['updated_at'] = now_str();
    save_data('settings', $settings);
    flash(t('tpl_saved'));
    redirect('templates.php');
}

/* ---------------- 删除 / 停用 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $key = (string)($_POST['tpl_key'] ?? '');
    $type = (($_POST['tpl_type'] ?? '') === 'resume') ? 'resume' : 'home';
    $all = template_list();
    $name = isset($all[$type][$key]['name']) ? $all[$type][$key]['name'] : $key;
    list($ok, $result) = tpl_delete($key);
    if (!$ok) {
        flash(t('tpl_del_failed', $result), 'error');
    } else {
        flash($result === 'hidden' ? t('tpl_hidden', $name) : t('tpl_deleted', $name));
        // 若正被使用，回退到该类型第一个可用模板
        $field = $type === 'resume' ? 'resume_template' : 'home_template';
        if (($settings[$field] ?? '') === $key) {
            $settings[$field] = valid_template('', $type);
            $settings['updated_at'] = now_str();
            save_data('settings', $settings);
        }
    }
    redirect('templates.php');
}

/* ---------------- 恢复内置 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'restore') {
    $key = (string)($_POST['tpl_key'] ?? '');
    list($ok, $m) = tpl_restore($key);
    flash($ok ? t('tpl_restored', $key) : t('tpl_del_failed', $m), $ok ? 'success' : 'error');
    redirect('templates.php');
}

/* ---------------- 新建 / 编辑（保存源码） ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_tpl') {
    $origKey = trim((string)($_POST['orig_key'] ?? ''));
    $key = trim((string)($_POST['tpl_key'] ?? ''));
    $name = trim((string)($_POST['tpl_name'] ?? ''));
    $desc = trim((string)($_POST['tpl_desc'] ?? ''));
    $type = (($_POST['tpl_type'] ?? '') === 'resume') ? 'resume' : 'home';
    $source = (string)($_POST['tpl_source'] ?? '');

    $key = tpl_normalize_key($key);
    if ($key === '') {
        $key = tpl_normalize_key($name);
    }
    if ($key === '' && $origKey !== '') {
        $key = $origKey;
    }
    $builtin = tpl_builtin();
    $isBuiltin = isset($builtin['home'][$key]) || isset($builtin['resume'][$key]);
    if ($isBuiltin) {
        $key = tpl_unique_key($key);
        flash(t('tpl_renamed', $key), 'error');
    }
    if ($origKey !== '' && $origKey !== $key) {
        // 改名：先删旧的
        tpl_delete($origKey);
    }
    list($ok, $msg) = tpl_put($key, $name, $desc, $type, $source);
    if (!$ok) {
        flash(t('tpl_save_failed', $msg), 'error');
    } else {
        flash($msg === 'updated' ? t('tpl_updated', $key) : t('tpl_added', $key));
    }
    redirect('templates.php');
}

/* ---------------- 导入 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import') {
    $mode = in_array(($_POST['mode'] ?? ''), array('skip', 'overwrite', 'rename'), true) ? $_POST['mode'] : 'rename';
    $raw = trim((string)($_POST['json_text'] ?? ''));
    $defaults = array(
        'key'  => trim((string)($_POST['def_key'] ?? '')),
        'name' => trim((string)($_POST['def_name'] ?? '')),
        'desc' => trim((string)($_POST['def_desc'] ?? '')),
        'type' => (($_POST['def_type'] ?? '') === 'resume') ? 'resume' : 'home',
    );
    if ($raw === '' && !empty($_FILES['json_file']['name'])) {
        $f = $_FILES['json_file'];
        if (empty($f['error']) && $f['size'] <= 2 * 1024 * 1024) {
            $raw = (string)@file_get_contents($f['tmp_name']);
        } else {
            flash(t('tpl_import_failed', '文件读取失败或超过 2MB'), 'error');
            redirect('templates.php#import');
        }
    }
    if ($raw === '') {
        flash(t('tpl_import_failed', t('tpl_import_need')), 'error');
        redirect('templates.php#import');
    }
    list($added, $updated, $renamed, $skipped, $errors) = tpl_import_payload($raw, $mode, $defaults);
    if (!$added && !$updated && !$renamed) {
        $why = $errors ? implode('；', array_slice($errors, 0, 3)) : t('tpl_import_none');
        flash(t('tpl_import_failed', $why), 'error');
    } else {
        $parts = array();
        if ($added) {
            $parts[] = t('tpl_import_added', $added);
        }
        if ($updated) {
            $parts[] = t('tpl_import_updated', $updated);
        }
        if ($renamed) {
            $parts[] = t('tpl_import_renamed', $renamed);
        }
        if ($skipped) {
            $parts[] = t('tpl_import_skipped', $skipped);
        }
        flash(t('tpl_import_done', implode('，', $parts)) . ($errors ? '（' . implode('；', array_slice($errors, 0, 2)) . '）' : ''));
    }
    redirect('templates.php');
}

/* ---------------- 列表 ---------------- */
$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$editKey = isset($_GET['edit']) ? (string)$_GET['edit'] : '';
$copyKey = isset($_GET['copy']) ? (string)$_GET['copy'] : '';
$allList = template_list();
$hidden = tpl_hidden_list();

$editTpl = null;
$editSource = '';
$isEdit = false;   // true = 编辑已有自定义模板；false = 新建（可能带蓝本）
if ($editKey !== '') {
    $found = null;
    foreach ($allList as $group) {
        if (isset($group[$editKey]) && $group[$editKey]['source'] === 'custom') {
            $found = $group[$editKey];
            break;
        }
    }
    if ($found) {
        $editTpl = $found;
        $isEdit = true;
        $file = template_path($editKey);
        if ($file) {
            $editSource = (string)file_get_contents($file);
        }
    } else {
        $editKey = '';
    }
}
if ($editTpl === null && $copyKey !== '') {
    // 以某模板为蓝本新建
    $src = null;
    foreach ($allList as $group) {
        if (isset($group[$copyKey])) {
            $src = $group[$copyKey];
            break;
        }
    }
    if ($src) {
        $file = template_path($copyKey);
        $editTpl = array(
            'name' => $src['name'] . '（副本）',
            'desc' => $src['desc'],
            'type' => $src['type'],
        );
        $editKey = tpl_normalize_key($copyKey . '_copy');
        $editSource = $file ? (string)file_get_contents($file) : '';
    }
}

$match = function ($key, $p) use ($q) {
    if ($q === '') {
        return true;
    }
    $hay = strtolower($key . ' ' . $p['name'] . ' ' . ($p['en'] ?? '') . ' ' . $p['desc']);
    return strpos($hay, strtolower($q)) !== false;
};

$types = array(
    'home'   => array('title' => 'home_tpl', 'field' => 'home_template', 'preview' => '../index.php', 'icon' => 'layout'),
    'resume' => array('title' => 'resume_tpl', 'field' => 'resume_template', 'preview' => '../resume.php', 'icon' => 'print'),
);

admin_header(t('templates'), 'templates');
?>
<div class="page-title">
    <h2><?= icon('layout') ?><?= te('templates') ?></h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn-line" href="templates.php?export=all"><?= icon('download') ?><?= te('tpl_export_all') ?></a>
        <a class="btn btn-line" href="templates.php?export=custom"><?= icon('download') ?><?= te('tpl_export_custom') ?></a>
        <a class="btn btn-line" href="templates.php#import"><?= icon('upload') ?><?= te('tpl_import') ?></a>
        <a class="btn" href="templates.php#new"><?= icon('add') ?><?= te('tpl_new') ?></a>
    </div>
</div>

<div class="card">
    <form method="get" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <div class="pp-search" style="flex:1;min-width:220px;margin:0">
            <?= icon('search') ?>
            <input type="text" name="q" id="tpl-search" value="<?= e($q) ?>" placeholder="<?= te('tpl_search_ph') ?>">
        </div>
        <button class="btn btn-line" type="submit"><?= icon('search') ?><?= te('search') ?></button>
        <?php if ($q !== ''): ?><a class="btn btn-gray" href="templates.php"><?= te('reset') ?></a><?php endif; ?>
    </form>
    <p class="muted" style="margin:10px 0 0">
        <?= e(t('tpl_count', count($allList['home']) + count($allList['resume']))) ?><?php if ($hidden): ?> · <?= e(t('tpl_hidden_count', count($hidden))) ?><?php endif; ?>
    </p>
</div>

<?php foreach ($types as $type => $info): ?>
    <?php
    $items = array();
    foreach (template_list($type) as $key => $meta) {
        if ($match($key, $meta)) {
            $items[$key] = $meta;
        }
    }
    if (empty($items)) {
        continue;
    }
    ?>
    <div class="card" data-group-block="<?= e($type) ?>">
        <h3><?= icon($info['icon']) ?><?= te($info['title']) ?> <span class="muted" style="font-weight:400">（<?= count($items) ?>）</span></h3>
        <div class="tpl-grid">
            <?php foreach ($items as $key => $meta):
                $inUse = ($settings[$info['field']] ?? '') === $key;
                $isCustom = $meta['source'] === 'custom'; ?>
                <div class="tpl-card <?= $inUse ? 'on' : '' ?>"
                     data-search="<?= e(strtolower($key . ' ' . $meta['name'] . ' ' . ($meta['en'] ?? '') . ' ' . $meta['desc'])) ?>">
                    <div class="tpl-preview">
                        <iframe src="<?= e($info['preview']) ?>?preview_tpl=<?= e($key) ?>" loading="lazy"
                                scrolling="no" title="<?= e($meta['name']) ?>"></iframe>
                    </div>
                    <div class="tpl-body">
                        <h4><?= e($meta['name']) ?>
                            <?php if ($isCustom): ?>
                                <span class="badge badge-orange"><?= te('tpl_custom') ?></span>
                            <?php else: ?>
                                <span class="badge"><?= te('tpl_builtin') ?></span>
                            <?php endif; ?>
                            <?php if ($inUse): ?><span class="badge badge-green"><?= te('in_use') ?></span><?php endif; ?>
                        </h4>
                        <p><?= e($meta['desc']) ?></p>
                        <div class="tpl-body-meta"><code><?= e($key) ?></code></div>
                        <div class="tpl-actions">
                            <form method="post" style="margin:0">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="use">
                                <input type="hidden" name="tpl_key" value="<?= e($key) ?>">
                                <input type="hidden" name="tpl_type" value="<?= e($type) ?>">
                                <button class="btn btn-sm <?= $inUse ? 'btn-gray' : '' ?>" type="submit" <?= $inUse ? 'disabled' : '' ?>>
                                    <?= icon('check') ?><?= $inUse ? te('in_use') : te('use_this') ?>
                                </button>
                            </form>
                            <a class="btn btn-sm btn-line" target="_blank"
                               href="<?= e($info['preview']) ?>?preview_tpl=<?= e($key) ?>"><?= icon('eye') ?></a>
                            <a class="btn btn-sm btn-line" href="templates.php?download=<?= e($key) ?>"
                               title="<?= te('tpl_download') ?>"><?= icon('download') ?></a>
                            <a class="btn btn-sm btn-line" href="templates.php?copy=<?= e($key) ?>#new"
                               title="<?= te('tpl_copy') ?>"><?= icon('style') ?></a>
                            <?php if ($isCustom): ?>
                                <a class="btn btn-sm btn-line" href="templates.php?edit=<?= e($key) ?>#new"><?= icon('edit') ?></a>
                            <?php endif; ?>
                            <form method="post" style="margin:0" onsubmit="return confirm('<?= e(t('tpl_del_confirm', $meta['name'])) ?>')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="tpl_key" value="<?= e($key) ?>">
                                <input type="hidden" name="tpl_type" value="<?= e($type) ?>">
                                <button class="btn btn-sm btn-danger" type="submit" title="<?= $isCustom ? e(te('delete')) : e(te('tpl_hide')) ?>"><?= icon('trash') ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>

<div class="pp-empty" id="tpl-no-match" style="display:none;padding:30px 0"><?= te('tpl_no_match') ?></div>

<?php if ($hidden): ?>
    <div class="card">
        <h3><?= icon('trash') ?><?= te('tpl_hidden_title') ?></h3>
        <p class="muted" style="margin-top:0"><?= te('tpl_hidden_desc') ?></p>
        <div class="tpl-grid">
            <?php foreach ($hidden as $key => $p): ?>
                <div class="tpl-card off">
                    <div class="tpl-body">
                        <h4><?= e($p['name']) ?> <span class="badge"><?= te('tpl_builtin') ?></span></h4>
                        <p><?= e($p['desc']) ?></p>
                        <div class="tpl-body-meta"><code><?= e($key) ?></code></div>
                        <div class="tpl-actions">
                            <form method="post" style="margin:0">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="restore">
                                <input type="hidden" name="tpl_key" value="<?= e($key) ?>">
                                <button class="btn btn-sm" type="submit"><?= icon('refresh') ?><?= te('tpl_restore') ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- ============ 新建 / 编辑 ============ -->
<div class="card" id="new">
    <h3><?= icon($isEdit ? 'edit' : 'add') ?><?= $isEdit ? te('tpl_edit') : te('tpl_new') ?></h3>
    <p class="muted" style="margin-top:0"><?= te('tpl_new_tip') ?></p>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_tpl">
        <input type="hidden" name="orig_key" value="<?= e($isEdit ? $editKey : '') ?>">
        <div class="grid">
            <div class="f f-1"><label><?= te('tpl_key') ?></label>
                <input type="text" name="tpl_key" value="<?= e($editKey) ?>" placeholder="my_template"></div>
            <div class="f f-1"><label><?= te('tpl_name') ?></label>
                <input type="text" name="tpl_name" value="<?= e($editTpl['name'] ?? '') ?>" placeholder="我的模板" required></div>
            <div class="f f-1"><label><?= te('tpl_type') ?></label>
                <select name="tpl_type">
                    <option value="home" <?= ($editTpl['type'] ?? 'home') === 'home' ? 'selected' : '' ?>><?= te('home_tpl') ?></option>
                    <option value="resume" <?= ($editTpl['type'] ?? '') === 'resume' ? 'selected' : '' ?>><?= te('resume_tpl') ?></option>
                </select></div>
            <div class="f f-3"><label><?= te('tpl_desc') ?></label>
                <input type="text" name="tpl_desc" value="<?= e($editTpl['desc'] ?? '') ?>" placeholder="<?= te('tpl_desc_ph') ?>"></div>
        </div>
        <div class="f" style="margin-top:10px">
            <label><?= icon('style') ?><?= te('tpl_source') ?></label>
            <textarea name="tpl_source" rows="16" class="code" spellcheck="false"
                      placeholder="&lt;?php /* 模板源码 */ ?&gt;"><?= e($editSource) ?></textarea>
        </div>
        <div style="margin-top:10px;display:flex;gap:8px">
            <button class="btn" type="submit"><?= icon('check') ?><?= te('save') ?></button>
            <?php if ($editTpl): ?><a class="btn btn-gray" href="templates.php#new"><?= te('cancel') ?></a><?php endif; ?>
        </div>
    </form>
</div>

<!-- ============ 导入 ============ -->
<div class="card" id="import">
    <h3><?= icon('upload') ?><?= te('tpl_import') ?></h3>
    <p class="muted" style="margin-top:0"><?= te('tpl_import_desc') ?></p>
    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="import">
        <div class="grid">
            <div class="f f-1"><label><?= te('tpl_import_file') ?></label>
                <input type="file" name="json_file" accept=".json,.php,application/json,text/plain"></div>
            <div class="f f-1"><label><?= te('tpl_import_mode') ?></label>
                <select name="mode">
                    <option value="rename"><?= te('theme_mode_rename') ?></option>
                    <option value="overwrite"><?= te('theme_mode_overwrite') ?></option>
                    <option value="skip"><?= te('theme_mode_skip') ?></option>
                </select></div>
            <div class="f f-1"><label><?= te('tpl_key') ?></label>
                <input type="text" name="def_key" placeholder="<?= te('tpl_def_key_ph') ?>"></div>
            <div class="f f-1"><label><?= te('tpl_name') ?></label>
                <input type="text" name="def_name" placeholder="<?= te('tpl_def_name_ph') ?>"></div>
            <div class="f f-1"><label><?= te('tpl_type') ?></label>
                <select name="def_type">
                    <option value="home"><?= te('home_tpl') ?></option>
                    <option value="resume"><?= te('resume_tpl') ?></option>
                </select></div>
            <div class="f f-1"><label><?= te('tpl_desc') ?></label>
                <input type="text" name="def_desc" placeholder="<?= te('tpl_desc_ph') ?>"></div>
        </div>
        <div class="f" style="margin-top:10px">
            <label><?= te('tpl_import_paste') ?></label>
            <textarea name="json_text" rows="8" class="code" spellcheck="false"
                      placeholder='{"templates":[{"key":"my_tpl","name":"我的模板","type":"home","desc":"…","source":"<?= e('<?php /* … */ ?>') ?>"}]}'></textarea>
        </div>
        <p class="muted" style="margin-top:8px"><?= te('tpl_import_tip') ?></p>
        <div style="margin-top:10px"><button class="btn" type="submit"><?= icon('upload') ?><?= te('tpl_import') ?></button></div>
    </form>
</div>

<script>
    (function () {
        var input = document.getElementById('tpl-search');
        if (!input) return;
        var cards = document.querySelectorAll('.tpl-card[data-search]');
        var blocks = document.querySelectorAll('[data-group-block]');
        var none = document.getElementById('tpl-no-match');
        input.addEventListener('input', function () {
            var q = (input.value || '').toLowerCase().trim();
            cards.forEach(function (c) {
                c.style.display = (!q || (c.getAttribute('data-search') || '').indexOf(q) !== -1) ? '' : 'none';
            });
            blocks.forEach(function (g) {
                var any = false;
                g.querySelectorAll('.tpl-card[data-search]').forEach(function (c) { if (c.style.display !== 'none') any = true; });
                g.style.display = any ? '' : 'none';
            });
            var shown = 0;
            cards.forEach(function (c) { if (c.style.display !== 'none') shown++; });
            if (none) none.style.display = (q && shown === 0) ? 'block' : 'none';
        });
    })();
</script>
<?php
admin_footer();
