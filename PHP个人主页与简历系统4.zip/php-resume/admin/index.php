<?php
/**
 * 后台概况
 */
require_once dirname(__DIR__) . '/includes/app.php';
require_once dirname(__DIR__) . '/includes/admin_ui.php';
if (!is_installed()) {
    redirect('../install.php');
}
require_admin();

$profile = get_data('profile', default_profile());
$settings = get_data('settings', default_settings());
$cfg = load_config();
$store = storage();
$stats = track_stats();

admin_header(t('dashboard'), 'index');
?>
<div class="stats">
    <div class="stat">
        <div class="k"><?= icon('user') ?><?= te('profile') ?></div>
        <div class="v" style="font-size:18px"><?= e($profile['basic']['name']) ?></div>
        <div class="s"><?= e($profile['basic']['title']) ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('chart') ?><?= te('total_visits') ?></div>
        <div class="v"><?= (int)$stats['total'] ?></div>
        <div class="s"><?= te('today_visits') ?> <?= (int)$stats['today'] ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('globe') ?><?= te('unique_ip') ?></div>
        <div class="v"><?= (int)$stats['ips'] ?></div>
    </div>
    <div class="stat">
        <div class="k"><?= icon('database') ?><?= te('storage') ?></div>
        <div class="v" style="font-size:15px"><?= e($store instanceof FileStore ? strtoupper($store->format()) : 'DB') ?></div>
    </div>
</div>

<div class="card">
    <h3><?= icon('sliders') ?><?= te('system_info') ?></h3>
    <table class="info">
        <tr><th><?= te('total') ?> v</th><td><?= e(APP_VERSION) ?></td></tr>
        <tr><th><?= te('storage') ?></th><td><?= e($store->label()) ?></td></tr>
        <?php if ($store instanceof FileStore): ?>
            <tr><th><?= te('storage') ?> Dir</th><td><code><?= e($store->dir()) ?></code></td></tr>
            <tr><th>Format</th><td><code>.<?= e($store->format()) ?></code></td></tr>
        <?php else: ?>
            <tr><th>DB</th><td><?= e($cfg['db']['driver'] === 'sqlite' ? 'SQLite：' . $cfg['db']['file'] : 'MySQL ' . $cfg['db']['host'] . ' / ' . $cfg['db']['name']) ?></td></tr>
            <tr><th>Table</th><td><code><?= e($store->table()) ?></code></td></tr>
        <?php endif; ?>
        <tr><th>Config</th><td><code>config/config.php</code></td></tr>
        <tr><th>PHP</th><td><?= e(PHP_VERSION) ?></td></tr>
        <tr><th><?= te('default_lang') ?></th><td><?= e(lang_name($settings['language'] ?? 'zh')) ?></td></tr>
        <tr><th><?= te('default_mode') ?></th><td><?= e(t('mode_' . ($settings['default_mode'] ?? 'auto'))) ?></td></tr>
        <tr><th><?= te('panel_default') ?></th><td><?= e(panel_name($settings['theme_panel'] ?? 'azure')) ?>（<?= e($settings['theme_panel'] ?? 'azure') ?>）</td></tr>
        <tr><th><?= te('updated_at') ?></th><td><?= e(isset($cfg['installed_at']) ? $cfg['installed_at'] : '-') ?></td></tr>
    </table>
</div>

<div class="card">
    <h3><?= icon('layout') ?><?= te('content_overview') ?></h3>
    <table class="info">
        <tr><th><?= te('education') ?></th><td><?= count($profile['educations']) ?></td></tr>
        <tr><th><?= te('experience') ?></th><td><?= count($profile['experiences']) ?></td></tr>
        <tr><th><?= te('projects') ?></th><td><?= count($profile['projects']) ?></td></tr>
        <tr><th><?= te('skills') ?></th><td><?= count($profile['skills']) ?></td></tr>
        <tr><th><?= te('certificates') ?></th><td><?= count($profile['certs']) ?></td></tr>
        <tr><th><?= te('portfolio') ?></th><td><?= count($profile['portfolio']) ?></td></tr>
        <tr><th><?= te('templates') ?></th><td><?= e(template_list('home')[$settings['home_template']]['name']) ?> ｜ <?= e(template_list('resume')[$settings['resume_template']]['name']) ?></td></tr>
        <tr><th><?= te('updated_at') ?></th><td><?= e($profile['updated_at'] ?: '-') ?></td></tr>
    </table>
</div>

<div class="card">
    <h3><?= icon('add') ?><?= te('quick_actions') ?></h3>
    <p>
        <a class="btn" href="profile.php"><?= icon('user') ?><?= te('edit_profile') ?></a>
        <a class="btn btn-line" href="templates.php"><?= icon('layout') ?><?= te('switch_template') ?></a>
        <a class="btn btn-line" href="visits.php"><?= icon('gauge') ?><?= te('visits') ?></a>
        <a class="btn btn-line" href="../index.php" target="_blank"><?= icon('eye') ?><?= te('preview_home') ?></a>
        <a class="btn btn-line" href="../resume.php?print=1" target="_blank"><?= icon('print') ?><?= te('print_pdf') ?></a>
    </p>
    <p class="muted"><?= te('print_tip') ?></p>
</div>
<?php
admin_footer();
