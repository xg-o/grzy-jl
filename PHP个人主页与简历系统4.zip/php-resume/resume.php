<?php
/**
 * 前台：正规样式简历（A4 打印友好）
 * 参数：?preview_tpl=resume_timeline（需后台登录） ?print=1 自动调起打印 ?lang=en
 */
require_once __DIR__ . '/includes/app.php';

if (!is_installed()) {
    redirect('install.php');
}

if (!empty($_GET['lang']) && isset(lang_list()[$_GET['lang']])) {
    set_lang($_GET['lang']);
}

$GLOBALS['__page'] = 'resume';

$profile = get_data('profile', default_profile());
$settings = get_data('settings', default_settings());

$tpl = valid_template($settings['resume_template'], 'resume');
if (is_admin() && !empty($_GET['preview_tpl'])) {
    $tpl = valid_template($_GET['preview_tpl'], 'resume');
    // 预览模式（后台缩略图 iframe）：不输出右上角偏好控件
    $GLOBALS['__preview'] = true;
}
$file = template_path($tpl);
if (!$file) {
    exit('模板文件不存在：' . e($tpl));
}

require $file;
