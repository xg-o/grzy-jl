<?php
/**
 * 安装向导
 * 步骤：1 环境检测 → 2 选择存储方式 → 3 管理员与初始资料 → 4 完成
 */
require_once __DIR__ . '/includes/app.php';

if (!empty($_GET['lang']) && isset(lang_list()[$_GET['lang']])) {
    set_lang($_GET['lang']);
}

if (is_installed() && !(isset($_GET['step']) && (int)$_GET['step'] === 4)) {
    exit('<!doctype html><html ' . theme_html_attrs() . '><meta charset="utf-8"><title>'
        . e(t('installed_title')) . '</title>'
        . '<link rel="stylesheet" href="assets/pref.css">'
        . theme_head_css()
        . '<body style="font-family:sans-serif;padding:40px;line-height:1.8;background:var(--bg);color:var(--text)">'
        . '<h2>' . e(t('installed_title')) . '</h2><p>' . e(t('installed_tip')) . '</p>'
        . '<p><a href="index.php">' . e(t('home')) . '</a> · <a href="admin/index.php">' . e(t('admin_panel')) . '</a></p></body></html>');
}

$step = isset($_REQUEST['step']) ? (int)$_REQUEST['step'] : 1;
if ($step < 1 || $step > 4) {
    $step = 1;
}
$sess = &$_SESSION['install'];
if (!is_array($sess)) {
    $sess = array();
}

$error = '';

/* ---------------- 环境检测 ---------------- */
function env_checks()
{
    $checks = array();
    $checks[] = array('name' => 'PHP 版本 ≥ 7.2', 'ok' => version_compare(PHP_VERSION, '7.2.0', '>='), 'val' => PHP_VERSION);
    $checks[] = array('name' => 'PDO 扩展（数据库存储需要）', 'ok' => extension_loaded('pdo'), 'val' => extension_loaded('pdo') ? '已加载' : '未加载');
    $checks[] = array('name' => 'PDO MySQL 驱动', 'ok' => extension_loaded('pdo_mysql'), 'val' => extension_loaded('pdo_mysql') ? '已加载' : '未加载（可用 SQLite 或文件存储）');
    $checks[] = array('name' => 'PDO SQLite 驱动', 'ok' => extension_loaded('pdo_sqlite'), 'val' => extension_loaded('pdo_sqlite') ? '已加载' : '未加载');
    $checks[] = array('name' => 'JSON 扩展', 'ok' => extension_loaded('json'), 'val' => extension_loaded('json') ? '已加载' : '未加载');
    $checks[] = array('name' => 'mbstring 扩展（推荐）', 'ok' => extension_loaded('mbstring'), 'val' => extension_loaded('mbstring') ? '已加载' : '未加载（不影响使用）');
    $checks[] = array('name' => '目录可写：config/', 'ok' => dir_writable(CONFIG_DIR), 'val' => dir_writable(CONFIG_DIR) ? '可写' : '不可写');
    $checks[] = array('name' => '目录可写：data/', 'ok' => dir_writable(DATA_DIR), 'val' => dir_writable(DATA_DIR) ? '可写' : '不可写');
    $checks[] = array('name' => '目录可写：data/uploads/', 'ok' => dir_writable(UPLOAD_DIR), 'val' => dir_writable(UPLOAD_DIR) ? '可写' : '不可写');
    return $checks;
}

/* ---------------- Step 2：存储方式 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 2) {
    csrf_check();
    $driver = isset($_POST['storage_driver']) && $_POST['storage_driver'] === 'db' ? 'db' : 'file';
    $scfg = array('driver' => $driver);
    $dbcfg = array();
    if ($driver === 'file') {
        $format = isset($_POST['file_format']) ? $_POST['file_format'] : 'json';
        if (!isset(FileStore::$formats[$format])) {
            $format = 'json';
        }
        $dir = isset($_POST['file_dir']) ? trim($_POST['file_dir']) : '';
        $dir = $dir === '' ? DATA_DIR : $dir;
        $scfg['format'] = $format;
        $scfg['dir'] = $dir;
    } else {
        $dbdriver = (isset($_POST['db_driver']) && $_POST['db_driver'] === 'sqlite') ? 'sqlite' : 'mysql';
        $dbcfg = array(
            'driver' => $dbdriver,
            'prefix' => preg_replace('/[^A-Za-z0-9_]/', '', isset($_POST['db_prefix']) ? trim($_POST['db_prefix']) : 'pr_'),
        );
        if ($dbdriver === 'sqlite') {
            $dbcfg['file'] = trim(isset($_POST['sqlite_file']) ? $_POST['sqlite_file'] : '') ?: (DATA_DIR . '/resume.db');
        } else {
            $dbcfg['host'] = trim(isset($_POST['db_host']) ? $_POST['db_host'] : 'localhost');
            $dbcfg['port'] = (int)(isset($_POST['db_port']) ? $_POST['db_port'] : 3306);
            $dbcfg['name'] = trim(isset($_POST['db_name']) ? $_POST['db_name'] : '');
            $dbcfg['user'] = trim(isset($_POST['db_user']) ? $_POST['db_user'] : '');
            $dbcfg['pass'] = isset($_POST['db_pass']) ? $_POST['db_pass'] : '';
            if ($dbcfg['name'] === '') {
                $error = '请填写数据库名 / Please enter the database name';
            }
        }
    }
    if (!$error) {
        list($ok, $msg) = StorageFactory::test($scfg, $dbcfg);
        if (!$ok) {
            $error = '存储配置测试失败：' . $msg;
        } else {
            $sess['storage'] = $scfg;
            $sess['db'] = $dbcfg;
            $sess['test_msg'] = $msg;
            redirect('install.php?step=3');
        }
    }
}

/* ---------------- Step 3：管理员与初始资料 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 3) {
    csrf_check();
    $user = trim(isset($_POST['admin_user']) ? $_POST['admin_user'] : '');
    $pass = isset($_POST['admin_pass']) ? $_POST['admin_pass'] : '';
    $pass2 = isset($_POST['admin_pass2']) ? $_POST['admin_pass2'] : '';
    $realname = trim(isset($_POST['realname']) ? $_POST['realname'] : '');
    $jobtitle = trim(isset($_POST['jobtitle']) ? $_POST['jobtitle'] : '');
    $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $homeTpl = isset($_POST['home_template']) ? $_POST['home_template'] : 'home_modern';
    $resumeTpl = isset($_POST['resume_template']) ? $_POST['resume_template'] : 'resume_classic';
    $lang = isset($_POST['language']) ? $_POST['language'] : 'zh';
    $mode = isset($_POST['default_mode']) ? $_POST['default_mode'] : 'auto';
    $panel = isset($_POST['theme_panel']) ? $_POST['theme_panel'] : 'azure';
    $color = trim(isset($_POST['theme_color']) ? $_POST['theme_color'] : '');
    if (!isset(theme_panels()[$panel])) {
        $panel = 'azure';
    }
    if ($color === '') {
        $color = theme_panels()[$panel]['primary'];
    }

    if ($user === '' || strlen($user) < 3) {
        $error = current_lang() === 'en' ? 'Username must be at least 3 characters' : '管理员用户名至少 3 个字符';
    } elseif (strlen($pass) < 6) {
        $error = current_lang() === 'en' ? 'Password must be at least 6 characters' : '管理员密码至少 6 位';
    } elseif ($pass !== $pass2) {
        $error = current_lang() === 'en' ? 'Passwords do not match' : '两次输入的密码不一致';
    } elseif ($realname === '') {
        $error = current_lang() === 'en' ? 'Please enter your name' : '请填写姓名（用于生成初始简历内容）';
    }
    if (!$error) {
        $cfg = array(
            'installed'  => true,
            'version'    => APP_VERSION,
            'installed_at' => date('Y-m-d H:i:s'),
            'storage'    => $sess['storage'],
            'db'         => $sess['db'],
            'admin'      => array('user' => $user, 'hash' => password_hash($pass, PASSWORD_DEFAULT)),
        );
        if (!save_config($cfg)) {
            $error = '写入配置文件失败，请检查 config/ 目录权限';
        } else {
            try {
                if ($sess['storage']['driver'] === 'db') {
                    db_create_table($sess['db']);
                    $store = new DbStore($sess['db']);
                } else {
                    $store = new FileStore($sess['storage']['dir'], $sess['storage']['format']);
                }
                $profile = default_profile();
                $profile['basic']['name'] = $realname;
                $profile['basic']['title'] = $jobtitle !== '' ? $jobtitle : $profile['basic']['title'];
                $profile['basic']['email'] = $email !== '' ? $email : $profile['basic']['email'];
                $profile['updated_at'] = date('Y-m-d H:i:s');
                $store->set('profile', $profile);

                $settings = default_settings();
                $settings['site_title'] = $realname . '的个人主页';
                $settings['meta_description'] = $realname . ' · ' . $profile['basic']['title'];
                $settings['home_template'] = valid_template($homeTpl, 'home');
                $settings['resume_template'] = valid_template($resumeTpl, 'resume');
                $settings['language'] = isset(lang_list()[$lang]) ? $lang : 'zh';
                $settings['default_mode'] = in_array($mode, array('light', 'dark', 'auto'), true) ? $mode : 'auto';
                $settings['theme_panel'] = $panel;
                $settings['theme_color'] = preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color)
                    ? $color : theme_panels()[$panel]['primary'];
                $store->set('settings', $settings);

                // 目录保护（Apache）
                foreach (array(CONFIG_DIR, DATA_DIR) as $d) {
                    $ht = $d . '/.htaccess';
                    if (!is_file($ht)) {
                        @file_put_contents($ht, "# 禁止直接访问\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
                    }
                }
                @file_put_contents(LOCK_FILE, date('Y-m-d H:i:s'));
                set_lang($settings['language']);
                $_SESSION['install_done'] = true;
                unset($_SESSION['install']);
                redirect('install.php?step=4');
            } catch (Exception $ex) {
                $error = '初始化数据失败：' . $ex->getMessage();
            }
        }
    }
}

/* ---------------- 渲染 ---------------- */
if ($step === 4 && empty($_SESSION['install_done'])) {
    redirect('install.php');
}
$checks = env_checks();
$hardOk = true;
foreach ($checks as $c) {
    if (in_array($c['name'], array('PHP 版本 ≥ 7.2', 'JSON 扩展', '目录可写：config/', '目录可写：data/'), true) && !$c['ok']) {
        $hardOk = false;
    }
}
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= te('install_title') ?></title>
    <link rel="stylesheet" href="assets/pref.css">
    <?= theme_head_css() ?>
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="install-wrap">
    <div class="logo">
        <h1><?= t('install_title') ?></h1>
        <p><?= e(t('install_sub')) ?> &nbsp;v<?= e(APP_VERSION) ?></p>
    </div>

    <div class="steps">
        <div class="<?= $step >= 1 ? ($step > 1 ? 'done' : 'on') : '' ?>"><?= e(t('step_env')) ?></div>
        <div class="<?= $step >= 2 ? ($step > 2 ? 'done' : 'on') : '' ?>"><?= e(t('step_storage')) ?></div>
        <div class="<?= $step >= 3 ? ($step > 3 ? 'done' : 'on') : '' ?>"><?= e(t('step_account')) ?></div>
        <div class="<?= $step === 4 ? 'on' : '' ?>"><?= e(t('step_done')) ?></div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= icon('shield') ?><span><?= e($error) ?></span></div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
        <div class="card">
            <h3><?= icon('check') ?><?= te('env_check') ?></h3>
            <ul class="check">
                <?php foreach ($checks as $c): ?>
                    <li>
                        <span><?= e($c['name']) ?></span>
                        <span>
                            <span class="<?= $c['ok'] ? 'ok' : 'bad' ?>"><?= $c['ok'] ? te('passed') : te('failed') ?></span>
                            <span class="muted" style="margin-left:8px"><?= e($c['val']) ?></span>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p class="muted" style="margin-top:14px"><?= te('no_db_tip') ?></p>
            <div style="margin-top:18px">
                <?php if ($hardOk): ?>
                    <a class="btn" href="install.php?step=2"><?= icon('arrow-left', array('style' => 'transform:rotate(180deg)')) ?><?= e(t('next_step')) ?></a>
                <?php else: ?>
                    <button class="btn btn-gray" disabled><?= e(t('fix_red_items')) ?></button>
                <?php endif; ?>
            </div>
        </div>

    <?php elseif ($step === 2): ?>
        <div class="card">
            <h3><?= icon('database') ?><?= te('storage') ?></h3>
            <form method="post" action="install.php?step=2">
                <?= csrf_field() ?>
                <label class="radio-card">
                    <input type="radio" name="storage_driver" value="file" checked>
                    <span class="rc-title"><?= icon('folder') ?><?= te('file_storage') ?></span>
                    <div class="rc-desc"><?= te('file_storage_desc') ?></div>
                </label>
                <div class="sub-box" data-driver-box="file">
                    <div class="form-row">
                        <div class="f f-3">
                            <label>文件格式</label>
                            <select name="file_format">
                                <?php foreach (FileStore::$formats as $k => $v): ?>
                                    <option value="<?= e($k) ?>"><?= e($v) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="f f-3">
                            <label>数据目录（绝对路径，留空用默认 data/）</label>
                            <input type="text" name="file_dir" placeholder="<?= e(DATA_DIR) ?>">
                        </div>
                    </div>
                    <p class="muted"><?= te('file_format_tip') ?></p>
                </div>

                <label class="radio-card">
                    <input type="radio" name="storage_driver" value="db">
                    <span class="rc-title"><?= icon('database') ?><?= te('db_storage') ?></span>
                    <div class="rc-desc"><?= te('db_storage_desc') ?></div>
                </label>
                <div class="sub-box" data-driver-box="db" style="display:none">
                    <div class="form-row">
                        <div class="f f-3">
                            <label>数据库类型</label>
                            <select name="db_driver" id="db_driver">
                                <option value="mysql">MySQL / MariaDB</option>
                                <option value="sqlite">SQLite（单文件，免安装）</option>
                            </select>
                        </div>
                        <div class="f f-1"><label>表前缀</label><input type="text" name="db_prefix" value="pr_"></div>
                    </div>
                    <div id="mysql-box">
                        <div class="form-row">
                            <div class="f f-2"><label>主机</label><input type="text" name="db_host" value="localhost"></div>
                            <div class="f f-1"><label>端口</label><input type="text" name="db_port" value="3306"></div>
                            <div class="f f-2"><label>数据库名</label><input type="text" name="db_name" placeholder="resume"></div>
                            <div class="f f-1"><label>用户名</label><input type="text" name="db_user" placeholder="root"></div>
                            <div class="f f-2"><label>密码</label><input type="password" name="db_pass" placeholder="数据库密码"></div>
                        </div>
                        <p class="muted"><?= te('mysql_tip') ?></p>
                    </div>
                    <div id="sqlite-box" style="display:none">
                        <div class="f"><label>SQLite 数据库文件路径</label>
                            <input type="text" name="sqlite_file" value="<?= e(DATA_DIR . '/resume.db') ?>"></div>
                        <p class="muted"><?= te('sqlite_tip') ?></p>
                    </div>
                </div>

                <div style="margin-top:18px">
                    <a class="btn btn-line" href="install.php?step=1"><?= e(t('prev_step')) ?></a>
                    <button class="btn" type="submit"><?= e(t('next_step')) ?></button>
                </div>
            </form>
        </div>

    <?php elseif ($step === 3): ?>
        <div class="card">
            <h3><?= icon('user') ?><?= te('account_section') ?></h3>
            <div class="alert alert-info"><?= icon('database') ?><span><?= te('storage') ?>：<?= e(isset($sess['test_msg']) ? $sess['test_msg'] : '') ?></span></div>
            <form method="post" action="install.php?step=3">
                <?= csrf_field() ?>
                <div class="form-row">
                    <div class="f f-1"><label><?= te('username') ?></label><input type="text" name="admin_user" value="admin" required></div>
                    <div class="f f-1"><label><?= te('password') ?>（≥6 位）</label><input type="password" name="admin_pass" required></div>
                    <div class="f f-1"><label><?= te('confirm_password') ?></label><input type="password" name="admin_pass2" required></div>
                    <div class="f f-1"><label><?= te('f_name') ?></label><input type="text" name="realname" placeholder="张三" required></div>
                    <div class="f f-1"><label><?= te('f_title') ?></label><input type="text" name="jobtitle" placeholder="全栈开发工程师"></div>
                    <div class="f f-1"><label><?= te('email') ?></label><input type="text" name="email" placeholder="me@example.com"></div>
                    <div class="f f-1"><label><?= te('default_lang') ?></label>
                        <select name="language">
                            <?php foreach (lang_list() as $code => $name): ?>
                                <option value="<?= e($code) ?>" <?= current_lang() === $code ? 'selected' : '' ?>><?= e($name) ?></option>
                            <?php endforeach; ?>
                        </select></div>
                    <div class="f f-1"><label><?= te('default_mode') ?></label>
                        <select name="default_mode">
                            <option value="auto"><?= te('mode_auto') ?></option>
                            <option value="light"><?= te('mode_light') ?></option>
                            <option value="dark"><?= te('mode_dark') ?></option>
                        </select></div>
                    <div class="f f-1"><label><?= te('panel_default') ?></label>
                        <select name="theme_panel" id="inst-panel">
                            <?php foreach (theme_panels() as $k => $p): ?>
                                <option value="<?= e($k) ?>"><?= e($p[current_lang()] ?? $p['zh']) ?></option>
                            <?php endforeach; ?>
                        </select></div>
                    <div class="f f-1"><label><?= te('theme_color') ?></label>
                        <input type="text" name="theme_color" id="inst-color" value="#2563eb" placeholder="#2563eb"></div>
                    <div class="f f-3"><label><?= te('home_tpl') ?></label>
                        <select name="home_template">
                            <?php foreach (template_list('home') as $k => $t): ?>
                                <option value="<?= e($k) ?>"><?= e($t['name']) ?> —— <?= e($t['desc']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="f f-3"><label><?= te('resume_tpl') ?></label>
                        <select name="resume_template">
                            <?php foreach (template_list('resume') as $k => $t): ?>
                                <option value="<?= e($k) ?>"><?= e($t['name']) ?> —— <?= e($t['desc']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div style="margin-top:18px">
                    <a class="btn btn-line" href="install.php?step=2"><?= e(t('prev_step')) ?></a>
                    <button class="btn" type="submit"><?= icon('check') ?><?= te('install_now') ?></button>
                </div>
            </form>
        </div>

    <?php else: ?>
        <div class="card">
            <h3><?= icon('check') ?>🎉 <?= e(t('step_done')) ?></h3>
            <p style="margin:16px 0">
                <a class="btn" href="admin/index.php"><?= icon('sliders') ?><?= te('admin_panel') ?></a>
                <a class="btn btn-line" href="index.php" target="_blank"><?= icon('globe') ?><?= te('home') ?></a>
                <a class="btn btn-line" href="resume.php" target="_blank"><?= icon('print') ?><?= te('resume') ?></a>
            </p>
            <div class="alert alert-error" style="margin-top:16px">
                <?= icon('shield') ?><span><?= te('del_install') ?></span>
            </div>
            <table class="info">
                <tr><th><?= te('time') ?></th><td><?= e(date('Y-m-d H:i:s')) ?></td></tr>
                <tr><th><?= te('storage') ?></th><td><?= e(storage()->label()) ?></td></tr>
                <tr><th><?= te('default_lang') ?></th><td><?= e(lang_name(current_lang())) ?></td></tr>
                <tr><th><?= te('panel_default') ?></th><td><?= e(panel_name(theme_panel())) ?></td></tr>
                <tr><th>Config</th><td><code>config/config.php</code></td></tr>
            </table>
        </div>
    <?php endif; ?>
</div>
<?= theme_assets() ?>
<script>
    var ip = document.getElementById('inst-panel'), ic = document.getElementById('inst-color');
    if (ip && ic) {
        var colors = <?= json_encode(array_map(function ($p) { return $p['primary']; }, theme_panels())) ?>;
        ip.addEventListener('change', function () { ic.value = colors[ip.value] || '#2563eb'; });
    }
    var sel = document.getElementById('db_driver');
    if (sel) {
        sel.addEventListener('change', function () {
            document.getElementById('mysql-box').style.display = sel.value === 'mysql' ? 'block' : 'none';
            document.getElementById('sqlite-box').style.display = sel.value === 'sqlite' ? 'block' : 'none';
        });
    }
</script>
</body>
</html>
