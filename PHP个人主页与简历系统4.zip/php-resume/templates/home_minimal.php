<?php
/**
 * 模板：极简白（个人主页）
 */
$primary = theme_color();
$avatar = avatar_url($profile);
$b = $profile['basic'];
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($settings['site_title'] ?: $b['name']) ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text); font-size: 15.5px; line-height: 1.85;
            font-family: Georgia, "Songti SC", "Source Han Serif SC", "Times New Roman", serif;
        }
        a { color: inherit; border-bottom: 1px solid var(--border); }
        a:hover { color: var(--primary); border-bottom-color: var(--primary); }
        .wrap { max-width: 720px; margin: 0 auto; padding: 70px 22px 60px; }
        header { text-align: center; margin-bottom: 46px; }
        .avatar { width: 92px; height: 92px; border-radius: 50%; object-fit: cover; margin-bottom: 14px; }
        h1 { font-size: 32px; margin: 0 0 6px; letter-spacing: 2px; font-weight: 500; }
        .role { color: var(--text-2); letter-spacing: 1px; font-size: 14.5px; margin-bottom: 18px; }
        .meta { font-size: 13.5px; color: var(--text-2); display: flex; flex-wrap: wrap; justify-content: center; gap: 4px; }
        .meta span { margin: 0 8px; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px; }
        .meta a { border-bottom: 0; }
        .intro { margin: 22px auto 0; max-width: 560px; text-align: left; color: var(--text-2); }
        section { margin-bottom: 38px; }
        h2 {
            font-size: 15px; letter-spacing: 3px; text-transform: uppercase; color: var(--text-2);
            font-weight: 500; border-bottom: 1px solid var(--border); padding-bottom: 8px; margin: 0 0 20px;
            display: flex; align-items: center; gap: 8px;
        }
        h2 svg { color: var(--primary); }
        .item { margin-bottom: 18px; }
        .item-head { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; align-items: baseline; }
        .t1 { font-size: 16.5px; font-weight: 600; }
        .t2 { color: var(--primary); font-size: 14px; margin-left: 8px; }
        .date { color: var(--text-3); font-size: 13px; }
        .desc { color: var(--text-2); font-size: 14.5px; margin-top: 4px; }
        .desc ul { margin: 4px 0 0; padding-left: 20px; }
        .skill-line { display: flex; justify-content: space-between; border-bottom: 1px dotted var(--border); padding: 5px 0; font-size: 14.5px; }
        .bar { height: 3px; background: var(--text); margin-top: 4px; }
        footer { text-align: center; color: var(--text-3); font-size: 13px; border-top: 1px solid var(--border); padding-top: 20px; }
        footer a { border-bottom: 0; color: var(--primary); }
        @media (max-width: 640px) { .wrap { padding: 50px 18px; } h1 { font-size: 26px; } }
    </style>
</head>
<body>
<div class="wrap">
    <header>
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt=""><?php endif; ?>
        <h1><?= e($b['name']) ?></h1>
        <div class="role"><?= e($b['title']) ?></div>
        <div class="meta">
            <?php if (!empty($b['email'])): ?><span><?= icon('mail') ?><?= e($b['email']) ?></span><?php endif; ?>
            <?php if (!empty($b['phone'])): ?><span><?= icon('phone') ?><?= e($b['phone']) ?></span><?php endif; ?>
            <?php if (!empty($b['location'])): ?><span><?= icon('pin') ?><?= e($b['location']) ?></span><?php endif; ?>
            <?php if (!empty($b['website'])): ?><span><a href="<?= e($b['website']) ?>" target="_blank"><?= icon('link') ?><?= t('website') ?></a></span><?php endif; ?>
            <?php foreach ($socials as $s): ?>
                <span><?= icon($s['icon']) ?><?php if ($s['url']): ?><a href="<?= e($s['url']) ?>" target="_blank"><?= e($s['label']) ?></a><?php else: ?><?= e($s['label']) ?>：<?= e($s['value']) ?><?php endif; ?></span>
            <?php endforeach; ?>
        </div>
        <?php if (!empty($b['intro'])): ?><div class="intro"><?= tpl_ml($b['intro']) ?></div><?php endif; ?>
    </header>

    <?php if (!empty($profile['experiences'])): ?>
        <section>
            <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
            <?php foreach ($profile['experiences'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['company'] ?? '') ?></span><?php if (!empty($it['position'])): ?><span class="t2"><?= e($it['position']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <div class="desc"><?php if (count($lines) > 1): ?><ul><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul><?php else: ?><?= tpl_ml($it['desc']) ?><?php endif; ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['projects'])): ?>
        <section>
            <h2><?= icon('folder') ?><?= te('projects') ?></h2>
            <?php foreach ($profile['projects'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['name'] ?? '') ?></a><?php else: ?><?= e($it['name'] ?? '') ?><?php endif; ?></span>
                            <?php if (!empty($it['role'])): ?><span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['tech'])): ?><div class="desc"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['educations'])): ?>
        <section>
            <h2><?= icon('school') ?><?= te('education') ?></h2>
            <?php foreach ($profile['educations'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['school'] ?? '') ?></span><?php if (!empty($it['major'])): ?><span class="t2"><?= e($it['major']) ?></span><?php endif; ?>
                            <?php if (!empty($it['degree'])): ?><span class="date"> · <?= e($it['degree']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['skills'])): ?>
        <section>
            <h2><?= icon('star') ?><?= te('skills') ?></h2>
            <?php foreach ($profile['skills'] as $it): ?>
                <div class="skill-line"><span><?= e($it['name'] ?? '') ?></span><span class="date"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                <div class="bar" style="width:<?= max(2, min(100, (int)($it['level'] ?? 0))) ?>%"></div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['certs'])): ?>
        <section>
            <h2><?= icon('award') ?><?= te('certificates') ?></h2>
            <?php foreach ($profile['certs'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['issuer'])): ?><span class="t2"><?= e($it['issuer']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= e($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['portfolio'])): ?>
        <section>
            <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
            <?php foreach ($profile['portfolio'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['title'] ?? '') ?></a><?php else: ?><?= e($it['title'] ?? '') ?><?php endif; ?></span></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= e($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['custom_items'])): ?>
        <section>
            <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
            <?php foreach ($profile['custom_items'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['title'] ?? '') ?></span></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <footer>
        <?php if (!empty($settings['show_resume'])): ?><p><a href="resume.php"><?= icon('print') ?> <?= te('online_resume') ?></a></p><?php endif; ?>
        <p><?= e($settings['footer_text']) ?></p>
    </footer>
</div>
<?= theme_assets() ?>
</body>
</html>
