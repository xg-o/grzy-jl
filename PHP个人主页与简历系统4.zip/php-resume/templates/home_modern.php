<?php
/**
 * 模板：现代渐变（个人主页）
 */
$primary = theme_color();
$avatar = avatar_url($profile);
$b = $profile['basic'];
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($settings['site_title'] ?: $b['name']) ?></title>
    <meta name="keywords" content="<?= e($settings['meta_keywords']) ?>">
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; font-size: 15px; line-height: 1.75; color: var(--text);
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
            background: var(--bg);
        }
        a { color: var(--primary); text-decoration: none; }
        .wrap { max-width: 880px; margin: 0 auto; padding: 0 20px 60px; }
        .hero {
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: #fff; padding: 58px 20px 48px; margin-bottom: 34px;
            position: relative; overflow: hidden;
        }
        .hero:after {
            content: ""; position: absolute; right: -80px; top: -80px; width: 320px; height: 320px;
            background: rgba(255,255,255,.12); border-radius: 50%;
        }
        .hero-inner { max-width: 880px; margin: 0 auto; display: flex; gap: 26px; align-items: center; position: relative; }
        .avatar { width: 108px; height: 108px; border-radius: 50%; object-fit: cover; border: 3px solid rgba(255,255,255,.85); flex: none; background: rgba(255,255,255,.2); }
        .hero h1 { margin: 0 0 6px; font-size: 30px; letter-spacing: .5px; }
        .hero .role { font-size: 16px; opacity: .92; margin-bottom: 12px; }
        .hero .intro { font-size: 14.5px; opacity: .9; max-width: 620px; }
        .contacts { margin-top: 16px; display: flex; flex-wrap: wrap; gap: 8px; }
        .contacts span {
            background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.25);
            padding: 4px 12px; border-radius: 999px; font-size: 13px;
            display: inline-flex; align-items: center; gap: 5px;
        }
        section { background: var(--panel); border-radius: 14px; padding: 26px 28px; margin-bottom: 20px; box-shadow: var(--shadow); }
        section h2 { margin: 0 0 18px; font-size: 19px; display: flex; align-items: center; gap: 9px; color: var(--text); }
        section h2 svg { color: var(--primary); }
        .item { padding: 14px 0; border-bottom: 1px dashed var(--border-2); }
        .item:last-child { border-bottom: 0; padding-bottom: 0; }
        .item-head { display: flex; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
        .item-title { font-weight: 600; font-size: 16px; }
        .item-sub { color: var(--primary); font-size: 14px; }
        .item-date { color: var(--text-3); font-size: 13px; white-space: nowrap; }
        .item-desc { color: var(--text-2); font-size: 14.5px; margin-top: 6px; }
        .item-desc ul { margin: 6px 0 0; padding-left: 18px; }
        .skills { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px 24px; }
        .skill-name { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 5px; }
        .bar { height: 7px; background: var(--chip); border-radius: 4px; overflow: hidden; }
        .bar i { display: block; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); border-radius: 4px; }
        .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 16px; }
        .card-x { border: 1px solid var(--border-2); border-radius: 10px; overflow: hidden; }
        .card-x img { width: 100%; height: 140px; object-fit: cover; display: block; background: var(--chip); }
        .card-x .body { padding: 12px 14px; }
        .card-x h4 { margin: 0 0 4px; font-size: 15px; }
        .card-x p { margin: 0; font-size: 13.5px; color: var(--text-2); }
        footer { text-align: center; color: var(--text-3); font-size: 13px; padding: 26px 0 0; }
        footer a { color: var(--text-2); }
        footer a:hover { color: var(--primary); }
        @media (max-width: 640px) {
            .hero { padding: 44px 18px 30px; }
            .hero-inner { flex-direction: column; text-align: center; }
            .contacts { justify-content: center; }
            section { padding: 20px 18px; }
        }
    </style>
</head>
<body>
<header class="hero">
    <div class="hero-inner">
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt="<?= e($b['name']) ?>"><?php endif; ?>
        <div>
            <h1><?= e($b['name']) ?></h1>
            <div class="role"><?= e($b['title']) ?></div>
            <?php if (!empty($b['intro'])): ?><div class="intro"><?= tpl_ml($b['intro']) ?></div><?php endif; ?>
            <div class="contacts">
                <?php if (!empty($b['email'])): ?><span><?= icon('mail') ?><?= e($b['email']) ?></span><?php endif; ?>
                <?php if (!empty($b['phone'])): ?><span><?= icon('phone') ?><?= e($b['phone']) ?></span><?php endif; ?>
                <?php if (!empty($b['location'])): ?><span><?= icon('pin') ?><?= e($b['location']) ?></span><?php endif; ?>
                <?php if (!empty($b['website'])): ?><span><a style="color:#fff" href="<?= e($b['website']) ?>" target="_blank"><?= icon('link') ?><?= t('website_label') ?></a></span><?php endif; ?>
                <?php foreach ($socials as $s): ?>
                    <span><?= icon($s['icon']) ?><?php if ($s['url']): ?><a style="color:#fff" href="<?= e($s['url']) ?>" target="_blank"><?= e($s['value']) ?></a><?php else: ?><?= e($s['label']) ?>：<?= e($s['value']) ?><?php endif; ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</header>

<div class="wrap">
    <?php if (!empty($profile['experiences'])): ?>
        <section>
            <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
            <?php foreach ($profile['experiences'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div>
                            <span class="item-title"><?= e($it['company'] ?? '') ?></span>
                            <?php if (!empty($it['position'])): ?><span class="item-sub"> · <?= e($it['position']) ?></span><?php endif; ?>
                            <?php if (!empty($it['location'])): ?><span class="item-date"> · <?= e($it['location']) ?></span><?php endif; ?>
                        </div>
                        <div class="item-date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?>
                        <div class="item-desc">
                            <?php $lines = tpl_lines($it['desc']); ?>
                            <?php if (count($lines) > 1): ?>
                                <ul><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                            <?php else: ?><?= tpl_ml($it['desc']) ?><?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['projects'])): ?>
        <section>
            <h2><?= icon('folder') ?><?= te('projects') ?></h2>
            <?php foreach ($profile['projects'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div>
                            <span class="item-title"><?= e($it['name'] ?? '') ?></span>
                            <?php if (!empty($it['role'])): ?><span class="item-sub"> · <?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?>
                            <?php if (!empty($it['link'])): ?> · <a href="<?= e($it['link']) ?>" target="_blank"><?= icon('link') ?></a><?php endif; ?>
                        </div>
                        <div class="item-date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['tech'])): ?><div class="item-desc"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                    <?php if (!empty($it['desc'])): ?><div class="item-desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['skills'])): ?>
        <section>
            <h2><?= icon('star') ?><?= te('skills') ?></h2>
            <div class="skills">
                <?php foreach ($profile['skills'] as $it): ?>
                    <div>
                        <div class="skill-name"><span><?= e($it['name'] ?? '') ?></span><span class="item-date"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                        <div class="bar"><i style="width:<?= max(0, min(100, (int)($it['level'] ?? 0))) ?>%"></i></div>
                        <?php if (!empty($it['desc'])): ?><div class="item-desc" style="font-size:13px"><?= e($it['desc']) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['educations'])): ?>
        <section>
            <h2><?= icon('school') ?><?= te('education') ?></h2>
            <?php foreach ($profile['educations'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="item-title"><?= e($it['school'] ?? '') ?></span>
                            <?php if (!empty($it['major'])): ?><span class="item-sub"> · <?= e($it['major']) ?></span><?php endif; ?>
                            <?php if (!empty($it['degree'])): ?><span class="item-date"> · <?= e($it['degree']) ?></span><?php endif; ?>
                        </div>
                        <div class="item-date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="item-desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['certs'])): ?>
        <section>
            <h2><?= icon('award') ?><?= te('certificates') ?></h2>
            <?php foreach ($profile['certs'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="item-title"><?= e($it['name'] ?? '') ?></span>
                            <?php if (!empty($it['issuer'])): ?><span class="item-sub"> · <?= e($it['issuer']) ?></span><?php endif; ?></div>
                        <div class="item-date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="item-desc"><?= e($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['portfolio'])): ?>
        <section>
            <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
            <div class="cards">
                <?php foreach ($profile['portfolio'] as $it): ?>
                    <div class="card-x">
                        <?php if (!empty($it['image'])): ?><img src="<?= e($it['image']) ?>" alt="<?= e($it['title'] ?? '') ?>"><?php endif; ?>
                        <div class="body">
                            <h4><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['title'] ?? '') ?></a><?php else: ?><?= e($it['title'] ?? '') ?><?php endif; ?></h4>
                            <?php if (!empty($it['desc'])): ?><p><?= e($it['desc']) ?></p><?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['custom_items'])): ?>
        <section>
            <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
            <?php foreach ($profile['custom_items'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="item-title"><?= e($it['title'] ?? '') ?></span></div>
                        <div class="item-date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="item-desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <footer>
        <?php if (!empty($settings['show_resume'])): ?>
            <p><a href="resume.php"><?= icon('print') ?> <?= te('view_resume') ?></a></p>
        <?php endif; ?>
        <p><?= e($settings['footer_text']) ?><?php if (!empty($settings['icp'])): ?> · <a href="https://beian.miit.gov.cn" target="_blank"><?= e($settings['icp']) ?></a><?php endif; ?></p>
    </footer>
</div>
<?= theme_assets() ?>
</body>
</html>
