<?php
/**
 * 模板：经典黑白简历（A4 打印友好）
 */
$isPreview = is_admin() && !empty($_GET['preview_tpl']);
$autoPrint = !empty($_GET['print']) && !$isPreview;
$b = $profile['basic'];
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($b['name']) ?> - <?= te('resume') ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.65;
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
        }
        a { color: var(--text); text-decoration: none; }
        .toolbar { position: fixed; right: 18px; bottom: 18px; display: flex; gap: 8px; z-index: 40; }
        .toolbar a, .toolbar button {
            background: var(--text); color: var(--bg); border: 0; padding: 9px 15px; border-radius: 6px;
            font-size: 13px; cursor: pointer; font-family: inherit; display: inline-flex; align-items: center; gap: 6px;
        }
        .toolbar a:hover, .toolbar button:hover { background: var(--primary); color: #fff; }
        .page {
            width: 210mm; min-height: 297mm; margin: 24px auto; background: var(--panel);
            color: var(--text); padding: 16mm 15mm; box-shadow: var(--shadow-lg);
        }
        .head { text-align: center; border-bottom: 2px solid var(--text); padding-bottom: 10px; margin-bottom: 16px; }
        .head h1 { font-size: 26px; margin: 0 0 4px; letter-spacing: 4px; }
        .head .role { font-size: 14px; color: var(--text-2); margin-bottom: 8px; }
        .head .contact { font-size: 12.5px; color: var(--text-2); display: flex; flex-wrap: wrap; justify-content: center; gap: 2px 4px; }
        .head .contact span { margin: 0 6px; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px; }
        h2 {
            font-size: 15px; margin: 18px 0 8px; padding-bottom: 4px;
            border-bottom: 1px solid var(--text); letter-spacing: 2px;
            display: flex; align-items: center; gap: 7px;
        }
        table.exp { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
        table.exp td { vertical-align: top; padding: 3px 0; }
        table.exp td.date { width: 34mm; color: var(--text-2); font-size: 12.5px; }
        .t1 { font-weight: 700; font-size: 14.5px; }
        .t2 { color: var(--text-2); font-size: 13px; margin-left: 6px; }
        ul.pts { margin: 4px 0 0; padding-left: 18px; font-size: 13.5px; color: var(--text-2); }
        ul.pts li { margin-bottom: 2px; }
        .skill-item { display: flex; justify-content: space-between; font-size: 13.5px; border-bottom: 1px dotted var(--border); padding: 2px 0; }
        .two { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 20px; }
        .summary { font-size: 13.5px; margin: 6px 0 0; color: var(--text-2); }
        @page { size: A4; margin: 12mm; }
        @media print {
            html, html.dark, html.light, html.auto-mode {
                --bg: #fff; --panel: #fff; --panel-2: #fff;
                --text: #111; --text-2: #333; --text-3: #555;
                --border: #999; --border-2: #ccc; --chip: #f2f2f2; --shadow: none; --shadow-lg: none;
                color-scheme: light;
            }
            body { background: #fff; }
            .toolbar { display: none; }
            .page { margin: 0; box-shadow: none; width: auto; min-height: auto; padding: 0; }
            a { color: #111; }
        }
        @media (max-width: 820px) { .page { width: auto; min-height: auto; margin: 12px; padding: 22px 16px; } }
    </style>
</head>
<body>
<?php if (!$isPreview): ?>
    <div class="toolbar">
        <button onclick="window.print()"><?= icon('print') ?><?= te('print_pdf') ?></button>
        <a href="index.php"><?= icon('arrow-left') ?><?= te('back_home') ?></a>
    </div>
<?php endif; ?>

<div class="page">
    <div class="head">
        <h1><?= e($b['name']) ?></h1>
        <div class="role"><?= e($b['title']) ?></div>
        <div class="contact">
            <?php if (!empty($b['phone'])): ?><span><?= icon('phone') ?><?= e($b['phone']) ?></span><?php endif; ?>
            <?php if (!empty($b['email'])): ?><span><?= icon('mail') ?><?= e($b['email']) ?></span><?php endif; ?>
            <?php if (!empty($b['location'])): ?><span><?= icon('pin') ?><?= e($b['location']) ?></span><?php endif; ?>
            <?php if (!empty($b['birthday'])): ?><span><?= icon('cake') ?><?= e($b['birthday']) ?></span><?php endif; ?>
            <?php if (!empty($b['website'])): ?><span><?= icon('link') ?><a href="<?= e($b['website']) ?>" target="_blank"><?= e($b['website']) ?></a></span><?php endif; ?>
            <?php foreach ($socials as $s): ?><span><?= icon($s['icon']) ?><?= e($s['value']) ?></span><?php endforeach; ?>
        </div>
    </div>

    <?php if (!empty($b['objective'])): ?>
        <h2><?= icon('target') ?><?= te('objective') ?></h2>
        <div class="summary"><?= tpl_ml($b['objective']) ?></div>
    <?php endif; ?>

    <?php if (!empty($b['intro'])): ?>
        <h2><?= icon('user') ?><?= te('summary') ?></h2>
        <div class="summary"><?= tpl_ml($b['intro']) ?></div>
    <?php endif; ?>

    <?php if (!empty($profile['educations'])): ?>
        <h2><?= icon('school') ?><?= te('education') ?></h2>
        <?php foreach ($profile['educations'] as $it): ?>
            <table class="exp">
                <tr>
                    <td class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></td>
                    <td>
                        <span class="t1"><?= e($it['school'] ?? '') ?></span>
                        <?php if (!empty($it['major'])): ?><span class="t2"><?= e($it['major']) ?><?php if (!empty($it['degree'])): ?>（<?= e($it['degree']) ?>）<?php endif; ?></span><?php endif; ?>
                        <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                            <?php if (count($lines) > 1): ?>
                                <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                            <?php else: ?><div class="summary"><?= e($it['desc']) ?></div><?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($profile['experiences'])): ?>
        <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
        <?php foreach ($profile['experiences'] as $it): ?>
            <table class="exp">
                <tr>
                    <td class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></td>
                    <td>
                        <span class="t1"><?= e($it['company'] ?? '') ?></span>
                        <?php if (!empty($it['position'])): ?><span class="t2"><?= e($it['position']) ?></span><?php endif; ?>
                        <?php if (!empty($it['location'])): ?><span class="t2"><?= e($it['location']) ?></span><?php endif; ?>
                        <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                            <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($profile['projects'])): ?>
        <h2><?= icon('folder') ?><?= te('projects') ?></h2>
        <?php foreach ($profile['projects'] as $it): ?>
            <table class="exp">
                <tr>
                    <td class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></td>
                    <td>
                        <span class="t1"><?= e($it['name'] ?? '') ?></span>
                        <?php if (!empty($it['role'])): ?><span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?>
                        <?php if (!empty($it['tech'])): ?><div class="summary"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                        <?php if (!empty($it['link'])): ?><div class="summary"><?= te('project_link') ?>：<?= e($it['link']) ?></div><?php endif; ?>
                        <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                            <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($profile['skills'])): ?>
        <h2><?= icon('star') ?><?= te('skills') ?></h2>
        <div class="two">
            <?php foreach ($profile['skills'] as $it): ?>
                <div class="skill-item"><span><?= e($it['name'] ?? '') ?></span><span><?= (int)($it['level'] ?? 0) ?>%</span></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($profile['certs'])): ?>
        <h2><?= icon('award') ?><?= te('certificates') ?></h2>
        <ul class="pts">
            <?php foreach ($profile['certs'] as $it): ?>
                <li><?= e($it['date'] ?? '') ?>　<?= e($it['name'] ?? '') ?><?php if (!empty($it['issuer'])): ?>（<?= e($it['issuer']) ?>）<?php endif; ?><?php if (!empty($it['desc'])): ?>　<?= e($it['desc']) ?><?php endif; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!empty($profile['portfolio'])): ?>
        <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
        <ul class="pts">
            <?php foreach ($profile['portfolio'] as $it): ?>
                <li><?= e($it['title'] ?? '') ?><?php if (!empty($it['link'])): ?>　<?= e($it['link']) ?><?php endif; ?><?php if (!empty($it['desc'])): ?>　<?= e($it['desc']) ?><?php endif; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!empty($profile['custom_items'])): ?>
        <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
        <?php foreach ($profile['custom_items'] as $it): ?>
            <table class="exp">
                <tr>
                    <td class="date"><?= e($it['date'] ?? '') ?></td>
                    <td>
                        <span class="t1"><?= e($it['title'] ?? '') ?></span>
                        <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                            <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php if ($autoPrint): ?><script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 400); });</script><?php endif; ?>
<?= theme_assets() ?>
</body>
</html>
