<?php
/**
 * 模板：暗色科技（个人主页）—— 恒深色风格，明暗切换仅微调层次
 */
$primary = theme_color();
$avatar = avatar_url($profile);
$b = $profile['basic'];
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($settings['site_title'] ?: $b['name']) ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        /* 该模板恒定深色基线：定义在 body 上，优先级高于面板变量 */
        html { color-scheme: dark; }
        body {
            --bg: #0b1120; --panel: #121a2b; --panel-2: #0f172a;
            --text: #e2e8f0; --text-2: #94a3b8; --text-3: #64748b;
            --border: #1e293b; --border-2: #1a2436; --chip: rgba(255,255,255,.07);
            --shadow: 0 1px 3px rgba(0,0,0,.35); --shadow-lg: 0 8px 30px rgba(0,0,0,.45);
        }
        html.light { color-scheme: light; }
        html.light body {
            --bg: #eef2f8; --panel: #ffffff; --panel-2: #f6f8fc;
            --text: #1e293b; --text-2: #64748b; --text-3: #94a3b8;
            --border: #dbe3ef; --border-2: #e8edf6; --chip: #f1f5f9;
            --shadow: 0 1px 3px rgba(15,23,42,.08); --shadow-lg: 0 8px 30px rgba(15,23,42,.14);
        }
        @media (prefers-color-scheme: light) {
            html.auto-mode { color-scheme: light; }
            html.auto-mode body {
                --bg: #eef2f8; --panel: #ffffff; --panel-2: #f6f8fc;
                --text: #1e293b; --text-2: #64748b; --text-3: #94a3b8;
                --border: #dbe3ef; --border-2: #e8edf6; --chip: #f1f5f9;
                --shadow: 0 1px 3px rgba(15,23,42,.08); --shadow-lg: 0 8px 30px rgba(15,23,42,.14);
            }
        }
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text-2); font-size: 15px; line-height: 1.75;
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
            background-image: radial-gradient(1000px 500px at 20% -10%, var(--glow-2), transparent),
                              radial-gradient(800px 400px at 90% 10%, var(--glow), transparent);
        }
        a { color: var(--primary); text-decoration: none; }
        .wrap { max-width: 860px; margin: 0 auto; padding: 0 20px 60px; }
        header { padding: 64px 0 34px; display: flex; gap: 24px; align-items: center; flex-wrap: wrap; }
        .avatar { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary); box-shadow: 0 0 26px rgba(34,211,238,.22); }
        h1 { margin: 0 0 6px; font-size: 30px; color: var(--text); }
        .role { color: var(--primary); font-size: 15px; letter-spacing: 1px; margin-bottom: 12px; font-family: ui-monospace, Menlo, Consolas, monospace; }
        .intro { color: var(--text-2); max-width: 600px; }
        .chips { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
        .chip {
            border: 1px solid var(--border); background: var(--chip); color: var(--text-2);
            padding: 4px 12px; border-radius: 6px; font-size: 13px; font-family: ui-monospace, Menlo, monospace;
            display: inline-flex; align-items: center; gap: 5px;
        }
        section { background: var(--panel); border: 1px solid var(--border); border-radius: 12px; padding: 24px 26px; margin-bottom: 18px; box-shadow: var(--shadow); }
        h2 { margin: 0 0 16px; font-size: 16px; color: var(--text); display: flex; align-items: center; gap: 8px; }
        h2 svg { color: var(--primary); }
        .item { padding: 13px 0; border-bottom: 1px dashed var(--border); }
        .item:last-child { border-bottom: 0; }
        .item-head { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
        .t1 { color: var(--text); font-weight: 600; }
        .t2 { color: var(--primary); font-size: 14px; }
        .date { color: var(--text-3); font-size: 13px; font-family: ui-monospace, Menlo, monospace; }
        .desc { color: var(--text-2); font-size: 14px; margin-top: 5px; }
        .desc ul { margin: 4px 0 0; padding-left: 18px; }
        .skills { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 12px 22px; }
        .skill-name { display: flex; justify-content: space-between; font-size: 13.5px; margin-bottom: 4px; color: var(--text); }
        .bar { height: 6px; background: var(--chip); border-radius: 3px; overflow: hidden; }
        .bar i { display: block; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); }
        .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 14px; }
        .card-x { border: 1px solid var(--border); border-radius: 10px; overflow: hidden; background: var(--panel-2); }
        .card-x img { width: 100%; height: 130px; object-fit: cover; display: block; }
        .card-x .body { padding: 12px 14px; }
        .card-x h4 { margin: 0 0 4px; font-size: 15px; color: var(--text); }
        .card-x p { margin: 0; font-size: 13px; color: var(--text-2); }
        footer { text-align: center; color: var(--text-3); font-size: 13px; padding: 22px 0; }
        @media (max-width: 640px) { header { padding: 48px 0 24px; text-align: center; } .chips { justify-content: center; } section { padding: 20px 18px; } }
    </style>
</head>
<body>
<div class="wrap">
    <header>
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt=""><?php endif; ?>
        <div>
            <h1><?= e($b['name']) ?></h1>
            <div class="role">&lt;?= <?= e($b['title']) ?> ?&gt;</div>
            <?php if (!empty($b['intro'])): ?><div class="intro"><?= tpl_ml($b['intro']) ?></div><?php endif; ?>
            <div class="chips">
                <?php if (!empty($b['email'])): ?><span class="chip"><?= icon('mail') ?><?= e($b['email']) ?></span><?php endif; ?>
                <?php if (!empty($b['phone'])): ?><span class="chip"><?= icon('phone') ?><?= e($b['phone']) ?></span><?php endif; ?>
                <?php if (!empty($b['location'])): ?><span class="chip"><?= icon('pin') ?><?= e($b['location']) ?></span><?php endif; ?>
                <?php if (!empty($b['website'])): ?><a class="chip" href="<?= e($b['website']) ?>" target="_blank"><?= icon('link') ?>Website</a><?php endif; ?>
                <?php foreach ($socials as $s): ?>
                    <?php if ($s['url']): ?><a class="chip" href="<?= e($s['url']) ?>" target="_blank"><?= icon($s['icon']) ?><?= e($s['label']) ?></a><?php else: ?><span class="chip"><?= icon($s['icon']) ?><?= e($s['label']) ?>: <?= e($s['value']) ?></span><?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </header>

    <?php if (!empty($profile['experiences'])): ?>
        <section>
            <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
            <?php foreach ($profile['experiences'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['company'] ?? '') ?></span><?php if (!empty($it['position'])): ?> <span class="t2"><?= e($it['position']) ?></span><?php endif; ?>
                            <?php if (!empty($it['location'])): ?> <span class="date"><?= e($it['location']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <div class="desc"><?php if (count($lines) > 1): ?><ul><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul><?php else: ?><?= tpl_ml($it['desc']) ?><?php endif; ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['projects'])): ?>
        <section>
            <h2><?= icon('folder') ?><?= te('projects') ?></h2>
            <?php foreach ($profile['projects'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['role'])): ?> <span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?>
                            <?php if (!empty($it['link'])): ?> · <a href="<?= e($it['link']) ?>" target="_blank"><?= icon('link') ?></a><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['tech'])): ?><div class="desc"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['skills'])): ?>
        <section>
            <h2><?= icon('star') ?><?= te('skills') ?></h2>
            <div class="skills">
                <?php foreach ($profile['skills'] as $it): ?>
                    <div>
                        <div class="skill-name"><span><?= e($it['name'] ?? '') ?></span><span class="date"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                        <div class="bar"><i style="width:<?= max(0, min(100, (int)($it['level'] ?? 0))) ?>%"></i></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['educations'])): ?>
        <section>
            <h2><?= icon('school') ?><?= te('education') ?></h2>
            <?php foreach ($profile['educations'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['school'] ?? '') ?></span><?php if (!empty($it['major'])): ?> <span class="t2"><?= e($it['major']) ?></span><?php endif; ?>
                            <?php if (!empty($it['degree'])): ?> <span class="date"><?= e($it['degree']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['certs'])): ?>
        <section>
            <h2><?= icon('award') ?><?= te('certificates') ?></h2>
            <?php foreach ($profile['certs'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['issuer'])): ?> <span class="t2"><?= e($it['issuer']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= e($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['portfolio'])): ?>
        <section>
            <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
            <div class="cards">
                <?php foreach ($profile['portfolio'] as $it): ?>
                    <div class="card-x">
                        <?php if (!empty($it['image'])): ?><img src="<?= e($it['image']) ?>" alt=""><?php endif; ?>
                        <div class="body">
                            <h4><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['title'] ?? '') ?></a><?php else: ?><?= e($it['title'] ?? '') ?><?php endif; ?></h4>
                            <?php if (!empty($it['desc'])): ?><p><?= e($it['desc']) ?></p><?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($profile['custom_items'])): ?>
        <section>
            <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
            <?php foreach ($profile['custom_items'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['title'] ?? '') ?></span></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <footer>
        <?php if (!empty($settings['show_resume'])): ?><p><a href="resume.php"><?= icon('print') ?> <?= te('online_resume') ?></a></p><?php endif; ?>
        <p><?= e($settings['footer_text']) ?></p>
    </footer>
</div>
<?= theme_assets() ?>
</body>
</html>
