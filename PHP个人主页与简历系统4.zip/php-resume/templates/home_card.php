<?php
/**
 * 模板：双栏名片（个人主页）
 */
$primary = theme_color();
$avatar = avatar_url($profile);
$b = $profile['basic'];
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($settings['site_title'] ?: $b['name']) ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text); font-size: 15px; line-height: 1.75;
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
        }
        a { color: var(--primary); text-decoration: none; }
        .wrap { max-width: 1000px; margin: 34px auto; padding: 0 18px; display: grid; grid-template-columns: 300px 1fr; gap: 22px; align-items: start; }
        .side { background: var(--panel); border-radius: 14px; padding: 28px 24px; box-shadow: var(--shadow); position: sticky; top: 24px; }
        .main { display: flex; flex-direction: column; gap: 18px; }
        .avatar { width: 112px; height: 112px; border-radius: 16px; object-fit: cover; display: block; margin: 0 auto 14px; }
        .side h1 { font-size: 22px; margin: 0 0 4px; text-align: center; }
        .role { text-align: center; color: var(--primary); font-size: 14px; margin-bottom: 18px; }
        .info-row { display: flex; gap: 10px; font-size: 13.5px; padding: 7px 0; border-bottom: 1px dashed var(--border-2); align-items: flex-start; }
        .info-row .k { color: var(--text-3); width: 62px; flex: none; display: flex; align-items: center; gap: 5px; }
        .info-row .v { color: var(--text-2); word-break: break-all; }
        .side .tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }
        .tag { background: var(--chip); color: var(--text-2); border-radius: 5px; padding: 3px 9px; font-size: 12.5px; }
        .card { background: var(--panel); border-radius: 14px; padding: 24px 26px; box-shadow: var(--shadow); }
        .card h2 { margin: 0 0 16px; font-size: 17px; padding-left: 10px; border-left: 4px solid var(--primary); display: flex; align-items: center; gap: 8px; }
        .card h2 svg { color: var(--primary); }
        .item { padding: 12px 0; border-bottom: 1px dashed var(--border-2); }
        .item:last-child { border-bottom: 0; padding-bottom: 0; }
        .item-head { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
        .t1 { font-weight: 600; }
        .t2 { color: var(--primary); font-size: 14px; }
        .date { color: var(--text-3); font-size: 13px; }
        .desc { color: var(--text-2); font-size: 14.5px; margin-top: 4px; }
        .desc ul { margin: 4px 0 0; padding-left: 18px; }
        .skills { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 12px 22px; }
        .bar { height: 6px; background: var(--chip); border-radius: 3px; overflow: hidden; margin-top: 4px; }
        .bar i { display: block; height: 100%; background: var(--primary); }
        .skill-name { display: flex; justify-content: space-between; font-size: 13.5px; }
        .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 14px; }
        .card-x { border: 1px solid var(--border-2); border-radius: 10px; overflow: hidden; }
        .card-x img { width: 100%; height: 130px; object-fit: cover; display: block; }
        .card-x .body { padding: 11px 13px; }
        .card-x h4 { margin: 0 0 4px; font-size: 14.5px; }
        .card-x p { margin: 0; font-size: 13px; color: var(--text-2); }
        footer { grid-column: 1 / -1; text-align: center; color: var(--text-3); font-size: 13px; padding: 6px 0 20px; }
        @media (max-width: 800px) { .wrap { grid-template-columns: 1fr; margin: 18px auto; } .side { position: static; } }
    </style>
</head>
<body>
<div class="wrap">
    <aside class="side">
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt=""><?php endif; ?>
        <h1><?= e($b['name']) ?></h1>
        <div class="role"><?= e($b['title']) ?></div>
        <?php if (!empty($b['email'])): ?><div class="info-row"><span class="k"><?= icon('mail') ?><?= te('email') ?></span><span class="v"><?= e($b['email']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['phone'])): ?><div class="info-row"><span class="k"><?= icon('phone') ?><?= te('phone') ?></span><span class="v"><?= e($b['phone']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['location'])): ?><div class="info-row"><span class="k"><?= icon('pin') ?><?= te('city') ?></span><span class="v"><?= e($b['location']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['birthday'])): ?><div class="info-row"><span class="k"><?= icon('cake') ?><?= te('birthday') ?></span><span class="v"><?= e($b['birthday']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['website'])): ?><div class="info-row"><span class="k"><?= icon('link') ?><?= te('website') ?></span><span class="v"><a href="<?= e($b['website']) ?>" target="_blank"><?= e($b['website']) ?></a></span></div><?php endif; ?>
        <?php foreach ($socials as $s): ?>
            <div class="info-row"><span class="k"><?= icon($s['icon']) ?><?= e($s['label']) ?></span><span class="v"><?php if ($s['url']): ?><a href="<?= e($s['url']) ?>" target="_blank"><?= e($s['value']) ?></a><?php else: ?><?= e($s['value']) ?><?php endif; ?></span></div>
        <?php endforeach; ?>
        <?php if (!empty($profile['skills'])): ?>
            <div class="tags">
                <?php foreach ($profile['skills'] as $it): ?><span class="tag"><?= e($it['name'] ?? '') ?></span><?php endforeach; ?>
            </div>
        <?php endif; ?>
    </aside>

    <div class="main">
        <?php if (!empty($b['intro'])): ?>
            <div class="card">
                <h2><?= icon('user') ?><?= te('about_me') ?></h2>
                <div class="desc"><?= tpl_ml($b['intro']) ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['experiences'])): ?>
            <div class="card">
                <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
                <?php foreach ($profile['experiences'] as $it): ?>
                    <div class="item">
                        <div class="item-head">
                            <div><span class="t1"><?= e($it['company'] ?? '') ?></span><?php if (!empty($it['position'])): ?> <span class="t2"><?= e($it['position']) ?></span><?php endif; ?></div>
                            <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                        </div>
                        <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                            <div class="desc"><?php if (count($lines) > 1): ?><ul><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul><?php else: ?><?= tpl_ml($it['desc']) ?><?php endif; ?></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['projects'])): ?>
            <div class="card">
                <h2><?= icon('folder') ?><?= te('projects') ?></h2>
                <?php foreach ($profile['projects'] as $it): ?>
                    <div class="item">
                        <div class="item-head">
                            <div><span class="t1"><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['name'] ?? '') ?></a><?php else: ?><?= e($it['name'] ?? '') ?><?php endif; ?></span>
                                <?php if (!empty($it['role'])): ?> <span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?></div>
                            <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                        </div>
                        <?php if (!empty($it['tech'])): ?><div class="desc"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                        <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['educations'])): ?>
            <div class="card">
                <h2><?= icon('school') ?><?= te('education') ?></h2>
                <?php foreach ($profile['educations'] as $it): ?>
                    <div class="item">
                        <div class="item-head">
                            <div><span class="t1"><?= e($it['school'] ?? '') ?></span><?php if (!empty($it['major'])): ?> <span class="t2"><?= e($it['major']) ?></span><?php endif; ?></div>
                            <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                        </div>
                        <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['skills'])): ?>
            <div class="card">
                <h2><?= icon('star') ?><?= te('skills') ?></h2>
                <div class="skills">
                    <?php foreach ($profile['skills'] as $it): ?>
                        <div>
                            <div class="skill-name"><span><?= e($it['name'] ?? '') ?></span><span class="date"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                            <div class="bar"><i style="width:<?= max(0, min(100, (int)($it['level'] ?? 0))) ?>%"></i></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['certs'])): ?>
            <div class="card">
                <h2><?= icon('award') ?><?= te('certificates') ?></h2>
                <?php foreach ($profile['certs'] as $it): ?>
                    <div class="item">
                        <div class="item-head">
                            <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['issuer'])): ?> <span class="t2"><?= e($it['issuer']) ?></span><?php endif; ?></div>
                            <div class="date"><?= e($it['date'] ?? '') ?></div>
                        </div>
                        <?php if (!empty($it['desc'])): ?><div class="desc"><?= e($it['desc']) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['portfolio'])): ?>
            <div class="card">
                <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
                <div class="cards">
                    <?php foreach ($profile['portfolio'] as $it): ?>
                        <div class="card-x">
                            <?php if (!empty($it['image'])): ?><img src="<?= e($it['image']) ?>" alt=""><?php endif; ?>
                            <div class="body">
                                <h4><?php if (!empty($it['link'])): ?><a href="<?= e($it['link']) ?>" target="_blank"><?= e($it['title'] ?? '') ?></a><?php else: ?><?= e($it['title'] ?? '') ?><?php endif; ?></h4>
                                <?php if (!empty($it['desc'])): ?><p><?= e($it['desc']) ?></p><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['custom_items'])): ?>
            <div class="card">
                <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
                <?php foreach ($profile['custom_items'] as $it): ?>
                    <div class="item">
                        <div class="item-head">
                            <div><span class="t1"><?= e($it['title'] ?? '') ?></span></div>
                            <div class="date"><?= e($it['date'] ?? '') ?></div>
                        </div>
                        <?php if (!empty($it['desc'])): ?><div class="desc"><?= tpl_ml($it['desc']) ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <?php if (!empty($settings['show_resume'])): ?><p><a href="resume.php"><?= icon('print') ?> <?= te('view_resume') ?></a></p><?php endif; ?>
        <p><?= e($settings['footer_text']) ?></p>
    </footer>
</div>
<?= theme_assets() ?>
</body>
</html>
