<?php
/**
 * 模板：侧栏商务简历（A4 打印友好，左侧深色信息栏）
 */
$isPreview = is_admin() && !empty($_GET['preview_tpl']);
$autoPrint = !empty($_GET['print']) && !$isPreview;
$primary = theme_color();
$b = $profile['basic'];
$avatar = avatar_url($profile);
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($b['name']) ?> - <?= te('resume') ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.7;
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
        }
        a { color: var(--primary); text-decoration: none; }
        .toolbar { position: fixed; right: 18px; bottom: 18px; display: flex; gap: 8px; z-index: 40; }
        .toolbar a, .toolbar button {
            background: var(--primary); color: #fff; border: 0; padding: 9px 15px; border-radius: 6px;
            font-size: 13px; cursor: pointer; font-family: inherit; display: inline-flex; align-items: center; gap: 6px;
            box-shadow: var(--shadow-lg);
        }
        .page { width: 210mm; min-height: 297mm; margin: 24px auto; background: var(--panel); box-shadow: var(--shadow-lg); display: flex; }
        .side { width: 62mm; background: var(--primary); color: #eef3ff; padding: 14mm 10mm; flex: none; }
        .side .avatar { width: 62px; height: 62px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,.7); display: block; margin-bottom: 12px; }
        .side h3 { font-size: 12px; letter-spacing: 2px; margin: 16px 0 8px; color: rgba(255,255,255,.75); border-bottom: 1px solid rgba(255,255,255,.3); padding-bottom: 5px; }
        .side .row { font-size: 12.5px; margin-bottom: 6px; word-break: break-all; display: flex; align-items: flex-start; gap: 5px; }
        .side .row b { font-weight: 500; color: rgba(255,255,255,.75); font-size: 11.5px; }
        .side .row a { color: #fff; }
        .side .tag { display: inline-block; background: rgba(255,255,255,.16); border-radius: 4px; padding: 2px 8px; font-size: 12px; margin: 0 4px 5px 0; }
        .main { flex: 1; padding: 14mm 12mm; min-width: 0; }
        .main .name { font-size: 25px; font-weight: 700; margin: 0 0 2px; letter-spacing: 2px; }
        .main .role { color: var(--primary); font-size: 14px; margin-bottom: 14px; }
        .main h2 { font-size: 14px; margin: 16px 0 10px; color: var(--primary); display: flex; align-items: center; gap: 8px; }
        .main h2:after { content: ""; flex: 1; height: 1px; background: var(--border-2); }
        .item { margin-bottom: 11px; }
        .item-head { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; align-items: baseline; }
        .t1 { font-weight: 700; font-size: 14px; }
        .t2 { font-size: 13px; color: var(--text-2); margin-left: 5px; }
        .date { font-size: 12px; color: var(--text-3); background: var(--chip); padding: 1px 8px; border-radius: 10px; white-space: nowrap; }
        ul.pts { margin: 4px 0 0; padding-left: 17px; font-size: 13px; color: var(--text-2); }
        .bar { height: 5px; background: var(--chip); border-radius: 3px; overflow: hidden; margin: 3px 0 8px; }
        .bar i { display: block; height: 100%; background: var(--primary); }
        .skill-name { display: flex; justify-content: space-between; font-size: 13px; }
        .summary { font-size: 13px; color: var(--text-2); }
        ul.plain { margin: 0; padding-left: 17px; font-size: 13px; color: var(--text-2); }
        @page { size: A4; margin: 10mm; }
        @media print {
            html, html.dark, html.light, html.auto-mode {
                --bg: #fff; --panel: #fff; --panel-2: #fff;
                --text: #111; --text-2: #333; --text-3: #555;
                --border: #999; --border-2: #ddd; --chip: #f0f0f0; --shadow: none; --shadow-lg: none;
                color-scheme: light;
            }
            body { background: #fff; }
            .toolbar { display: none; }
            .page { margin: 0; box-shadow: none; width: auto; min-height: auto; }
            .side { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
        @media (max-width: 820px) {
            .page { flex-direction: column; width: auto; min-height: auto; margin: 12px; }
            .side { width: auto; }
            .main { padding: 22px 16px; }
        }
    </style>
</head>
<body>
<?php if (!$isPreview): ?>
    <div class="toolbar">
        <button onclick="window.print()"><?= icon('print') ?><?= te('print_pdf') ?></button>
        <a href="index.php"><?= icon('arrow-left') ?><?= te('back_home') ?></a>
    </div>
<?php endif; ?>

<div class="page">
    <aside class="side">
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt=""><?php endif; ?>
        <h3><?= te('contact') ?></h3>
        <?php if (!empty($b['phone'])): ?><div class="row"><?= icon('phone') ?><span><b><?= te('phone') ?></b><br><?= e($b['phone']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['email'])): ?><div class="row"><?= icon('mail') ?><span><b><?= te('email') ?></b><br><?= e($b['email']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['location'])): ?><div class="row"><?= icon('pin') ?><span><b><?= te('location') ?></b><br><?= e($b['location']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['birthday'])): ?><div class="row"><?= icon('cake') ?><span><b><?= te('birth_date') ?></b><br><?= e($b['birthday']) ?></span></div><?php endif; ?>
        <?php if (!empty($b['website'])): ?><div class="row"><?= icon('link') ?><span><b><?= te('website') ?></b><br><a href="<?= e($b['website']) ?>" target="_blank"><?= e($b['website']) ?></a></span></div><?php endif; ?>
        <?php foreach ($socials as $s): ?>
            <div class="row"><?= icon($s['icon']) ?><span><b><?= e($s['label']) ?></b><br><?php if ($s['url']): ?><a href="<?= e($s['url']) ?>" target="_blank"><?= e($s['value']) ?></a><?php else: ?><?= e($s['value']) ?><?php endif; ?></span></div>
        <?php endforeach; ?>

        <?php if (!empty($profile['skills'])): ?>
            <h3><?= te('skills') ?></h3>
            <div>
                <?php foreach ($profile['skills'] as $it): ?><span class="tag"><?= e($it['name'] ?? '') ?></span><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($profile['certs'])): ?>
            <h3><?= te('certificates') ?></h3>
            <?php foreach ($profile['certs'] as $it): ?>
                <div class="row">· <?= e($it['name'] ?? '') ?><?php if (!empty($it['date'])): ?>（<?= e($it['date']) ?>）<?php endif; ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
    </aside>

    <div class="main">
        <div class="name"><?= e($b['name']) ?></div>
        <div class="role"><?= e($b['title']) ?></div>

        <?php if (!empty($b['objective'])): ?>
            <h2><?= icon('target') ?><?= te('objective') ?></h2>
            <div class="summary"><?= tpl_ml($b['objective']) ?></div>
        <?php endif; ?>

        <?php if (!empty($b['intro'])): ?>
            <h2><?= icon('user') ?><?= te('summary') ?></h2>
            <div class="summary"><?= tpl_ml($b['intro']) ?></div>
        <?php endif; ?>

        <?php if (!empty($profile['experiences'])): ?>
            <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
            <?php foreach ($profile['experiences'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['company'] ?? '') ?></span><?php if (!empty($it['position'])): ?><span class="t2"><?= e($it['position']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!empty($profile['projects'])): ?>
            <h2><?= icon('folder') ?><?= te('projects') ?></h2>
            <?php foreach ($profile['projects'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['role'])): ?><span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['tech'])): ?><div class="summary"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                    <?php if (!empty($it['link'])): ?><div class="summary"><?= te('project_link') ?>：<?= e($it['link']) ?></div><?php endif; ?>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!empty($profile['educations'])): ?>
            <h2><?= icon('school') ?><?= te('education') ?></h2>
            <?php foreach ($profile['educations'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['school'] ?? '') ?></span><?php if (!empty($it['major'])): ?><span class="t2"><?= e($it['major']) ?></span><?php endif; ?>
                            <?php if (!empty($it['degree'])): ?><span class="t2"><?= e($it['degree']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!empty($profile['skills'])): ?>
            <h2><?= icon('star') ?><?= te('skills') ?></h2>
            <?php foreach ($profile['skills'] as $it): ?>
                <div class="skill-name"><span><?= e($it['name'] ?? '') ?></span><span style="color:var(--text-3)"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                <div class="bar"><i style="width:<?= max(0, min(100, (int)($it['level'] ?? 0))) ?>%"></i></div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!empty($profile['portfolio'])): ?>
            <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
            <ul class="plain">
                <?php foreach ($profile['portfolio'] as $it): ?>
                    <li><?= e($it['title'] ?? '') ?><?php if (!empty($it['desc'])): ?>　<?= e($it['desc']) ?><?php endif; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <?php if (!empty($profile['custom_items'])): ?>
            <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
            <?php foreach ($profile['custom_items'] as $it): ?>
                <div class="item">
                    <div class="item-head">
                        <div><span class="t1"><?= e($it['title'] ?? '') ?></span></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php if ($autoPrint): ?><script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 400); });</script><?php endif; ?>
<?= theme_assets() ?>
</body>
</html>
