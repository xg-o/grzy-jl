<?php
/**
 * 模板：时间轴简历（A4 打印友好）
 */
$isPreview = is_admin() && !empty($_GET['preview_tpl']);
$autoPrint = !empty($_GET['print']) && !$isPreview;
$primary = theme_color();
$b = $profile['basic'];
$avatar = avatar_url($profile);
$socials = social_list($profile);
$lang = current_lang();
?>
<!doctype html>
<html <?= theme_html_attrs() ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($b['name']) ?> - <?= te('resume') ?></title>
    <meta name="description" content="<?= e($settings['meta_description']) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/pref.css')) ?>">
    <?= theme_head_css() ?>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0; background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.7;
            font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
        }
        a { color: var(--primary); text-decoration: none; }
        .toolbar { position: fixed; right: 18px; bottom: 18px; display: flex; gap: 8px; z-index: 40; }
        .toolbar a, .toolbar button {
            background: var(--primary); color: #fff; border: 0; padding: 9px 15px; border-radius: 6px;
            font-size: 13px; cursor: pointer; font-family: inherit; display: inline-flex; align-items: center; gap: 6px;
            box-shadow: var(--shadow-lg);
        }
        .page { width: 210mm; min-height: 297mm; margin: 24px auto; background: var(--panel); padding: 15mm 14mm; box-shadow: var(--shadow-lg); }
        .head { display: flex; gap: 18px; align-items: center; border-bottom: 3px solid var(--primary); padding-bottom: 14px; margin-bottom: 6px; }
        .avatar { width: 74px; height: 74px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary); }
        .head h1 { font-size: 24px; margin: 0 0 3px; }
        .role { color: var(--primary); font-size: 14px; margin-bottom: 6px; }
        .contact { font-size: 12.5px; color: var(--text-2); display: flex; flex-wrap: wrap; gap: 4px 6px; }
        .contact span { margin-right: 12px; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px; }
        h2 { font-size: 15px; margin: 20px 0 12px; color: var(--primary); display: flex; align-items: center; gap: 8px; }
        h2:after { content: ""; flex: 1; height: 1px; background: var(--border-2); }
        .timeline { position: relative; padding-left: 26px; }
        .timeline:before { content: ""; position: absolute; left: 6px; top: 4px; bottom: 4px; width: 2px; background: var(--border-2); }
        .node { position: relative; margin-bottom: 14px; }
        .node:before {
            content: ""; position: absolute; left: -24px; top: 6px; width: 10px; height: 10px;
            border-radius: 50%; background: var(--primary); box-shadow: 0 0 0 3px var(--chip);
        }
        .node-head { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; align-items: baseline; }
        .t1 { font-weight: 700; font-size: 14.5px; }
        .t2 { color: var(--text-2); font-size: 13px; margin-left: 6px; }
        .date { color: var(--text-3); font-size: 12.5px; background: var(--chip); padding: 1px 8px; border-radius: 10px; }
        ul.pts { margin: 4px 0 0; padding-left: 18px; font-size: 13.5px; color: var(--text-2); }
        .skill-wrap { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 8px 20px; }
        .skill-name { display: flex; justify-content: space-between; font-size: 13.5px; }
        .bar { height: 5px; background: var(--chip); border-radius: 3px; overflow: hidden; margin-top: 3px; }
        .bar i { display: block; height: 100%; background: var(--primary); }
        .summary { font-size: 13.5px; color: var(--text-2); }
        ul.plain { margin: 0; padding-left: 18px; font-size: 13.5px; color: var(--text-2); }
        @page { size: A4; margin: 12mm; }
        @media print {
            html, html.dark, html.light, html.auto-mode {
                --bg: #fff; --panel: #fff; --panel-2: #fff;
                --text: #111; --text-2: #333; --text-3: #555;
                --border: #999; --border-2: #ddd; --chip: #f0f0f0; --shadow: none; --shadow-lg: none;
                color-scheme: light;
            }
            body { background: #fff; }
            .toolbar { display: none; }
            .page { margin: 0; box-shadow: none; width: auto; min-height: auto; padding: 0; }
        }
        @media (max-width: 820px) { .page { width: auto; min-height: auto; margin: 12px; padding: 22px 16px; } }
    </style>
</head>
<body>
<?php if (!$isPreview): ?>
    <div class="toolbar">
        <button onclick="window.print()"><?= icon('print') ?><?= te('print_pdf') ?></button>
        <a href="index.php"><?= icon('arrow-left') ?><?= te('back_home') ?></a>
    </div>
<?php endif; ?>

<div class="page">
    <div class="head">
        <?php if ($avatar): ?><img class="avatar" src="<?= e($avatar) ?>" alt=""><?php endif; ?>
        <div style="flex:1">
            <h1><?= e($b['name']) ?></h1>
            <div class="role"><?= e($b['title']) ?></div>
            <div class="contact">
                <?php if (!empty($b['phone'])): ?><span><?= icon('phone') ?><?= e($b['phone']) ?></span><?php endif; ?>
                <?php if (!empty($b['email'])): ?><span><?= icon('mail') ?><?= e($b['email']) ?></span><?php endif; ?>
                <?php if (!empty($b['location'])): ?><span><?= icon('pin') ?><?= e($b['location']) ?></span><?php endif; ?>
                <?php if (!empty($b['website'])): ?><span><?= icon('link') ?><a href="<?= e($b['website']) ?>" target="_blank"><?= te('website') ?></a></span><?php endif; ?>
                <?php foreach ($socials as $s): ?><span><?= icon($s['icon']) ?><?= e($s['value']) ?></span><?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php if (!empty($b['objective'])): ?>
        <h2><?= icon('target') ?><?= te('objective') ?></h2>
        <div class="summary"><?= tpl_ml($b['objective']) ?></div>
    <?php endif; ?>

    <?php if (!empty($b['intro'])): ?>
        <h2><?= icon('user') ?><?= te('summary') ?></h2>
        <div class="summary"><?= tpl_ml($b['intro']) ?></div>
    <?php endif; ?>

    <?php if (!empty($profile['experiences'])): ?>
        <h2><?= icon('briefcase') ?><?= te('experience') ?></h2>
        <div class="timeline">
            <?php foreach ($profile['experiences'] as $it): ?>
                <div class="node">
                    <div class="node-head">
                        <div><span class="t1"><?= e($it['company'] ?? '') ?></span><?php if (!empty($it['position'])): ?><span class="t2"><?= e($it['position']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($profile['projects'])): ?>
        <h2><?= icon('folder') ?><?= te('projects') ?></h2>
        <div class="timeline">
            <?php foreach ($profile['projects'] as $it): ?>
                <div class="node">
                    <div class="node-head">
                        <div><span class="t1"><?= e($it['name'] ?? '') ?></span><?php if (!empty($it['role'])): ?><span class="t2"><?= e($it['role']) ?></span><?php endif; ?><?= tpl_tag($it) ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['tech'])): ?><div class="summary"><?= te('tech_stack') ?>：<?= e($it['tech']) ?></div><?php endif; ?>
                    <?php if (!empty($it['link'])): ?><div class="summary"><?= te('project_link') ?>：<?= e($it['link']) ?></div><?php endif; ?>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($profile['educations'])): ?>
        <h2><?= icon('school') ?><?= te('education') ?></h2>
        <div class="timeline">
            <?php foreach ($profile['educations'] as $it): ?>
                <div class="node">
                    <div class="node-head">
                        <div><span class="t1"><?= e($it['school'] ?? '') ?></span><?php if (!empty($it['major'])): ?><span class="t2"><?= e($it['major']) ?></span><?php endif; ?>
                            <?php if (!empty($it['degree'])): ?><span class="t2"><?= e($it['degree']) ?></span><?php endif; ?></div>
                        <div class="date"><?= e(date_range($it['start'] ?? '', $it['end'] ?? '')) ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($profile['skills'])): ?>
        <h2><?= icon('star') ?><?= te('skills') ?></h2>
        <div class="skill-wrap">
            <?php foreach ($profile['skills'] as $it): ?>
                <div>
                    <div class="skill-name"><span><?= e($it['name'] ?? '') ?></span><span style="color:var(--text-3)"><?= (int)($it['level'] ?? 0) ?>%</span></div>
                    <div class="bar"><i style="width:<?= max(0, min(100, (int)($it['level'] ?? 0))) ?>%"></i></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($profile['certs'])): ?>
        <h2><?= icon('award') ?><?= te('certificates') ?></h2>
        <ul class="plain">
            <?php foreach ($profile['certs'] as $it): ?>
                <li><?= e($it['date'] ?? '') ?>　<?= e($it['name'] ?? '') ?><?php if (!empty($it['issuer'])): ?>（<?= e($it['issuer']) ?>）<?php endif; ?><?php if (!empty($it['desc'])): ?>　<?= e($it['desc']) ?><?php endif; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!empty($profile['portfolio'])): ?>
        <h2><?= icon('image') ?><?= te('portfolio') ?></h2>
        <ul class="plain">
            <?php foreach ($profile['portfolio'] as $it): ?>
                <li><?= e($it['title'] ?? '') ?><?php if (!empty($it['link'])): ?>　<?= e($it['link']) ?><?php endif; ?><?php if (!empty($it['desc'])): ?>　<?= e($it['desc']) ?><?php endif; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!empty($profile['custom_items'])): ?>
        <h2><?= icon('target') ?><?= e($profile['custom_title'] ?: t('custom_section')) ?></h2>
        <div class="timeline">
            <?php foreach ($profile['custom_items'] as $it): ?>
                <div class="node">
                    <div class="node-head">
                        <div><span class="t1"><?= e($it['title'] ?? '') ?></span></div>
                        <div class="date"><?= e($it['date'] ?? '') ?></div>
                    </div>
                    <?php if (!empty($it['desc'])): $lines = tpl_lines($it['desc']); ?>
                        <ul class="pts"><?php foreach ($lines as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php if ($autoPrint): ?><script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 400); });</script><?php endif; ?>
<?= theme_assets() ?>
</body>
</html>
