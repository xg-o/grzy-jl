<?php
/**
 * 通用辅助函数
 */

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function now_str()
{
    return date('Y-m-d H:i:s');
}

/* ---------------- CSRF ---------------- */

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_check()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return true;
    }
    $token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        exit('<!doctype html><meta charset="utf-8"><title>403</title><body style="font-family:sans-serif;padding:40px">'
            . '<h2>请求被拒绝</h2><p>表单校验失败（可能页面已过期），请刷新后重试。</p></body>');
    }
    return true;
}

/* ---------------- 提示消息 ---------------- */

function flash($msg, $type = 'success')
{
    $_SESSION['flash'] = array('msg' => $msg, 'type' => $type);
}

function take_flash()
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

/* ---------------- 后台登录 ---------------- */

function is_admin()
{
    return !empty($_SESSION['admin_user']);
}

function require_admin()
{
    if (!is_admin()) {
        redirect('login.php');
    }
}

function verify_admin_login($user, $pass)
{
    $cfg = load_config();
    if (empty($cfg['admin'])) {
        return false;
    }
    if (!hash_equals($cfg['admin']['user'], $user)) {
        return false;
    }
    return password_verify($pass, $cfg['admin']['hash']);
}

/* ---------------- 上传 ---------------- */

function handle_upload($field, $subdir = '')
{
    if (empty($_FILES[$field]) || empty($_FILES[$field]['name'])) {
        return null;
    }
    $f = $_FILES[$field];
    if (!empty($f['error']) && $f['error'] !== UPLOAD_ERR_OK) {
        return array('error' => '上传失败，错误码：' . $f['error']);
    }
    if ($f['size'] > 3 * 1024 * 1024) {
        return array('error' => '文件不能超过 3MB');
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    $allow = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'svg');
    if (!in_array($ext, $allow, true)) {
        return array('error' => '仅支持 jpg / png / gif / webp / svg 格式');
    }
    // 用 getimagesize 校验真实图片（svg 跳过）
    if ($ext !== 'svg' && @getimagesize($f['tmp_name']) === false) {
        return array('error' => '文件内容不是有效图片');
    }
    $dir = UPLOAD_DIR . ($subdir ? '/' . $subdir : '');
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $name = date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        return array('error' => '保存文件失败，请检查 data/uploads 目录权限');
    }
    return array('path' => 'data/uploads' . ($subdir ? '/' . $subdir : '') . '/' . $name);
}

/* ---------------- 数组工具 ---------------- */

function array_get($arr, $key, $default = '')
{
    return is_array($arr) && array_key_exists($key, $arr) ? $arr[$key] : $default;
}

/**
 * 清理重复组：去掉全空行并重排索引
 */
function normalize_rows($rows)
{
    $out = array();
    if (!is_array($rows)) {
        return $out;
    }
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $has = false;
        foreach ($row as $v) {
            if (is_array($v)) {
                $v = implode('', $v);
            }
            if (trim((string)$v) !== '') {
                $has = true;
                break;
            }
        }
        if ($has) {
            $out[] = $row;
        }
    }
    return $out;
}

/**
 * 递归去除首尾空白（字符串）
 */
function trim_deep($value)
{
    if (is_array($value)) {
        return array_map('trim_deep', $value);
    }
    return is_string($value) ? trim($value) : $value;
}

/**
 * 检测目录是否可写
 */
function dir_writable($dir)
{
    if (!is_dir($dir)) {
        return @mkdir($dir, 0755, true);
    }
    return is_writable($dir);
}

/**
 * 安全截取字符串（无 mbstring 时退化为 substr）
 */
function str_cut($str, $len, $suffix = '')
{
    $str = (string)$str;
    if (function_exists('mb_substr')) {
        $cut = mb_substr($str, 0, $len, 'UTF-8');
        return (mb_strlen($str, 'UTF-8') > $len) ? $cut . $suffix : $cut;
    }
    return (strlen($str) > $len) ? substr($str, 0, $len) . $suffix : $str;
}
