<?php
/**
 * 代码托管平台：从 GitHub / Gitee / GitLab 拉取仓库并转换为项目条目
 *
 * 只做只读的公开接口请求，Token 可选（用于提高限流额度或读取私有仓库）。
 */

function platform_list()
{
    return array(
        'github' => array('zh' => 'GitHub', 'en' => 'GitHub', 'hint' => 'github.com/<用户名>'),
        'gitee'  => array('zh' => 'Gitee',  'en' => 'Gitee',  'hint' => 'gitee.com/<用户名>'),
        'gitlab' => array('zh' => 'GitLab', 'en' => 'GitLab', 'hint' => 'gitlab.com/<用户名>'),
        'gitea'  => array('zh' => 'Gitea / 自建', 'en' => 'Gitea / self-hosted', 'hint' => '如 https://git.example.com/api/v1'),
    );
}

function platform_name($key)
{
    $all = platform_list();
    if (!isset($all[$key])) {
        return $key;
    }
    $lang = current_lang();
    return isset($all[$key][$lang]) ? $all[$key][$lang] : $all[$key]['zh'];
}

/**
 * 构造请求 URL
 */
function platform_url($platform, $user, $limit, $base = '')
{
    $user = rawurlencode($user);
    $limit = max(1, min(100, (int)$limit));
    switch ($platform) {
        case 'gitee':
            return 'https://gitee.com/api/v5/users/' . $user . '/repos?type=owner&sort=recently_updated&per_page=' . $limit;
        case 'gitlab':
            return 'https://gitlab.com/api/v4/users/' . $user . '/projects?per_page=' . $limit . '&order_by=updated_at&simple=false';
        case 'gitea':
            $base = rtrim(trim((string)$base), '/');
            if ($base === '') {
                $base = 'https://gitea.com/api/v1';
            }
            return $base . '/users/' . $user . '/repos?limit=' . $limit . '&sort=updated';
        default:
            return 'https://api.github.com/users/' . $user . '/repos?per_page=' . $limit . '&sort=updated&type=owner';
    }
}

/**
 * HTTP GET（curl 优先，回退 stream）
 * 返回 array(code, body, error)
 */
function http_get_json($url, $token = '', $auth = 'token')
{
    $headers = array('Accept: application/json', 'User-Agent: php-resume/1.0');
    if ($token !== '') {
        // GitHub / Gitee / Gitea 用 token，GitLab 用 Bearer
        $headers[] = 'Authorization: ' . ($auth === 'bearer' ? 'Bearer ' : 'token ') . $token;
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_ENCODING       => '',
        ));
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false) {
            return array(0, '', $err ?: '网络请求失败');
        }
        return array($code, $body, '');
    }

    if (!ini_get('allow_url_fopen')) {
        return array(0, '', '服务器未启用 curl，且 allow_url_fopen 已关闭，无法请求远程接口');
    }
    $ctx = stream_context_create(array(
        'http' => array(
            'method'        => 'GET',
            'header'        => implode("\r\n", $headers) . "\r\n",
            'timeout'       => 12,
            'ignore_errors' => true,
            'follow_location' => 1,
        ),
        'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
    ));
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        return array(0, '', '网络请求失败或被防火墙拦截');
    }
    $code = 200;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int)$m[1];
    }
    return array($code, $body, '');
}

/**
 * 拉取仓库列表
 * 返回 array(ok, msg, repos)
 */
function platform_fetch($platform, $user, $token = '', $limit = 20, $base = '')
{
    $user = trim((string)$user);
    if ($user === '') {
        return array(false, current_lang() === 'en' ? 'Please enter a username' : '请填写平台用户名', array());
    }
    if (!isset(platform_list()[$platform])) {
        $platform = 'github';
    }
    $url = platform_url($platform, $user, $limit, $base);
    $auth = ($platform === 'gitlab') ? 'bearer' : 'token';
    list($code, $body, $err) = http_get_json($url, trim((string)$token), $auth);

    if ($err !== '') {
        return array(false, $err, array());
    }
    if ($code === 403 || $code === 429) {
        return array(false, current_lang() === 'en'
            ? 'Blocked by the platform (HTTP ' . $code . '): rate limit reached, or the server IP is not allowed. Try a Token or switch network.'
            : '平台拒绝了请求（HTTP ' . $code . '）：可能是限流，也可能是服务器出口 IP 不被允许。可填写 Token 或换个网络环境重试', array());
    }
    if ($code === 404) {
        return array(false, current_lang() === 'en' ? 'User not found' : '用户不存在或仓库不可见', array());
    }
    if ($code >= 400) {
        return array(false, 'HTTP ' . $code, array());
    }
    $data = json_decode($body, true);
    if (!is_array($data)) {
        // Gitee 等可能返回 {"message": "..."}
        $msg = is_array($data) && isset($data['message']) ? $data['message'] : '';
        return array(false, $msg ?: (current_lang() === 'en' ? 'Invalid response' : '接口返回内容无法解析'), array());
    }
    if (isset($data['message']) && !isset($data[0])) {
        return array(false, (string)$data['message'], array());
    }

    $repos = array();
    foreach ($data as $r) {
        if (!is_array($r)) {
            continue;
        }
        $name = (string)($r['name'] ?? '');
        if ($name === '') {
            continue;
        }
        $desc = (string)($r['description'] ?? '');
        $link = (string)($r['html_url'] ?? ($r['web_url'] ?? ''));
        $lang = (string)($r['language'] ?? '');
        $star = (int)($r['stargazers_count'] ?? ($r['star_count'] ?? ($r['stars_count'] ?? 0)));
        $fork = !empty($r['fork']);
        $archived = !empty($r['archived']);
        $start = substr((string)($r['created_at'] ?? ''), 0, 7);
        $end = substr((string)($r['updated_at'] ?? ($r['last_activity_at'] ?? ($r['pushed_at'] ?? ''))), 0, 7);
        $topics = isset($r['topics']) && is_array($r['topics']) ? array_slice($r['topics'], 0, 4) : array();

        $tag = '';
        if ($star >= 1000) {
            $tag = '★ ' . round($star / 1000, 1) . 'k';
        } elseif ($star > 0) {
            $tag = '★ ' . $star;
        }
        if ($archived) {
            $tag = trim($tag . ' · ' . (current_lang() === 'en' ? 'archived' : '已归档'));
        }

        $tech = $lang;
        if ($topics && $tech === '') {
            $tech = implode(', ', $topics);
        }

        $repos[] = array(
            'name'  => $name,
            'desc'  => $desc,
            'link'  => $link,
            'tech'  => $tech,
            'tag'   => $tag,
            'start' => $start,
            'end'   => $end,
            'star'  => $star,
            'fork'  => $fork ? 1 : 0,
        );
    }
    if (empty($repos)) {
        return array(false, current_lang() === 'en' ? 'No public repositories found' : '没有找到公开仓库', array());
    }
    return array(true, sprintf(current_lang() === 'en' ? 'Fetched %d repositories' : '共获取 %d 个仓库', count($repos)), $repos);
}

/**
 * 可用排序方式
 */
function platform_sorts()
{
    return array(
        'time_desc' => array('zh' => '时间反（最近更新在前）', 'en' => 'Newest first'),
        'time_asc'  => array('zh' => '时间正（最早创建/更新在前）', 'en' => 'Oldest first'),
        'name_asc'  => array('zh' => '名称 A→Z', 'en' => 'Name A→Z'),
        'name_desc' => array('zh' => '名称 Z→A', 'en' => 'Name Z→A'),
        'star_desc' => array('zh' => 'Star 多→少', 'en' => 'Most stars'),
        'star_asc'  => array('zh' => 'Star 少→多', 'en' => 'Fewest stars'),
    );
}

function platform_sort_name($key)
{
    $all = platform_sorts();
    if (!isset($all[$key])) {
        $key = 'time_desc';
    }
    $lang = current_lang();
    return isset($all[$key][$lang]) ? $all[$key][$lang] : $all[$key]['zh'];
}

/**
 * 排序（原地）
 */
function platform_sort(array &$repos, $sort)
{
    $fallback = function ($a, $b, $key) {
        // 空值排最后
        $va = isset($a[$key]) ? (string)$a[$key] : '';
        $vb = isset($b[$key]) ? (string)$b[$key] : '';
        if ($va === '' && $vb === '') {
            return 0;
        }
        if ($va === '') {
            return 1;
        }
        if ($vb === '') {
            return -1;
        }
        return 0;
    };
    usort($repos, function ($a, $b) use ($sort, $fallback) {
        switch ($sort) {
            case 'time_asc':
                $cmp = strcmp((string)$a['end'], (string)$b['end']);
                return $cmp !== 0 ? $cmp : $fallback($a, $b, 'end');
            case 'name_asc':
                return strnatcasecmp((string)$a['name'], (string)$b['name']);
            case 'name_desc':
                return -strnatcasecmp((string)$a['name'], (string)$b['name']);
            case 'star_asc':
                $cmp = (int)$a['star'] <=> (int)$b['star'];
                return $cmp !== 0 ? $cmp : strnatcasecmp((string)$a['name'], (string)$b['name']);
            case 'star_desc':
                $cmp = (int)$b['star'] <=> (int)$a['star'];
                return $cmp !== 0 ? $cmp : strnatcasecmp((string)$a['name'], (string)$b['name']);
            case 'time_desc':
            default:
                $cmp = strcmp((string)$b['end'], (string)$a['end']);
                return $cmp !== 0 ? $cmp : $fallback($a, $b, 'end');
        }
    });
    return $repos;
}

/**
 * 去重：优先按仓库地址，其次按 平台+用户+仓库名
 */
function platform_dedup(array $repos)
{
    $seen = array();
    $out = array();
    foreach ($repos as $r) {
        $link = strtolower(trim((string)($r['link'] ?? '')));
        $k = $link !== '' ? 'u:' . $link
            : 'n:' . strtolower(trim((string)($r['platform'] ?? ''))) . '/' . strtolower(trim((string)($r['name'] ?? '')));
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $r;
    }
    return $out;
}

/**
 * 多平台拼接获取：把多个「平台 + 用户名」的结果合并、去重、排序
 * $queries: array(array('platform'=>..,'user'=>..,'token'=>..,'base'=>..), ...)
 * 返回 array(okCount, errors, repos)
 */
function platform_fetch_multi(array $queries, $sort = 'time_desc', $limit = 20)
{
    $repos = array();
    $errors = array();
    $okCount = 0;
    foreach ($queries as $q) {
        $pf = isset($q['platform']) ? (string)$q['platform'] : '';
        $user = trim((string)($q['user'] ?? ''));
        if ($pf === '' || $user === '') {
            continue;
        }
        $token = trim((string)($q['token'] ?? ''));
        $base = trim((string)($q['base'] ?? ''));
        list($ok, $msg, $list) = platform_fetch($pf, $user, $token, $limit, $base);
        if (!$ok) {
            $errors[] = platform_name($pf) . '（' . $user . '）：' . $msg;
            continue;
        }
        $okCount++;
        foreach ($list as $r) {
            $r['platform'] = $pf;
            $r['user'] = $user;
            $repos[] = $r;
        }
    }
    $repos = platform_dedup($repos);
    platform_sort($repos, $sort);
    return array($okCount, $errors, $repos);
}

/**
 * 把仓库数组转成项目条目（写入 profile['projects'] 用）
 */
function platform_to_projects(array $repos, array $indexes)
{
    $out = array();
    foreach ($indexes as $i) {
        if (!isset($repos[$i])) {
            continue;
        }
        $r = $repos[$i];
        $desc = trim($r['desc']);
        $out[] = array(
            'name'  => $r['name'],
            'role'  => '',
            'start' => $r['start'],
            'end'   => $r['end'],
            'tech'  => $r['tech'],
            'tag'   => $r['tag'],
            'link'  => $r['link'],
            'desc'  => $desc,
        );
    }
    return $out;
}
