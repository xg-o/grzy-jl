<?php
/**
 * 存储抽象层：文件存储（json / php / txt）与数据库存储（MySQL / SQLite）
 *
 * 所有驱动统一实现 KeyValueStore 接口，业务层只关心 get / set。
 */

interface KeyValueStore
{
    public function get($key, $default = array());

    public function set($key, $value);

    public function delete($key);

    public function label();
}

/* ============================================================
 * 文件存储
 * ========================================================== */
class FileStore implements KeyValueStore
{
    private $dir;
    private $format;

    public static $formats = array(
        'json' => 'JSON（.json，通用易读）',
        'php'  => 'PHP 数组（.php，include 直接加载）',
        'txt'  => '文本序列化（.txt，PHP serialize）',
    );

    public function __construct($dir, $format = 'json')
    {
        $this->dir = rtrim($dir, '/\\');
        $this->format = array_key_exists($format, self::$formats) ? $format : 'json';
        if (!is_dir($this->dir)) {
            @mkdir($this->dir, 0755, true);
        }
    }

    public function format()
    {
        return $this->format;
    }

    public function dir()
    {
        return $this->dir;
    }

    private function path($key)
    {
        $safe = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$key);
        if ($safe === '') {
            $safe = 'default';
        }
        return $this->dir . '/' . $safe . '.' . $this->format;
    }

    public function get($key, $default = array())
    {
        $file = $this->path($key);
        if (!is_file($file)) {
            return $default;
        }
        $raw = @file_get_contents($file);
        if ($raw === false || $raw === '') {
            return $default;
        }
        $data = $this->decode($file, $raw);
        return is_array($data) ? $data : $default;
    }

    public function set($key, $value)
    {
        $file = $this->path($key);
        $raw = $this->encode($value);
        $tmp = $file . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, $raw, LOCK_EX) === false) {
            throw new RuntimeException('无法写入数据文件：' . $file . '（请检查目录权限）');
        }
        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            if (@file_put_contents($file, $raw, LOCK_EX) === false) {
                throw new RuntimeException('无法写入数据文件：' . $file);
            }
        }
        return true;
    }

    public function delete($key)
    {
        $file = $this->path($key);
        if (is_file($file)) {
            @unlink($file);
        }
        return true;
    }

    public function label()
    {
        return '文件存储（' . strtoupper($this->format) . '）';
    }

    private function decode($file, $raw)
    {
        switch ($this->format) {
            case 'php':
                $data = @include $file;
                return is_array($data) ? $data : null;
            case 'txt':
                $data = @unserialize($raw);
                return is_array($data) ? $data : null;
            case 'json':
            default:
                $data = json_decode($raw, true);
                return is_array($data) ? $data : null;
        }
    }

    private function encode($value)
    {
        switch ($this->format) {
            case 'php':
                return "<?php\n/**\n * 数据文件（自动生成，格式：PHP 数组）\n * 更新：" . date('Y-m-d H:i:s') . "\n */\nreturn " . var_export($value, true) . ";\n";
            case 'txt':
                return serialize($value);
            case 'json':
            default:
                return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        }
    }
}

/* ============================================================
 * 数据库存储
 * ========================================================== */
class DbStore implements KeyValueStore
{
    private $pdo;
    private $table;
    private $driver;

    public function __construct(array $db)
    {
        $this->driver = isset($db['driver']) ? $db['driver'] : 'mysql';
        $this->pdo = db_connect($db);
        $prefix = isset($db['prefix']) ? preg_replace('/[^A-Za-z0-9_]/', '', $db['prefix']) : '';
        $this->table = $prefix . 'data';
    }

    public function pdo()
    {
        return $this->pdo;
    }

    public function table()
    {
        return $this->table;
    }

    public function get($key, $default = array())
    {
        try {
            $stmt = $this->pdo->prepare('SELECT `value` FROM ' . $this->quote($this->table) . ' WHERE `dk` = ? LIMIT 1');
            $stmt->execute(array($key));
            $raw = $stmt->fetchColumn();
        } catch (PDOException $ex) {
            throw new RuntimeException('读取数据失败：' . $ex->getMessage());
        }
        if ($raw === false || $raw === null || $raw === '') {
            return $default;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }

    public function set($key, $value)
    {
        $raw = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $sql = 'DELETE FROM ' . $this->quote($this->table) . ' WHERE `dk` = ?';
        $this->pdo->prepare($sql)->execute(array($key));
        $sql = 'INSERT INTO ' . $this->quote($this->table) . ' (`dk`, `value`, `updated_at`) VALUES (?, ?, ?)';
        $this->pdo->prepare($sql)->execute(array($key, $raw, date('Y-m-d H:i:s')));
        return true;
    }

    public function delete($key)
    {
        $this->pdo->prepare('DELETE FROM ' . $this->quote($this->table) . ' WHERE `dk` = ?')->execute(array($key));
        return true;
    }

    public function label()
    {
        return '数据库存储（' . ($this->driver === 'sqlite' ? 'SQLite' : 'MySQL') . '）';
    }

    private function quote($name)
    {
        return '`' . str_replace('`', '', $name) . '`';
    }
}

/* ============================================================
 * 连接与建表
 * ========================================================== */

function db_connect(array $db)
{
    $driver = isset($db['driver']) ? $db['driver'] : 'mysql';
    if ($driver === 'sqlite') {
        $file = isset($db['file']) && $db['file'] !== '' ? $db['file'] : (DATA_DIR . '/resume.db');
        if (!is_dir(dirname($file))) {
            @mkdir(dirname($file), 0755, true);
        }
        $pdo = new PDO('sqlite:' . $file, null, null, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ));
    } else {
        $host = isset($db['host']) ? $db['host'] : 'localhost';
        $name = isset($db['name']) ? $db['name'] : '';
        $user = isset($db['user']) ? $db['user'] : '';
        $pass = isset($db['pass']) ? $db['pass'] : '';
        $charset = 'utf8mb4';
        $port = !empty($db['port']) ? (int)$db['port'] : 3306;
        $dsn = 'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $name . ';charset=' . $charset;
        $pdo = new PDO($dsn, $user, $pass, array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ));
    }
    return $pdo;
}

function db_create_table(array $db)
{
    $pdo = db_connect($db);
    $prefix = isset($db['prefix']) ? preg_replace('/[^A-Za-z0-9_]/', '', $db['prefix']) : '';
    $table = $prefix . 'data';
    if (isset($db['driver']) && $db['driver'] === 'sqlite') {
        $pdo->exec('CREATE TABLE IF NOT EXISTS `' . $table . '` (
            `dk` TEXT NOT NULL PRIMARY KEY,
            `value` TEXT,
            `updated_at` TEXT
        )');
    } else {
        $pdo->exec('CREATE TABLE IF NOT EXISTS `' . $table . '` (
            `dk` varchar(64) NOT NULL,
            `value` longtext,
            `updated_at` datetime DEFAULT NULL,
            PRIMARY KEY (`dk`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    }
    return $pdo;
}

/* ============================================================
 * 工厂
 * ========================================================== */
class StorageFactory
{
    public static function create(array $cfg)
    {
        $scfg = isset($cfg['storage']) ? $cfg['storage'] : array('driver' => 'file', 'format' => 'json');
        $dbcfg = isset($cfg['db']) ? $cfg['db'] : array();
        if ($scfg['driver'] === 'db') {
            return new DbStore($dbcfg);
        }
        $dir = !empty($scfg['dir']) ? $scfg['dir'] : DATA_DIR;
        return new FileStore($dir, isset($scfg['format']) ? $scfg['format'] : 'json');
    }

    /**
     * 测试一组存储配置是否可用（安装/切换时使用）
     * 返回 array(true) 或 array(false, 错误信息)
     */
    public static function test(array $scfg, array $dbcfg)
    {
        try {
            if ($scfg['driver'] === 'db') {
                $pdo = db_create_table($dbcfg);
                $prefix = isset($dbcfg['prefix']) ? preg_replace('/[^A-Za-z0-9_]/', '', $dbcfg['prefix']) : '';
                $st = new DbStore($dbcfg);
                $st->set('__test', array('ok' => 1, 'time' => time()));
                $st->delete('__test');
                return array(true, '数据库连接正常，数据表已就绪（' . $prefix . 'data）');
            }
            $dir = !empty($scfg['dir']) ? $scfg['dir'] : DATA_DIR;
            if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
                return array(false, '无法创建数据目录：' . $dir);
            }
            if (!is_writable($dir)) {
                return array(false, '数据目录不可写：' . $dir . '（请设置 755 或 777 权限）');
            }
            $st = new FileStore($dir, $scfg['format']);
            $st->set('__test', array('ok' => 1, 'time' => time()));
            $st->delete('__test');
            return array(true, '文件存储可用：' . $dir . '（' . strtoupper($scfg['format']) . '）');
        } catch (Exception $ex) {
            return array(false, $ex->getMessage());
        }
    }
}
