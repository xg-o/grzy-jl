<?php
/**
 * 访问记录采集：IP、设备、系统、屏幕、网络、电量等
 *
 * 服务端采集（track.php 请求时）+ 前端 JS 上报（Battery / Network Information API）
 */

/**
 * 客户端 IP（兼容反向代理）
 */
function client_ip()
{
    $keys = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');
    foreach ($keys as $k) {
        if (empty($_SERVER[$k])) {
            continue;
        }
        $v = trim($_SERVER[$k]);
        if ($k === 'HTTP_X_FORWARDED_FOR' && strpos($v, ',') !== false) {
            $v = trim(explode(',', $v)[0]);
        }
        if ($v !== '' && strtolower($v) !== 'unknown') {
            return $v;
        }
    }
    return '0.0.0.0';
}

/**
 * IP 脱敏：1.2.3.4 → 1.2.3.*
 */
function mask_ip($ip)
{
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $p = explode('.', $ip);
        return $p[0] . '.' . $p[1] . '.' . $p[2] . '.*';
    }
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        return substr($ip, 0, strrpos($ip, ':') ?: 4) . ':*';
    }
    return $ip;
}

/**
 * 解析 UA → 浏览器 + 系统
 */
function parse_ua($ua)
{
    $ua = (string)$ua;
    $browser = t('unknown');
    $os = t('unknown');
    $map = array(
        'Edg'      => 'Edge',
        'OPR'      => 'Opera',
        'Chrome'   => 'Chrome',
        'Safari'   => 'Safari',
        'Firefox'  => 'Firefox',
        'MSIE'     => 'IE',
        'Trident'  => 'IE',
    );
    foreach ($map as $key => $name) {
        if (stripos($ua, $key) !== false) {
            $browser = $name;
            break;
        }
    }
    $osMap = array(
        'Windows'  => 'Windows',
        'Android'  => 'Android',
        'iPhone'   => 'iOS',
        'iPad'     => 'iOS',
        'Mac OS'   => 'macOS',
        'Linux'    => 'Linux',
    );
    foreach ($osMap as $key => $name) {
        if (stripos($ua, $key) !== false) {
            $os = $name;
            break;
        }
    }
    return array('browser' => $browser, 'os' => $os);
}

/**
 * 采集开关
 */
function track_enabled()
{
    if (!is_installed()) {
        return false;
    }
    $settings = get_data('settings', array());
    return !isset($settings['track_enable']) || $settings['track_enable'];
}

function track_keep_limit()
{
    $settings = get_data('settings', array());
    $n = (int)(isset($settings['track_keep']) ? $settings['track_keep'] : 500);
    return $n > 0 ? min($n, 5000) : 500;
}

/**
 * 写入一条访问记录
 */
function track_record(array $data)
{
    if (!track_enabled()) {
        return false;
    }
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $device = parse_ua($ua);
    $row = array(
        'time'    => date('Y-m-d H:i:s'),
        'ip'      => client_ip(),
        'page'    => isset($data['page']) ? substr((string)$data['page'], 0, 40) : '',
        'referer' => isset($data['ref']) ? substr((string)$data['ref'], 0, 200) : (isset($_SERVER['HTTP_REFERER']) ? substr($_SERVER['HTTP_REFERER'], 0, 200) : ''),
        'browser' => $device['browser'],
        'os'      => $device['os'],
        'ua'      => substr($ua, 0, 220),
        'lang'    => isset($data['lang']) ? substr((string)$data['lang'], 0, 20) : '',
        'tz'      => isset($data['tz']) ? substr((string)$data['tz'], 0, 40) : '',
        'screen'  => (isset($data['sw']) && isset($data['sh'])) ? ((int)$data['sw'] . '×' . (int)$data['sh']) : '',
        'dpr'     => isset($data['dpr']) ? round((float)$data['dpr'], 2) : '',
        'cores'   => isset($data['cores']) ? (int)$data['cores'] : '',
        'mem'     => isset($data['mem']) ? (float)$data['mem'] : '',
        'net'     => isset($data['net']) ? substr((string)$data['net'], 0, 20) : '',
        'downlink'=> isset($data['dl']) ? round((float)$data['dl'], 2) : '',
        'rtt'     => isset($data['rtt']) ? (int)$data['rtt'] : '',
        'online'  => isset($data['online']) ? ((int)$data['online'] ? 1 : 0) : 1,
        'bat'     => (isset($data['bat']) && $data['bat'] !== '' && $data['bat'] !== null) ? round((float)$data['bat'] * 100) : '',
        'charging'=> isset($data['chg']) ? ((int)$data['chg'] ? 1 : 0) : '',
        'dark'    => isset($data['dark']) ? ((int)$data['dark'] ? 1 : 0) : '',
    );
    try {
        $list = storage()->get('visits', array());
        if (!is_array($list)) {
            $list = array();
        }
        array_unshift($list, $row);
        $limit = track_keep_limit();
        if (count($list) > $limit) {
            $list = array_slice($list, 0, $limit);
        }
        storage()->set('visits', $list);
    } catch (Exception $ex) {
        return false;
    }
    return true;
}

/**
 * 读取访问记录
 */
function track_list()
{
    if (!is_installed()) {
        return array();
    }
    try {
        $list = storage()->get('visits', array());
    } catch (Exception $ex) {
        return array();
    }
    return is_array($list) ? $list : array();
}

/**
 * 统计
 */
function track_stats(array $list = null)
{
    if ($list === null) {
        $list = track_list();
    }
    $today = date('Y-m-d');
    $ips = array();
    $todayCount = 0;
    $batSum = 0;
    $batNum = 0;
    $charging = 0;
    foreach ($list as $r) {
        if (!empty($r['ip'])) {
            $ips[$r['ip']] = true;
        }
        if (!empty($r['time']) && strpos($r['time'], $today) === 0) {
            $todayCount++;
        }
        if (isset($r['bat']) && $r['bat'] !== '') {
            $batSum += (int)$r['bat'];
            $batNum++;
        }
        if (!empty($r['charging'])) {
            $charging++;
        }
    }
    return array(
        'total'    => count($list),
        'today'    => $todayCount,
        'ips'      => count($ips),
        'avg_bat'  => $batNum ? round($batSum / $batNum) : null,
        'charging' => $charging,
    );
}

/**
 * 清空
 */
function track_clear()
{
    storage()->set('visits', array());
}
