<?php
/**
 * 数据结构定义：默认数据 + 后台表单字段描述
 */

function default_profile()
{
    return array(
        'basic' => array(
            'name'        => '张明',
            'title'       => '全栈开发工程师',
            'avatar'      => '',
            'email'       => 'zhangming@example.com',
            'phone'       => '138-0000-0000',
            'location'    => '中国 · 杭州',
            'website'     => 'https://example.com',
            'birthday'    => '1995-03-12',
            'intro'       => '6 年 Web 开发经验，擅长 PHP / Go / 前端工程化，主导过多个百万级用户产品的架构设计与落地。喜欢把复杂的事情做简单，也喜欢把简单的事情做到极致。',
            'objective'   => '寻求一个能持续创造价值的工程岗位，在技术与业务之间搭桥。',
            'github'      => 'https://github.com/example',
            'linkedin'    => '',
            'weibo'       => '',
            'wechat'      => '',
            'qq'          => '',
        ),
        'educations' => array(
            array(
                'school'   => '示例大学',
                'major'    => '计算机科学与技术',
                'degree'   => '本科',
                'start'    => '2013-09',
                'end'      => '2017-06',
                'desc'     => '主修方向：分布式系统、数据库原理；连续三年获得校级奖学金。',
            ),
        ),
        'experiences' => array(
            array(
                'company'  => '某某科技有限公司',
                'position' => '高级后端工程师',
                'start'    => '2020-04',
                'end'      => '至今',
                'location' => '杭州',
                'desc'     => "负责核心交易系统重构，QPS 从 800 提升至 6000+\n带领 5 人小组完成微服务拆分与灰度发布体系建设",
            ),
        ),
        'projects' => array(
            array(
                'name'   => '开源简历系统',
                'role'   => '作者 /  maintainer',
                'start'  => '2024-01',
                'end'    => '2024-06',
                'link'   => 'https://github.com/example/resume',
                'tech'   => 'PHP, MySQL, Bootstrap',
                'desc'   => '一个零依赖、支持多模板与多存储方式的个人主页系统，GitHub 累计 1.2k star。',
            ),
        ),
        'skills' => array(
            array('name' => 'PHP / Laravel', 'level' => 90, 'desc' => ''),
            array('name' => 'MySQL / Redis', 'level' => 85, 'desc' => ''),
            array('name' => 'JavaScript / Vue', 'level' => 80, 'desc' => ''),
            array('name' => 'Docker / Linux', 'level' => 75, 'desc' => ''),
        ),
        'certs' => array(
            array('name' => 'AWS 解决方案架构师助理级', 'issuer' => 'Amazon', 'date' => '2022-08', 'desc' => ''),
        ),
        'portfolio' => array(
            array('title' => '作品一：电商平台', 'link' => 'https://example.com', 'image' => '', 'desc' => '日订单 10 万+ 的 B2C 商城。'),
        ),
        'custom_title'  => '',
        'custom_items'  => array(),
        'updated_at'    => '',
    );
}

function default_settings()
{
    return array(
        'site_title'       => '张明的个人主页',
        'meta_keywords'    => '张明,个人主页,简历,PHP工程师',
        'meta_description' => '张明的个人主页与在线简历',
        'home_template'    => 'home_modern',
        'resume_template'  => 'resume_classic',
        'theme_color'      => '#2563eb',
        'theme_panel'      => 'azure',
        'show_resume'      => 1,
        'footer_text'      => '© 2025 张明 · 保留所有权利',
        'icp'              => '',
        'language'         => 'zh',
        'default_mode'     => 'auto',
        'track_enable'     => 1,
        'track_keep'       => 500,
        'ip_mask'          => 0,
        'updated_at'       => '',
    );
}

/**
 * 后台资料编辑的字段分组
 */
function profile_schema()
{
    return array(
        'educations' => array(
            'label'  => 'education',
            'icon'   => 'school',
            'fields' => array(
                'school' => array('label' => 'f_school', 'type' => 'text', 'span' => 2),
                'major'  => array('label' => 'f_major', 'type' => 'text', 'span' => 2),
                'degree' => array('label' => 'f_degree', 'type' => 'text', 'span' => 1),
                'start'  => array('label' => 'f_start', 'type' => 'text', 'span' => 1, 'ph' => '2013-09'),
                'end'    => array('label' => 'f_end', 'type' => 'text', 'span' => 1, 'ph' => '2017-06'),
                'desc'   => array('label' => 'f_desc', 'type' => 'textarea', 'span' => 3),
            ),
        ),
        'experiences' => array(
            'label'  => 'experience',
            'icon'   => 'briefcase',
            'fields' => array(
                'company'  => array('label' => 'f_company', 'type' => 'text', 'span' => 2),
                'position' => array('label' => 'f_position', 'type' => 'text', 'span' => 2),
                'location' => array('label' => 'city', 'type' => 'text', 'span' => 1),
                'start'    => array('label' => 'f_start', 'type' => 'text', 'span' => 1, 'ph' => '2020-04'),
                'end'      => array('label' => 'f_end', 'type' => 'text', 'span' => 1, 'ph' => '至今'),
                'desc'     => array('label' => 'f_work_desc', 'type' => 'textarea', 'span' => 3, 'ph' => '每行一条，支持换行分条展示'),
            ),
        ),
        'projects' => array(
            'label'  => 'projects',
            'icon'   => 'folder',
            'fields' => array(
                'name' => array('label' => 'f_project', 'type' => 'text', 'span' => 2),
                'role' => array('label' => 'f_role', 'type' => 'text', 'span' => 1),
                'start' => array('label' => 'f_start', 'type' => 'text', 'span' => 1),
                'end'   => array('label' => 'f_end', 'type' => 'text', 'span' => 1),
                'tech'  => array('label' => 'f_tech', 'type' => 'text', 'span' => 1),
                'tag'   => array('label' => 'f_tag', 'type' => 'text', 'span' => 1, 'ph' => '★ 128 / 开源'),
                'link'  => array('label' => 'f_link', 'type' => 'text', 'span' => 2),
                'desc'  => array('label' => 'f_project_desc', 'type' => 'textarea', 'span' => 3),
            ),
        ),
        'skills' => array(
            'label'  => 'skills',
            'icon'   => 'star',
            'fields' => array(
                'name'  => array('label' => 'f_skill', 'type' => 'text', 'span' => 2),
                'level' => array('label' => 'f_level', 'type' => 'number', 'span' => 1),
                'desc'  => array('label' => 'f_remark', 'type' => 'text', 'span' => 3),
            ),
        ),
        'certs' => array(
            'label'  => 'certificates',
            'icon'   => 'award',
            'fields' => array(
                'name'   => array('label' => 'f_cert', 'type' => 'text', 'span' => 2),
                'issuer' => array('label' => 'f_issuer', 'type' => 'text', 'span' => 2),
                'date'   => array('label' => 'f_date', 'type' => 'text', 'span' => 1),
                'desc'   => array('label' => 'f_desc', 'type' => 'text', 'span' => 3),
            ),
        ),
        'portfolio' => array(
            'label'  => 'portfolio',
            'icon'   => 'image',
            'fields' => array(
                'title' => array('label' => 'f_port_title', 'type' => 'text', 'span' => 2),
                'link'  => array('label' => 'f_link', 'type' => 'text', 'span' => 2),
                'image' => array('label' => 'f_cover', 'type' => 'text', 'span' => 3),
                'desc'  => array('label' => 'f_summary', 'type' => 'textarea', 'span' => 3),
            ),
        ),
        'custom_items' => array(
            'label'  => 'custom_section',
            'icon'   => 'target',
            'fields' => array(
                'title' => array('label' => 'f_item_title', 'type' => 'text', 'span' => 2),
                'date'  => array('label' => 'f_date', 'type' => 'text', 'span' => 1),
                'desc'  => array('label' => 'f_content', 'type' => 'textarea', 'span' => 3),
            ),
        ),
    );
}

function basic_schema()
{
    return array(
        'name'      => array('label' => 'f_name', 'type' => 'text', 'span' => 1),
        'title'     => array('label' => 'f_title', 'type' => 'text', 'span' => 1),
        'email'     => array('label' => 'email', 'type' => 'text', 'span' => 1),
        'phone'     => array('label' => 'phone', 'type' => 'text', 'span' => 1),
        'location'  => array('label' => 'location', 'type' => 'text', 'span' => 1),
        'birthday'  => array('label' => 'birthday', 'type' => 'text', 'span' => 1),
        'website'   => array('label' => 'website', 'type' => 'text', 'span' => 2),
        'github'    => array('label' => 'f_github', 'type' => 'text', 'span' => 1),
        'linkedin'  => array('label' => 'f_linkedin', 'type' => 'text', 'span' => 1),
        'weibo'     => array('label' => 'f_weibo', 'type' => 'text', 'span' => 1),
        'wechat'    => array('label' => 'f_wechat', 'type' => 'text', 'span' => 1),
        'qq'        => array('label' => 'f_qq', 'type' => 'text', 'span' => 1),
        'intro'     => array('label' => 'f_intro', 'type' => 'textarea', 'span' => 3, 'ph' => '一两段话介绍你自己'),
        'objective' => array('label' => 'f_objective', 'type' => 'textarea', 'span' => 3),
    );
}

/* ---------------- 模板辅助函数 ---------------- */

function tpl_primary($settings, $default = '#2563eb')
{
    $c = isset($settings['theme_color']) ? trim($settings['theme_color']) : '';
    return preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $c) ? $c : $default;
}

function avatar_url($profile)
{
    $a = isset($profile['basic']['avatar']) ? trim($profile['basic']['avatar']) : '';
    if ($a === '') {
        return '';
    }
    if (preg_match('#^(https?:)?//#i', $a)) {
        return $a;
    }
    return app_url(ltrim(str_replace('\\', '/', $a), '/'));
}

function tpl_ml($value)
{
    return nl2br(e($value));
}

/**
 * 把多行文本拆成条目数组
 */
function tpl_lines($value)
{
    $lines = preg_split('/\r\n|\r|\n/', (string)$value);
    $out = array();
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line !== '') {
            $out[] = $line;
        }
    }
    return $out;
}

function social_list($profile)
{
    $map = array(
        'github'   => array('GitHub', 'github'),
        'linkedin' => array('LinkedIn', 'linkedin'),
        'weibo'    => array('微博', 'weibo'),
        'wechat'   => array('微信', 'wechat'),
        'qq'       => array('QQ', 'qq'),
    );
    $out = array();
    foreach ($map as $key => $meta) {
        $v = isset($profile['basic'][$key]) ? trim($profile['basic'][$key]) : '';
        if ($v === '') {
            continue;
        }
        $url = preg_match('#^(https?:)?//#i', $v) ? $v : '';
        $out[] = array('label' => $meta[0], 'icon' => $meta[1], 'value' => $v, 'url' => $url);
    }
    return $out;
}

function date_range($start, $end)
{
    $s = trim((string)$start);
    $e = trim((string)$end);
    if ($s === '' && $e === '') {
        return '';
    }
    return $s . ($s !== '' && $e !== '' ? ' ~ ' : '') . $e;
}

/**
 * 项目标签徽章（如 Star 数、开源标记）
 */
function tpl_tag($item, $extraStyle = '')
{
    $tag = isset($item['tag']) ? trim((string)$item['tag']) : '';
    if ($tag === '') {
        return '';
    }
    return '<span class="ptag" style="display:inline-flex;align-items:center;gap:3px;vertical-align:1px;'
        . 'background:var(--chip);color:var(--text-2);border:1px solid var(--border-2);border-radius:5px;'
        . 'padding:0 6px;font-size:11.5px;line-height:17px;margin-left:6px;white-space:nowrap'
        . ($extraStyle ? ';' . $extraStyle : '') . '">' . e($tag) . '</span>';
}
