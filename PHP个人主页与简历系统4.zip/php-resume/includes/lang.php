<?php
/**
 * 国际化（i18n）：全站语言包
 *
 * 语言优先级：URL ?lang= > Cookie > 后台默认设置 > zh
 */

function lang_list()
{
    return array(
        'zh' => '简体中文',
        'en' => 'English',
    );
}

function lang_name($code)
{
    $all = lang_list();
    return isset($all[$code]) ? $all[$code] : $code;
}

/**
 * 解析当前语言
 */
function current_lang()
{
    if (!isset($GLOBALS['__lang'])) {
        $all = lang_list();
        $lang = '';
        // URL 参数（用于无 JS 环境或分享链接）
        if (!empty($_GET['lang']) && isset($all[$_GET['lang']])) {
            $lang = $_GET['lang'];
        } elseif (!empty($_COOKIE['pr_lang']) && isset($all[$_COOKIE['pr_lang']])) {
            $lang = $_COOKIE['pr_lang'];
        } else {
            $settings = array();
            if (function_exists('is_installed') && is_installed()) {
                $settings = get_data('settings', array());
            }
            $lang = isset($settings['language']) ? $settings['language'] : 'zh';
        }
        if (!isset($all[$lang])) {
            $lang = 'zh';
        }
        $GLOBALS['__lang'] = $lang;
    }
    return $GLOBALS['__lang'];
}

/**
 * 翻译：t('key') 或 t('key', $arg1, $arg2)
 */
function t($key)
{
    static $pack = null;
    if ($pack === null) {
        $lang = current_lang();
        $file = __DIR__ . '/lang/' . basename($lang) . '.php';
        $pack = is_file($file) ? (array)(include $file) : array();
    }
    $value = isset($pack[$key]) ? $pack[$key] : $key;
    $args = func_get_args();
    array_shift($args);
    if ($args && substr_count($value, '%s') === count($args)) {
        $value = vsprintf($value, $args);
    }
    return $value;
}

/**
 * 输出翻译（自动转义）
 */
function te($key)
{
    return e(t($key));
}

/**
 * 设置语言 Cookie 并立即生效
 */
function set_lang($lang)
{
    if (!isset(lang_list()[$lang])) {
        return false;
    }
    setcookie('pr_lang', $lang, time() + 86400 * 365, '/', '', false, false);
    $_COOKIE['pr_lang'] = $lang;
    unset($GLOBALS['__lang']);
    return true;
}
