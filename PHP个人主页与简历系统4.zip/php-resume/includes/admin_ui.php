<?php
/**
 * 后台界面组件：布局、表单控件、重复组编辑器
 */

function admin_header($title = '', $active = '')
{
    $title = $title ?: t('admin_panel');
    $store = storage();
    $flash = take_flash();
    $lang = current_lang();
    ?>
    <!doctype html>
    <html <?= theme_html_attrs() ?>>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= e($title) ?> - <?= te('admin_panel') ?></title>
        <link rel="stylesheet" href="../assets/pref.css">
    <?= theme_head_css() ?>
        <link rel="stylesheet" href="../assets/admin.css">
    </head>
    <body>
    <div class="layout">
        <aside class="sidebar">
            <div class="brand">个人主页<span>管理系统</span></div>
            <nav>
                <a href="index.php" class="<?= $active === 'index' ? 'on' : '' ?>"><?= icon('chart') ?><?= te('dashboard') ?></a>
                <a href="profile.php" class="<?= $active === 'profile' ? 'on' : '' ?>"><?= icon('user') ?><?= te('profile') ?></a>
                <a href="templates.php" class="<?= $active === 'templates' ? 'on' : '' ?>"><?= icon('layout') ?><?= te('templates') ?></a>
                <a href="themes.php" class="<?= $active === 'themes' ? 'on' : '' ?>"><?= icon('palette') ?><?= te('theme_panels') ?></a>
                <a href="visits.php" class="<?= $active === 'visits' ? 'on' : '' ?>"><?= icon('gauge') ?><?= te('visits') ?></a>
                <a href="settings.php" class="<?= $active === 'settings' ? 'on' : '' ?>"><?= icon('sliders') ?><?= te('settings') ?></a>
                <div class="sep"></div>
                <a href="../index.php" target="_blank"><?= icon('globe') ?><?= te('preview_home') ?></a>
                <a href="../resume.php" target="_blank"><?= icon('print') ?><?= te('preview_resume') ?></a>
                <a href="logout.php"><?= icon('key') ?><?= te('logout') ?></a>
            </nav>
            <div class="store-badge"><?= icon('database') ?> <?= e($store->label()) ?></div>
        </aside>
        <main class="content">
            <h1 class="page-title"><?= e($title) ?></h1>
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>">
                    <?= icon($flash['type'] === 'error' ? 'shield' : 'check') ?>
                    <span><?= e($flash['msg']) ?></span>
                </div>
            <?php endif; ?>
    <?php
}

function admin_footer()
{
    ?>
        </main>
    </div>
    <?= theme_assets() ?>
    <script src="../assets/admin.js"></script>
    </body>
    </html>
    <?php
}

/**
 * 渲染一个字段
 */
function field_control($name, $field, $value = '')
{
    $type = isset($field['type']) ? $field['type'] : 'text';
    $span = isset($field['span']) ? (int)$field['span'] : 1;
    $ph = isset($field['ph']) ? $field['ph'] : '';
    $label = isset($field['label']) ? t($field['label']) : '';
    $html = '<div class="f f-' . $span . '"><label>' . e($label) . '</label>';
    if ($type === 'textarea') {
        $html .= '<textarea name="' . e($name) . '" placeholder="' . e($ph) . '">' . e($value) . '</textarea>';
    } elseif ($type === 'number') {
        $html .= '<input type="number" name="' . e($name) . '" value="' . e($value) . '" placeholder="' . e($ph) . '" min="0" max="100">';
    } elseif ($type === 'email') {
        $html .= '<input type="email" name="' . e($name) . '" value="' . e($value) . '" placeholder="' . e($ph) . '">';
    } else {
        $html .= '<input type="text" name="' . e($name) . '" value="' . e($value) . '" placeholder="' . e($ph) . '">';
    }
    $html .= '</div>';
    return $html;
}

/**
 * 渲染重复组编辑器
 */
function repeater($group, $label, array $fields, array $rows, $iconName = '')
{
    $rows = array_values($rows);
    if (empty($rows)) {
        $rows = array(array());
    }
    echo '<div class="repeater" data-group="' . e($group) . '" id="' . e($group) . '-block">';
    echo '<div class="rep-head"><h3>' . ($iconName ? icon($iconName) : '') . e($label) . '</h3>'
        . '<button type="button" class="btn btn-sm" data-add="' . e($group) . '">' . icon('add', array('class' => '')) . t('add') . '</button></div>';
    echo '<div class="rep-list" id="list-' . e($group) . '">';
    foreach ($rows as $i => $row) {
        echo '<div class="rep-item">';
        echo '<div class="rep-bar"><span class="idx">' . e($label) . ' #' . ($i + 1) . '</span>'
            . '<button type="button" class="btn-del" data-del>' . icon('trash') . t('delete') . '</button></div>';
        echo '<div class="grid">';
        foreach ($fields as $key => $field) {
            $val = isset($row[$key]) ? $row[$key] : '';
            echo field_control($group . '[' . $i . '][' . $key . ']', $field, $val);
        }
        echo '</div></div>';
    }
    echo '</div>';
    // 新增行的模板
    echo '<script type="text/template" id="tpl-' . e($group) . '">';
    echo '<div class="rep-item"><div class="rep-bar"><span class="idx">' . e($label) . ' #N</span>'
        . '<button type="button" class="btn-del" data-del>' . icon('trash') . t('delete') . '</button></div><div class="grid">';
    foreach ($fields as $key => $field) {
        echo field_control($group . '[__i__][' . $key . ']', $field, '');
    }
    echo '</div></div></script>';
    echo '</div>';
}
