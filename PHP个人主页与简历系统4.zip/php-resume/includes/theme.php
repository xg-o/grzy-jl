<?php
/**
 * 外观系统：内置主题面板 / 主题色 / 明暗模式 / 语言
 *
 * 优先级：Cookie（访客自选） > 后台默认设置 > 内置默认（azure + 跟随系统）
 */

/* ============================================================
   1. 内置主题面板
   ============================================================ */

/**
 * 面板定义：主色 + 辅助色 + 中性色相
 * 其余背景 / 文字 / 边框等由算法按 HSL 派生，保证明暗两套都协调
 */
function theme_builtin_panels()
{
    static $panels = null;
    if ($panels === null) {
        $panels = array(
            /* —— 经典 —— */
            'azure'    => array('zh' => '晴空蓝', 'en' => 'Azure',       'primary' => '#2563eb', 'accent' => '#7c3aed', 'neutral' => 220),
            'indigo'   => array('zh' => '靛青',   'en' => 'Indigo',      'primary' => '#4f46e5', 'accent' => '#6366f1', 'neutral' => 240),
            'ocean'    => array('zh' => '深海青', 'en' => 'Ocean',       'primary' => '#0891b2', 'accent' => '#0ea5e9', 'neutral' => 195),
            'jade'     => array('zh' => '青竹绿', 'en' => 'Jade',        'primary' => '#059669', 'accent' => '#10b981', 'neutral' => 160),
            /* —— 活力 —— */
            'amber'    => array('zh' => '琥珀橙', 'en' => 'Amber',       'primary' => '#d97706', 'accent' => '#f59e0b', 'neutral' => 30),
            'crimson'  => array('zh' => '朱砂红', 'en' => 'Crimson',     'primary' => '#dc2626', 'accent' => '#f43f5e', 'neutral' => 0),
            'rose'     => array('zh' => '玫粉',   'en' => 'Rose',        'primary' => '#db2777', 'accent' => '#ec4899', 'neutral' => 330),
            'violet'   => array('zh' => '紫罗兰', 'en' => 'Violet',      'primary' => '#7c3aed', 'accent' => '#a855f7', 'neutral' => 265),
            /* —— 自然 —— */
            'forest'   => array('zh' => '松林绿', 'en' => 'Forest',      'primary' => '#16a34a', 'accent' => '#65a30d', 'neutral' => 140),
            'teal'     => array('zh' => '湖蓝绿', 'en' => 'Teal',        'primary' => '#0d9488', 'accent' => '#14b8a6', 'neutral' => 175),
            'gold'     => array('zh' => '流金',   'en' => 'Gold',        'primary' => '#b45309', 'accent' => '#ca8a04', 'neutral' => 40),
            'mocha'    => array('zh' => '摩卡',   'en' => 'Mocha',       'primary' => '#78350f', 'accent' => '#92400e', 'neutral' => 25),
            /* —— 沉稳 —— */
            'graphite' => array('zh' => '石墨',   'en' => 'Graphite',    'primary' => '#334155', 'accent' => '#64748b', 'neutral' => 215),
            'ink'      => array('zh' => '墨黑',   'en' => 'Ink',         'primary' => '#0f172a', 'accent' => '#334155', 'neutral' => 220),
            'plum'     => array('zh' => '青梅',   'en' => 'Plum',        'primary' => '#9333ea', 'accent' => '#c026d3', 'neutral' => 290),
            'sky'      => array('zh' => '天蓝',   'en' => 'Sky',         'primary' => '#0284c7', 'accent' => '#38bdf8', 'neutral' => 205),
        );
    }
    return $panels;
}

/* ============================================================
   1b. 自定义面板：存储 / 增删改查 / 导入导出
   ============================================================ */

/** 数据键名（同时用于备份导出与存储迁移） */
define('THEME_DATA_KEY', 'themes');

/** 合法的面板分组 */
function theme_group_keys()
{
    return array('classic' => 1, 'vivid' => 1, 'nature' => 1, 'calm' => 1, 'custom' => 1);
}

/**
 * 读取面板元数据：array(custom => [...], hidden => [...])
 */
function theme_meta()
{
    if (isset($GLOBALS['__theme_meta']) && $GLOBALS['__theme_meta'] !== null) {
        return $GLOBALS['__theme_meta'];
    }
    $meta = array('custom' => array(), 'hidden' => array());
    if (function_exists('is_installed') && is_installed()) {
        $raw = get_data(THEME_DATA_KEY, array());
        if (isset($raw['custom']) && is_array($raw['custom'])) {
            $meta['custom'] = $raw['custom'];
        }
        if (isset($raw['hidden']) && is_array($raw['hidden'])) {
            $meta['hidden'] = $raw['hidden'];
        }
    }
    $GLOBALS['__theme_meta'] = $meta;
    return $meta;
}

function theme_meta_save(array $meta)
{
    $GLOBALS['__theme_meta'] = $meta;
    // 清掉所有面板相关缓存
    $GLOBALS['__theme_panels'] = null;
    save_data(THEME_DATA_KEY, $meta);
    return true;
}

/**
 * 合并后的面板列表（内置 - 已停用 + 自定义）
 */
function theme_panels()
{
    if (isset($GLOBALS['__theme_panels']) && $GLOBALS['__theme_panels'] !== null) {
        return $GLOBALS['__theme_panels'];
    }
    $meta = theme_meta();
    $builtin = theme_builtin_panels();
    $out = array();
    foreach ($builtin as $key => $p) {
        if (!empty($meta['hidden'][$key])) {
            continue;
        }
        $p['source'] = 'builtin';
        $p['group'] = theme_builtin_group($key);
        $out[$key] = $p;
    }
    foreach ($meta['custom'] as $key => $p) {
        if (!is_array($p) || empty($p['primary'])) {
            continue;
        }
        $p['source'] = 'custom';
        if (!isset($p['group']) || !isset(theme_group_keys()[$p['group']])) {
            $p['group'] = 'custom';
        }
        $out[$key] = $p;
    }
    $GLOBALS['__theme_panels'] = $out;
    return $out;
}

/**
 * 内置面板所属分组
 */
function theme_builtin_group($key)
{
    foreach (theme_builtin_groups() as $gk => $g) {
        if (in_array($key, $g['items'], true)) {
            return $gk;
        }
    }
    return 'custom';
}

/**
 * 内置分组定义（不含自定义项）
 */
function theme_builtin_groups()
{
    return array(
        'classic' => array('zh' => '经典', 'en' => 'Classic',  'items' => array('azure', 'indigo', 'ocean', 'jade')),
        'vivid'   => array('zh' => '活力', 'en' => 'Vivid',    'items' => array('amber', 'crimson', 'rose', 'violet')),
        'nature'  => array('zh' => '自然', 'en' => 'Nature',   'items' => array('forest', 'teal', 'gold', 'mocha')),
        'calm'    => array('zh' => '沉稳', 'en' => 'Calm',     'items' => array('graphite', 'ink', 'plum', 'sky')),
    );
}

/**
 * 面板：内置 + 自定义；内置分组按 source 过滤掉被停用的项
 */
function theme_panel_groups()
{
    $all = theme_panels();
    $groups = theme_builtin_groups();
    foreach ($groups as $gk => $g) {
        $groups[$gk]['items'] = array_values(array_filter($g['items'], function ($k) use ($all) {
            return isset($all[$k]);
        }));
    }
    $custom = array();
    foreach ($all as $key => $p) {
        if ($p['source'] === 'custom' && ($p['group'] === 'custom' || !isset($groups[$p['group']]))) {
            $custom[] = $key;
        }
    }
    if ($custom) {
        $lang = current_lang();
        $groups['custom'] = array('zh' => '自定义', 'en' => 'Custom', 'items' => $custom);
    }
    // 归入内置分组的自定义面板
    foreach ($all as $key => $p) {
        if ($p['source'] === 'custom' && isset($groups[$p['group']]) && $p['group'] !== 'custom'
            && !in_array($key, $groups[$p['group']]['items'], true)) {
            $groups[$p['group']]['items'][] = $key;
        }
    }
    return array_filter($groups, function ($g) { return !empty($g['items']); });
}

/**
 * 面板来源：builtin / custom / hidden
 */
function theme_panel_source($key)
{
    $all = theme_panels();
    if (isset($all[$key])) {
        return $all[$key]['source'];
    }
    $meta = theme_meta();
    if (!empty($meta['hidden'][$key])) {
        return 'hidden';
    }
    return '';
}

/**
 * 规范 key：小写、仅保留 a-z0-9_，长度 2~24
 */
function theme_normalize_key($key)
{
    $key = strtolower(trim((string)$key));
    $key = preg_replace('/[^a-z0-9_]+/', '_', $key);
    $key = trim($key, '_');
    if ($key === '') {
        return '';
    }
    if (strlen($key) < 2) {
        $key = 'panel_' . $key;
    }
    return substr($key, 0, 24);
}

/**
 * 校验并规范化一个面板定义
 * 返回 array(ok, msg, panel)
 */
function theme_normalize_panel(array $in, $forceKey = '')
{
    $zh = trim((string)($in['zh'] ?? ''));
    $en = trim((string)($in['en'] ?? ''));
    $primary = trim((string)($in['primary'] ?? ''));
    $accent = trim((string)($in['accent'] ?? ''));
    $neutral = (int)($in['neutral'] ?? 220);
    $group = trim((string)($in['group'] ?? 'custom'));

    if ($primary === '' && $zh === '' && $en === '') {
        return array(false, '缺少面板名称与主色', array());
    }
    if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $primary)) {
        return array(false, '主色格式不正确：' . $primary, array());
    }
    if ($accent === '') {
        $accent = $primary;
    }
    if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $accent)) {
        $accent = $primary;
    }
    if ($zh === '') {
        $zh = $en !== '' ? $en : '未命名';
    }
    if ($en === '') {
        $en = $zh;
    }
    $neutral = max(0, min(360, $neutral));
    if (!isset(theme_group_keys()[$group])) {
        $group = 'custom';
    }
    $key = $forceKey !== '' ? $forceKey : theme_normalize_key($in['key'] ?? '');
    if ($key === '') {
        $key = theme_normalize_key($en);
    }
    if ($key === '') {
        $key = 'panel_' . substr(md5($primary . $zh), 0, 6);
    }
    return array(true, '', array(
        'zh'      => str_cut($zh, 20),
        'en'      => str_cut($en, 30),
        'primary' => strtolower($primary),
        'accent'  => strtolower($accent),
        'neutral' => $neutral,
        'group'   => $group,
        'key'     => $key,
    ));
}

/**
 * 生成一个不与内置/现有冲突的 key
 */
function theme_unique_key($key, array $exclude = array())
{
    $builtin = theme_builtin_panels();
    $meta = theme_meta();
    $base = $key;
    $i = 2;
    while (isset($builtin[$key]) || isset($meta['custom'][$key]) || isset($exclude[$key])) {
        $key = $base . '_' . $i;
        $i++;
    }
    return $key;
}

/**
 * 新增 / 更新自定义面板
 */
function theme_put_panel(array $panel, $allowOverwriteBuiltin = false)
{
    $meta = theme_meta();
    $key = $panel['key'];
    unset($panel['key']);
    if (!$allowOverwriteBuiltin && isset(theme_builtin_panels()[$key])) {
        return array(false, '该名称属于内置面板，请换一个标识');
    }
    $panel['source'] = 'custom';
    $meta['custom'][$key] = $panel;
    theme_meta_save($meta);
    return array(true, $key);
}

function theme_delete_panel($key)
{
    $meta = theme_meta();
    $all = theme_panels();
    if (!isset($all[$key])) {
        return array(false, '面板不存在');
    }
    if ($all[$key]['source'] === 'builtin') {
        // 内置面板：停用（可恢复）
        $meta['hidden'][$key] = 1;
        theme_meta_save($meta);
        return array(true, 'hidden');
    }
    unset($meta['custom'][$key]);
    theme_meta_save($meta);
    return array(true, 'deleted');
}

function theme_restore_panel($key)
{
    $meta = theme_meta();
    if (empty($meta['hidden'][$key])) {
        return array(false, '该面板未被停用');
    }
    unset($meta['hidden'][$key]);
    theme_meta_save($meta);
    return array(true, 'restored');
}

/**
 * 停用（隐藏）的内置面板列表
 */
function theme_hidden_panels()
{
    $meta = theme_meta();
    $builtin = theme_builtin_panels();
    $out = array();
    foreach ($meta['hidden'] as $key => $v) {
        if ($v && isset($builtin[$key])) {
            $p = $builtin[$key];
            $p['source'] = 'hidden';
            $p['group'] = theme_builtin_group($key);
            $out[$key] = $p;
        }
    }
    return $out;
}

/**
 * 导出数据
 * $scope: all | custom | 指定 key
 */
function theme_export_payload($scope = 'all')
{
    if ($scope === 'custom') {
        $src = array();
        foreach (theme_panels() as $k => $p) {
            if ($p['source'] === 'custom') {
                $src[$k] = $p;
            }
        }
    } elseif ($scope === 'all') {
        $src = theme_panels();
    } else {
        $all = theme_panels();
        $src = isset($all[$scope]) ? array($scope => $all[$scope]) : array();
    }
    $out = array();
    foreach ($src as $k => $p) {
        $out[] = array(
            'key'     => $k,
            'zh'      => $p['zh'],
            'en'      => $p['en'],
            'primary' => $p['primary'],
            'accent'  => $p['accent'],
            'neutral' => (int)$p['neutral'],
            'group'   => $p['group'],
        );
    }
    return array(
        'app'    => 'php-resume-theme',
        'version' => defined('APP_VERSION') ? APP_VERSION : '1.0.0',
        'time'   => date('Y-m-d H:i:s'),
        'panels' => $out,
    );
}

/**
 * 导入数据
 * $mode: skip（跳过同名）| overwrite（覆盖）| rename（自动改名）
 * 返回 array(added, updated, renamed, skipped, errors)
 */
function theme_import_payload($raw, $mode = 'rename')
{
    if (is_string($raw)) {
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            return array(0, 0, 0, 0, array('JSON 解析失败或内容为空'));
        }
    } elseif (is_array($raw)) {
        $data = $raw;
    } else {
        return array(0, 0, 0, 0, array('不支持的数据格式'));
    }

    // 兼容多种结构
    $list = array();
    if (isset($data['panels'])) {
        if (is_array($data['panels'])) {
            // {"key": {...}} 或 [ {...}, {...} ]
            $isAssoc = !isset($data['panels'][0]) && $data['panels'];
            if ($isAssoc) {
                foreach ($data['panels'] as $k => $p) {
                    if (is_array($p)) {
                        $p['key'] = isset($p['key']) ? $p['key'] : $k;
                        $list[] = $p;
                    }
                }
            } else {
                $list = $data['panels'];
            }
        }
    } elseif (isset($data['key']) || isset($data['primary'])) {
        $list = array($data);
    } else {
        $list = $data;
    }

    $meta = theme_meta();
    $builtin = theme_builtin_panels();
    $added = $updated = $renamed = $skipped = 0;
    $errors = array();

    foreach ($list as $i => $item) {
        if (!is_array($item)) {
            $errors[] = '第 ' . ($i + 1) . ' 项不是对象';
            continue;
        }
        list($ok, $msg, $panel) = theme_normalize_panel($item);
        if (!$ok) {
            $errors[] = '第 ' . ($i + 1) . ' 项：' . $msg;
            continue;
        }
        $key = $panel['key'];
        $isBuiltin = isset($builtin[$key]);
        $existsCustom = isset($meta['custom'][$key]);

        if ($isBuiltin && $mode !== 'overwrite') {
            // 内置面板：不允许覆盖，自动改名（skip 模式下直接跳过）
            if ($mode === 'skip') {
                $skipped++;
                continue;
            }
            $newKey = theme_unique_key($key);
            $panel['key'] = $newKey;
            $key = $newKey;
            $renamed++;
        } elseif ($existsCustom && $mode === 'skip') {
            $skipped++;
            continue;
        } elseif ($existsCustom && $mode === 'rename') {
            $newKey = theme_unique_key($key);
            $panel['key'] = $newKey;
            $key = $newKey;
            $renamed++;
        } elseif ($existsCustom) {
            $updated++;
        } else {
            $added++;
        }
        unset($panel['key']);
        $panel['source'] = 'custom';
        $meta['custom'][$key] = $panel;
    }
    theme_meta_save($meta);
    return array($added, $updated, $renamed, $skipped, $errors);
}

function panel_name($key)
{
    $all = theme_panels();
    if (!isset($all[$key])) {
        return $key;
    }
    $lang = current_lang();
    $p = $all[$key];
    return isset($p[$lang]) && $p[$lang] !== '' ? $p[$lang] : $p['zh'];
}

/* ============================================================
   2. 颜色工具
   ============================================================ */

function hex_to_hsl($hex)
{
    $hex = ltrim((string)$hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if (strlen($hex) !== 6 || !ctype_xdigit($hex)) {
        return array(220, 80, 50);
    }
    $r = hexdec(substr($hex, 0, 2)) / 255;
    $g = hexdec(substr($hex, 2, 2)) / 255;
    $b = hexdec(substr($hex, 4, 2)) / 255;
    $max = max($r, $g, $b);
    $min = min($r, $g, $b);
    $h = 0;
    $s = 0;
    $l = ($max + $min) / 2;
    $d = $max - $min;
    if ($d > 0) {
        $s = $l > 0.5 ? $d / (2 - $max - $min) : $d / ($max + $min);
        if ($max === $r) {
            $h = (($g - $b) / $d + ($g < $b ? 6 : 0));
        } elseif ($max === $g) {
            $h = ($b - $r) / $d + 2;
        } else {
            $h = ($r - $g) / $d + 4;
        }
        $h *= 60;
    }
    return array(round($h), round($s * 100), round($l * 100));
}

/**
 * HSL → RGB（0~1）
 */
function hsl_to_rgb($h, $s, $l)
{
    $h = fmod((float)$h, 360) / 360;
    $s = max(0, min(100, (float)$s)) / 100;
    $l = max(0, min(100, (float)$l)) / 100;
    if ($s <= 0) {
        return array($l, $l, $l);
    }
    $q = $l < 0.5 ? $l * (1 + $s) : $l + $s - $l * $s;
    $p = 2 * $l - $q;
    $f = function ($t) use ($p, $q) {
        $t = fmod($t + 1, 1);
        if ($t < 1 / 6) {
            return $p + ($q - $p) * 6 * $t;
        }
        if ($t < 1 / 2) {
            return $q;
        }
        if ($t < 2 / 3) {
            return $p + ($q - $p) * (2 / 3 - $t) * 6;
        }
        return $p;
    };
    return array($f($h + 1 / 3), $f($h), $f($h - 1 / 3));
}

/**
 * 相对亮度（WCAG）
 */
function rel_luminance($rgb)
{
    $f = function ($v) {
        $v = max(0, min(1, $v));
        return $v <= 0.03928 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * $f($rgb[0]) + 0.7152 * $f($rgb[1]) + 0.0722 * $f($rgb[2]);
}

/**
 * 对比度：hsl 数组 vs 固定 rgb
 */
function contrast_ratio($hsl, $bgRgb)
{
    $l1 = rel_luminance(hsl_to_rgb($hsl[0], $hsl[1], $hsl[2]));
    $l2 = rel_luminance($bgRgb);
    $hi = max($l1, $l2);
    $lo = min($l1, $l2);
    return ($hi + 0.05) / ($lo + 0.05);
}

/**
 * 在保持色相/饱和度的前提下，把亮度调整到满足对比度目标
 */
function fit_lightness($hsl, $bgRgb, $target, $dark)
{
    $h = $hsl[0];
    $s = $hsl[1];
    $l = $hsl[2];
    if ($dark) {
        for ($i = $l; $i <= 82; $i += 1) {
            if (contrast_ratio(array($h, $s, $i), $bgRgb) >= $target) {
                return min($i, 82);
            }
        }
        return 82;
    }
    for ($i = $l; $i >= 24; $i -= 1) {
        if (contrast_ratio(array($h, $s, $i), $bgRgb) >= $target) {
            return max($i, 24);
        }
    }
    return 24;
}

function hsl_str($hsl, $alpha = null)
{
    $h = round($hsl[0]);
    $s = round(max(0, min(100, $hsl[1])));
    $l = round(max(0, min(100, $hsl[2])));
    if ($alpha !== null && $alpha < 1) {
        return 'hsla(' . $h . ',' . $s . '%,' . $l . '%,' . round($alpha, 3) . ')';
    }
    return 'hsl(' . $h . ',' . $s . '%,' . $l . '%)';
}

/**
 * 派生一套变量
 */
function panel_vars($key, $dark)
{
    $all = theme_panels();
    if (!isset($all[$key])) {
        $key = 'azure';
    }
    $p = $all[$key];
    $pr = hex_to_hsl($p['primary']);
    $ac = hex_to_hsl($p['accent']);
    $n = (int)$p['neutral'];

    if ($dark) {
        // 深底：主色提亮到满足对比度（≥4.6），保证在深色背景上清晰
        $bgRgb = hsl_to_rgb($n, 26, 8);
        $pr[1] = min($pr[1], 88);
        $pr[2] = max($pr[2], 62);
        $pr[2] = fit_lightness($pr, $bgRgb, 4.6, true);
        $ac[2] = max($ac[2], 66);
        $ac[2] = fit_lightness($ac, $bgRgb, 3.2, true);
        $v = array(
            'primary'  => hsl_str($pr),
            'accent'   => hsl_str($ac),
            'bg'       => hsl_str(array($n, 26, 8)),
            'panel'    => hsl_str(array($n, 22, 12)),
            'panel-2'  => hsl_str(array($n, 22, 10)),
            'text'     => hsl_str(array($n, 22, 90)),
            'text-2'   => hsl_str(array($n, 16, 66)),
            'text-3'   => hsl_str(array($n, 13, 48)),
            'border'   => hsl_str(array($n, 19, 21)),
            'border-2' => hsl_str(array($n, 19, 17)),
            'chip'     => 'rgba(255,255,255,.07)',
            'glow'     => hsl_str($ac, .16),
            'glow-2'   => hsl_str($pr, .14),
        );
    } else {
        // 亮底：主色压暗到可读区间（白底对比度 ≥4.6）
        $white = array(1, 1, 1);
        $pr[2] = min($pr[2], 48);
        $pr[2] = fit_lightness($pr, $white, 4.6, false);
        $ac[2] = min($ac[2], 52);
        $ac[2] = fit_lightness($ac, $white, 3.2, false);
        $v = array(
            'primary'  => hsl_str($pr),
            'accent'   => hsl_str($ac),
            'bg'       => hsl_str(array($n, 32, 97)),
            'panel'    => '#ffffff',
            'panel-2'  => hsl_str(array($n, 32, 98)),
            'text'     => hsl_str(array($n, 26, 17)),
            'text-2'   => hsl_str(array($n, 13, 42)),
            'text-3'   => hsl_str(array($n, 11, 60)),
            'border'   => hsl_str(array($n, 26, 90)),
            'border-2' => hsl_str(array($n, 26, 94)),
            'chip'     => hsl_str(array($n, 26, 95)),
            'glow'     => hsl_str($ac, .13),
            'glow-2'   => hsl_str($pr, .12),
        );
    }
    $v['sidebar-bg'] = $dark ? hsl_str(array($n, 24, 9)) : hsl_str(array($n, 30, 15));
    $v['sidebar-text'] = $dark ? hsl_str(array($n, 16, 74)) : hsl_str(array($n, 14, 76));
    $v['sidebar-hover'] = $dark ? hsl_str(array($n, 22, 15)) : hsl_str(array($n, 28, 21));
    return $v;
}

/**
 * 生成全部面板 CSS（压缩输出）
 */
function theme_head_css()
{
    static $css = null;
    if ($css !== null) {
        return $css;
    }
    $out = '';
    foreach (theme_panels() as $key => $p) {
        // 亮色
        $v = panel_vars($key, false);
        $decl = '';
        foreach ($v as $name => $val) {
            $decl .= '--' . $name . ':' . $val . ';';
        }
        $out .= 'html[data-panel="' . $key . '"],html.light[data-panel="' . $key . '"]{' . $decl . '}';
        // 深色
        $v = panel_vars($key, true);
        $decl = '';
        foreach ($v as $name => $val) {
            $decl .= '--' . $name . ':' . $val . ';';
        }
        $out .= 'html.dark[data-panel="' . $key . '"]{' . $decl . '}';
        $out .= '@media(prefers-color-scheme:dark){html.auto-mode[data-panel="' . $key . '"]{' . $decl . '}}';
    }
    // 自定义主色（若有）覆盖面板主色，放在最后确保优先生效，避免首屏闪烁
    $custom = theme_color();
    if ($custom !== '') {
        $out .= 'html[data-panel]{--primary:' . $custom . ';}';
    }
    $css = '<style id="theme-panels">' . $out . '</style>';
    return $css;
}

/**
 * <html> 标签属性：语言 + 模式 class + 面板
 */
function theme_html_attrs()
{
    return 'lang="' . e(current_lang()) . '" class="' . e(theme_html_class()) . '" data-panel="' . e(theme_panel()) . '"';
}

/* ============================================================
   3. 当前取值
   ============================================================ */

function default_settings_cached()
{
    if (function_exists('is_installed') && is_installed()) {
        return get_data('settings', array());
    }
    return array();
}

/**
 * 当前面板：Cookie > 设置 > azure
 */
function theme_panel()
{
    if (!empty($_COOKIE['pr_panel']) && isset(theme_panels()[$_COOKIE['pr_panel']])) {
        return $_COOKIE['pr_panel'];
    }
    $s = default_settings_cached();
    $p = isset($s['theme_panel']) ? $s['theme_panel'] : '';
    return isset(theme_panels()[$p]) ? $p : 'azure';
}

/**
 * 自定义主色（可能为空，表示跟随面板）
 */
function theme_color()
{
    if (!empty($_COOKIE['pr_theme']) && preg_match('/^#[0-9a-fA-F]{6}$/', $_COOKIE['pr_theme'])) {
        return $_COOKIE['pr_theme'];
    }
    $s = default_settings_cached();
    $c = isset($s['theme_color']) ? trim($s['theme_color']) : '';
    // 设置里的主色必须与面板主色不同才视为“自定义”，否则跟随面板
    if ($c !== '' && preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $c)) {
        $pk = isset($s['theme_panel']) ? $s['theme_panel'] : 'azure';
        $all = theme_panels();
        $panel = isset($all[$pk]) ? $all[$pk] : false;
        if (!is_array($panel) || strtolower($c) !== strtolower($panel['primary'])) {
            return $c;
        }
    }
    return '';
}

/**
 * 当前显示模式
 */
function theme_mode()
{
    if (!empty($_COOKIE['pr_mode']) && in_array($_COOKIE['pr_mode'], array('light', 'dark', 'auto'), true)) {
        return $_COOKIE['pr_mode'];
    }
    $s = default_settings_cached();
    $m = isset($s['default_mode']) ? $s['default_mode'] : 'auto';
    return in_array($m, array('light', 'dark', 'auto'), true) ? $m : 'auto';
}

function theme_html_class()
{
    $m = theme_mode();
    return $m === 'dark' ? 'dark' : ($m === 'light' ? 'light' : 'auto-mode');
}

/* ============================================================
   4. 右上角偏好控件
   ============================================================ */

/**
 * 单色快捷色板（自定义主色用）
 */
function theme_swatches()
{
    return array(
        '#2563eb' => array('zh' => '蓝', 'en' => 'Blue'),
        '#0ea5e9' => array('zh' => '青', 'en' => 'Cyan'),
        '#10b981' => array('zh' => '绿', 'en' => 'Green'),
        '#f59e0b' => array('zh' => '橙', 'en' => 'Amber'),
        '#ef4444' => array('zh' => '红', 'en' => 'Red'),
        '#8b5cf6' => array('zh' => '紫', 'en' => 'Violet'),
        '#ec4899' => array('zh' => '粉', 'en' => 'Pink'),
        '#0f172a' => array('zh' => '墨', 'en' => 'Ink'),
    );
}

function theme_pref_bar()
{
    $panel = theme_panel();
    $lang = current_lang();
    $panels = theme_panels();
    $groups = theme_panel_groups();
    ob_start(); ?>
    <div class="pref" id="pref">
        <button type="button" class="pref-btn" data-panel-btn="mode" title="<?= te('pref_mode') ?>" aria-label="<?= te('pref_mode') ?>">
            <?= icon('auto') ?>
        </button>
        <button type="button" class="pref-btn" data-panel-btn="theme" title="<?= te('pref_theme') ?>" aria-label="<?= te('pref_theme') ?>">
            <?= icon('palette') ?>
        </button>
        <button type="button" class="pref-btn" data-panel-btn="lang" title="<?= te('pref_lang') ?>" aria-label="<?= te('pref_lang') ?>">
            <?= icon('globe') ?>
        </button>

        <div class="pref-panel" data-for="mode">
            <div class="pp-title"><?= te('pref_mode') ?></div>
            <button type="button" class="pp-item" data-set-mode="light">
                <?= icon('sun') ?><span><?= te('mode_light') ?></span><?= icon('check', array('class' => 'pp-check')) ?>
            </button>
            <button type="button" class="pp-item" data-set-mode="dark">
                <?= icon('moon') ?><span><?= te('mode_dark') ?></span><?= icon('check', array('class' => 'pp-check')) ?>
            </button>
            <button type="button" class="pp-item" data-set-mode="auto">
                <?= icon('auto') ?><span><?= te('mode_auto') ?></span><?= icon('check', array('class' => 'pp-check')) ?>
            </button>
        </div>

        <div class="pref-panel pref-panel-wide" data-for="theme">
            <div class="pp-title"><?= te('pref_panel') ?></div>
            <div class="pp-search">
                <?= icon('search') ?>
                <input type="text" id="pp-search" placeholder="<?= te('panel_search_ph') ?>" autocomplete="off">
            </div>
            <div class="pp-panels">
                <?php foreach ($groups as $gk => $g): ?>
                    <div class="pp-group" data-group-block="<?= e($gk) ?>">
                        <div class="pp-gname"><?= e($g[$lang] ?? $g['zh']) ?></div>
                        <div class="pp-gitems">
                            <?php foreach ($g['items'] as $key):
                                $p = $panels[$key];
                                $nm = $p[$lang] ?? $p['zh']; ?>
                                <button type="button" class="pp-panel <?= $key === $panel ? 'active' : '' ?>"
                                        data-set-panel="<?= e($key) ?>"
                                        data-search="<?= e(strtolower($nm . ' ' . $key . ' ' . ($p['en'] ?? '') . ' ' . ($p['zh'] ?? ''))) ?>"
                                        title="<?= e($nm) ?>">
                                    <i style="background:linear-gradient(135deg,<?= e($p['primary']) ?>,<?= e($p['accent']) ?>)"></i>
                                    <span><?= e($nm) ?></span>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="pp-empty" id="pp-empty" style="display:none"><?= te('panel_no_match') ?></div>
            </div>
            <div class="pp-title pp-title-2"><?= te('pref_theme') ?></div>
            <div class="pp-colors">
                <?php foreach (theme_swatches() as $hex => $lb): ?>
                    <button type="button" class="pp-color" data-set-color="<?= e($hex) ?>"
                            title="<?= e($lb[$lang] ?? $lb['zh']) ?>" style="background:<?= e($hex) ?>"><span></span></button>
                <?php endforeach; ?>
            </div>
            <div class="pp-reset">
                <button type="button" class="pp-linkbtn" data-reset-color><?= icon('refresh') ?><?= te('pref_reset') ?></button>
            </div>
        </div>

        <div class="pref-panel" data-for="lang">
            <div class="pp-title"><?= te('pref_lang') ?></div>
            <?php foreach (lang_list() as $code => $name): ?>
                <button type="button" class="pp-item" data-set-lang="<?= e($code) ?>">
                    <?= icon('globe2') ?><span><?= e($name) ?></span><?= icon('check', array('class' => 'pp-check')) ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 兜底脚本：若 pref.js 因缓存/拦截未加载，仍保证右上角三个按钮可用
 * 在 load 事件后检查 __prefReady，未就绪才接管，避免与 pref.js 重复绑定
 */
function theme_fallback_js()
{
    return <<<'JS'
(function(){
function ready(){
  if(window.__prefReady) return;
  var pref=document.getElementById('pref'); if(!pref) return;
  var root=document.documentElement;
  function ck(n,v){document.cookie=n+'='+encodeURIComponent(v)+';path=/;max-age=31536000;SameSite=Lax';}
  function panel(name){
    pref.querySelectorAll('.pref-panel').forEach(function(p){
      var on=p.getAttribute('data-for')===name && !p.classList.contains('open');
      p.classList.toggle('open',on);
    });
    pref.querySelectorAll('.pref-btn').forEach(function(b){
      b.classList.toggle('on', b.getAttribute('data-panel-btn')===name &&
        !!pref.querySelector('.pref-panel[data-for="'+name+'"].open'));
    });
  }
  pref.querySelectorAll('.pref-btn').forEach(function(btn){
    btn.addEventListener('click',function(e){e.stopPropagation();panel(btn.getAttribute('data-panel-btn'));});
  });
  pref.addEventListener('click',function(e){e.stopPropagation();});
  document.addEventListener('click',function(){
    pref.querySelectorAll('.pref-panel').forEach(function(p){p.classList.remove('open');});
    pref.querySelectorAll('.pref-btn').forEach(function(b){b.classList.remove('on');});
  });
  pref.querySelectorAll('[data-set-mode]').forEach(function(b){
    b.addEventListener('click',function(){
      var m=b.getAttribute('data-set-mode');
      root.classList.remove('dark','light','auto-mode'); root.classList.add(m==='dark'?'dark':(m==='light'?'light':'auto-mode'));
      ck('pr_mode',m); panel('mode');
    });
  });
  pref.querySelectorAll('[data-set-panel]').forEach(function(b){
    b.addEventListener('click',function(){
      var k=b.getAttribute('data-set-panel');
      root.setAttribute('data-panel',k); ck('pr_panel',k);
      document.cookie='pr_theme=;path=/;max-age=0;SameSite=Lax';
      root.style.removeProperty('--primary'); panel('theme');
    });
  });
  pref.querySelectorAll('[data-set-color]').forEach(function(b){
    b.addEventListener('click',function(){
      var c=b.getAttribute('data-set-color'); root.style.setProperty('--primary',c); ck('pr_theme',c); panel('theme');
    });
  });
  pref.querySelectorAll('[data-reset-color]').forEach(function(b){
    b.addEventListener('click',function(){
      root.style.removeProperty('--primary');
      document.cookie='pr_theme=;path=/;max-age=0;SameSite=Lax'; panel('theme');
    });
  });
  pref.querySelectorAll('[data-set-lang]').forEach(function(b){
    b.addEventListener('click',function(){ ck('pr_lang',b.getAttribute('data-set-lang')); location.reload(); });
  });
}
if(document.readyState==='complete') setTimeout(ready,50);
else window.addEventListener('load',function(){setTimeout(ready,50);});
})();
JS;
}

/**
 * 底部脚本 + 控件
 */
function theme_assets()
{
    // 后台预览 iframe 中不渲染控件（否则缩略图右上角会出现一套点不动的按钮）
    if (!empty($GLOBALS['__preview'])) {
        return '';
    }
    $settings = array();
    if (function_exists('is_installed') && is_installed()) {
        $settings = get_data('settings', array());
    }
    $track = !isset($settings['track_enable']) || $settings['track_enable'];
    $html = theme_pref_bar();
    $html .= '<script>' . theme_fallback_js() . '</script>';
    $html .= '<script>window.PR_PREF=' . json_encode(array(
            'mode'     => theme_mode(),
            'panel'    => theme_panel(),
            'color'    => theme_color(),
            'lang'     => current_lang(),
            'track'    => $track ? 1 : 0,
            'page'     => isset($GLOBALS['__page']) ? $GLOBALS['__page'] : '',
            'endpoint' => app_url('track.php'),
        )) . ';</script>';
    $html .= '<script src="' . e(app_url('assets/pref.js')) . '" defer></script>';
    return $html;
}
