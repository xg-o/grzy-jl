<?php
/**
 * 模板管理：内置 + 自定义合并、停用/恢复、删除、导入导出
 *
 * 自定义模板以 .php 文件存放在 templates/ 目录（文件名前缀 custom_），
 * 元数据（名称 / 说明 / 类型 / 文件名）存在存储层的 tplmeta 键下，
 * 因此会随备份导出导入与存储方式迁移一起走。
 */

define('TPL_DATA_KEY', 'tplmeta');

/** 自定义模板文件前缀，避免与内置模板重名 */
define('TPL_CUSTOM_PREFIX', 'custom_');

/**
 * 元数据：array(custom => [...], hidden => [...])
 */
function tpl_meta()
{
    if (isset($GLOBALS['__tpl_meta']) && $GLOBALS['__tpl_meta'] !== null) {
        return $GLOBALS['__tpl_meta'];
    }
    $meta = array('custom' => array(), 'hidden' => array());
    if (function_exists('is_installed') && is_installed()) {
        $raw = get_data(TPL_DATA_KEY, array());
        if (isset($raw['custom']) && is_array($raw['custom'])) {
            $meta['custom'] = $raw['custom'];
        }
        if (isset($raw['hidden']) && is_array($raw['hidden'])) {
            $meta['hidden'] = $raw['hidden'];
        }
    }
    // 清理元数据存在但文件已丢失的条目
    foreach ($meta['custom'] as $k => $v) {
        if (!is_array($v) || empty($v['file']) || !is_file(TPL_DIR . '/' . basename($v['file']))) {
            unset($meta['custom'][$k]);
        }
    }
    $GLOBALS['__tpl_meta'] = $meta;
    return $meta;
}

function tpl_meta_save(array $meta)
{
    $GLOBALS['__tpl_meta'] = $meta;
    $GLOBALS['__tpl_list'] = null;
    save_data(TPL_DATA_KEY, $meta);
    return true;
}

/**
 * 内置模板（硬编码）
 * type: home / resume
 */
function tpl_builtin()
{
    return array(
        'home' => array(
            'home_modern'  => array('name' => '现代渐变', 'en' => 'Modern Gradient', 'desc' => '顶部渐变头图 + 卡片式区块，适合大多数场景'),
            'home_minimal' => array('name' => '极简白', 'en' => 'Minimal', 'desc' => '大量留白、衬线标题，内容导向'),
            'home_dark'    => array('name' => '暗色科技', 'en' => 'Dark Tech', 'desc' => '深色背景 + 霓虹点缀，偏技术范'),
            'home_card'    => array('name' => '双栏名片', 'en' => 'Two Column', 'desc' => '左侧个人信息栏 + 右侧内容区'),
        ),
        'resume' => array(
            'resume_classic'  => array('name' => '经典黑白', 'en' => 'Classic', 'desc' => 'A4 打印友好，最通用、HR 接受度最高'),
            'resume_timeline' => array('name' => '时间轴', 'en' => 'Timeline', 'desc' => '竖线时间轴，经历脉络清晰'),
            'resume_sidebar'  => array('name' => '侧栏商务', 'en' => 'Sidebar', 'desc' => '左侧深色侧栏，右侧主内容，A4 一页'),
        ),
    );
}

/**
 * 合并后的模板清单：$type 为 null 返回全部分组
 * 每项补充 source（builtin / custom）、key、type
 */
function template_list($type = null)
{
    if (isset($GLOBALS['__tpl_list']) && $GLOBALS['__tpl_list'] !== null) {
        $all = $GLOBALS['__tpl_list'];
    } else {
        $all = tpl_builtin();
        foreach ($all as $tp => $items) {
            foreach ($items as $k => $v) {
                $all[$tp][$k]['source'] = 'builtin';
                $all[$tp][$k]['key'] = $k;
                $all[$tp][$k]['type'] = $tp;
            }
        }
        $meta = tpl_meta();
        foreach ($meta['custom'] as $key => $v) {
            $tp = isset($v['type']) ? $v['type'] : 'home';
            if (!isset($all[$tp])) {
                $tp = 'home';
            }
            $all[$tp][$key] = array(
                'name'   => isset($v['name']) ? $v['name'] : $key,
                'en'     => isset($v['en']) ? $v['en'] : '',
                'desc'   => isset($v['desc']) ? $v['desc'] : '',
                'source' => 'custom',
                'key'    => $key,
                'type'   => $tp,
                'file'   => $v['file'],
                'time'   => isset($v['time']) ? $v['time'] : '',
            );
        }
        // 移除停用的内置模板
        foreach ($meta['hidden'] as $k => $on) {
            if (!$on) {
                continue;
            }
            $tp = tpl_builtin_type($k);
            if ($tp) {
                unset($all[$tp][$k]);
            }
        }
        $GLOBALS['__tpl_list'] = $all;
    }
    if ($type === null) {
        return $all;
    }
    return isset($all[$type]) ? $all[$type] : array();
}

function tpl_builtin_type($key)
{
    foreach (tpl_builtin() as $tp => $items) {
        if (isset($items[$key])) {
            return $tp;
        }
    }
    return null;
}

/**
 * 已停用的内置模板
 */
function tpl_hidden_list()
{
    $meta = tpl_meta();
    $builtin = tpl_builtin();
    $out = array();
    foreach ($meta['hidden'] as $k => $on) {
        if (!$on) {
            continue;
        }
        $tp = tpl_builtin_type($k);
        if (!$tp) {
            continue;
        }
        $p = $builtin[$tp][$k];
        $p['source'] = 'builtin';
        $p['key'] = $k;
        $p['type'] = $tp;
        $out[$k] = $p;
    }
    return $out;
}

/**
 * 模板文件路径（内置：templates/<key>.php；自定义：元数据中的文件名）
 */
function template_path($tpl)
{
    $all = template_list();
    $found = null;
    $file = null;
    foreach ($all as $group) {
        if (isset($group[$tpl])) {
            $found = $group[$tpl];
            break;
        }
    }
    if ($found === null) {
        return null;
    }
    if ($found['source'] === 'custom' && !empty($found['file'])) {
        $file = TPL_DIR . '/' . basename($found['file']);
    } else {
        $file = TPL_DIR . '/' . basename($tpl) . '.php';
    }
    // 防目录穿越
    if (strpos(realpath_dir($file), realpath_dir(TPL_DIR)) !== 0) {
        return null;
    }
    return is_file($file) ? $file : null;
}

function realpath_dir($path)
{
    $real = realpath($path);
    if ($real !== false) {
        return $real;
    }
    return str_replace('\\', '/', dirname($path));
}

function valid_template($tpl, $type)
{
    $list = template_list($type);
    if (isset($list[$tpl])) {
        return $tpl;
    }
    $keys = array_keys($list);
    return empty($keys) ? '' : $keys[0];
}

/* ============================================================
   增删改
   ========================================================== */

function tpl_normalize_key($key)
{
    $key = strtolower(trim((string)$key));
    $key = preg_replace('/[^a-z0-9_]+/', '_', $key);
    $key = trim($key, '_');
    if ($key === '') {
        return '';
    }
    return substr($key, 0, 32);
}

function tpl_unique_key($key)
{
    $builtin = tpl_builtin();
    $meta = tpl_meta();
    $base = $key;
    $i = 2;
    while (isset($builtin['home'][$key]) || isset($builtin['resume'][$key]) || isset($meta['custom'][$key])) {
        $key = $base . '_' . $i;
        $i++;
    }
    return $key;
}

/**
 * 保存自定义模板（写文件 + 元数据）
 * $source 为完整 PHP 源码
 */
function tpl_put($key, $name, $desc, $type, $source, $en = '')
{
    if (!is_dir(TPL_DIR)) {
        @mkdir(TPL_DIR, 0755, true);
    }
    if (!is_writable(TPL_DIR)) {
        return array(false, 'templates 目录不可写，请检查权限');
    }
    $key = tpl_normalize_key($key);
    if ($key === '') {
        return array(false, '标识无效');
    }
    $name = trim((string)$name);
    if ($name === '') {
        $name = $key;
    }
    $type = ($type === 'resume') ? 'resume' : 'home';
    $source = (string)$source;
    if (trim($source) === '') {
        return array(false, '模板源码为空');
    }
    if (strpos($source, '<?php') !== 0 && strpos($source, '<?') !== 0) {
        $source = "<?php\n" . $source;
    }
    // 语法检查（不执行）
    $tmp = tempnam(sys_get_temp_dir(), 'tpl') . '.php';
    file_put_contents($tmp, $source);
    $out = array();
    $ret = 0;
    if (function_exists('exec')) {
        @exec(escapeshellarg(PHP_BINARY ?: 'php') . ' -l ' . escapeshellarg($tmp) . ' 2>&1', $out, $ret);
    }
    @unlink($tmp);
    if ($ret !== 0 && !empty($out)) {
        return array(false, '模板源码存在语法错误：' . trim(strip_tags(implode(' ', $out))));
    }

    $meta = tpl_meta();
    $isNew = !isset($meta['custom'][$key]);
    $file = TPL_CUSTOM_PREFIX . $key . '.php';
    if (@file_put_contents(TPL_DIR . '/' . $file, $source) === false) {
        return array(false, '写入模板文件失败');
    }
    $meta['custom'][$key] = array(
        'name' => str_cut($name, 40),
        'en'   => str_cut($en !== '' ? $en : $name, 40),
        'desc' => str_cut($desc, 120),
        'type' => $type,
        'file' => $file,
        'time' => date('Y-m-d H:i:s'),
    );
    tpl_meta_save($meta);
    return array(true, $isNew ? 'added' : 'updated');
}

/**
 * 删除自定义模板 / 停用内置模板
 */
function tpl_delete($key)
{
    $all = template_list();
    $found = null;
    foreach ($all as $group) {
        if (isset($group[$key])) {
            $found = $group[$key];
            break;
        }
    }
    if ($found === null) {
        // 可能是已停用的内置模板
        $hidden = tpl_hidden_list();
        if (isset($hidden[$key])) {
            return array(false, '该内置模板已处于停用状态');
        }
        return array(false, '模板不存在');
    }
    $meta = tpl_meta();
    if ($found['source'] === 'builtin') {
        $meta['hidden'][$key] = 1;
        tpl_meta_save($meta);
        return array(true, 'hidden');
    }
    $file = isset($meta['custom'][$key]['file']) ? $meta['custom'][$key]['file'] : '';
    if ($file) {
        @unlink(TPL_DIR . '/' . basename($file));
    }
    unset($meta['custom'][$key]);
    tpl_meta_save($meta);
    return array(true, 'deleted');
}

function tpl_restore($key)
{
    $meta = tpl_meta();
    if (empty($meta['hidden'][$key])) {
        return array(false, '该模板未被停用');
    }
    unset($meta['hidden'][$key]);
    tpl_meta_save($meta);
    return array(true, 'restored');
}

/* ============================================================
   导入导出
   ========================================================== */

/**
 * 导出：all / custom / 指定 key
 * 源码以字符串内嵌在 JSON 中，无需 zip 扩展
 */
function tpl_export_payload($scope = 'custom')
{
    $src = array();
    if ($scope === 'all') {
        foreach (template_list() as $group) {
            foreach ($group as $k => $v) {
                $src[$k] = $v;
            }
        }
    } elseif ($scope === 'custom') {
        foreach (template_list() as $group) {
            foreach ($group as $k => $v) {
                if ($v['source'] === 'custom') {
                    $src[$k] = $v;
                }
            }
        }
    } else {
        foreach (template_list() as $group) {
            if (isset($group[$scope])) {
                $src[$scope] = $group[$scope];
            }
        }
    }
    $items = array();
    foreach ($src as $k => $v) {
        $file = template_path($k);
        $items[] = array(
            'key'    => $k,
            'name'   => $v['name'],
            'en'     => isset($v['en']) ? $v['en'] : '',
            'desc'   => $v['desc'],
            'type'   => $v['type'],
            'source' => $file ? (string)file_get_contents($file) : '',
        );
    }
    return array(
        'app'        => 'php-resume-template',
        'version'    => defined('APP_VERSION') ? APP_VERSION : '1.0.0',
        'time'       => date('Y-m-d H:i:s'),
        'templates'  => $items,
    );
}

/**
 * 导入：支持 JSON（含源码）或单个 .php 源码文本
 * 返回 array(added, updated, renamed, skipped, errors)
 */
function tpl_import_payload($raw, $mode = 'rename', array $defaults = array())
{
    $items = array();
    if (is_array($raw)) {
        $data = $raw;
    } else {
        $raw = trim((string)$raw);
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $data = $decoded;
        } else {
            // 当作单个 PHP 模板源码
            if ($raw === '') {
                return array(0, 0, 0, 0, array('内容为空'));
            }
            $data = array('templates' => array(array(
                'key'    => isset($defaults['key']) ? $defaults['key'] : '',
                'name'   => isset($defaults['name']) ? $defaults['name'] : '',
                'desc'   => isset($defaults['desc']) ? $defaults['desc'] : '',
                'type'   => isset($defaults['type']) ? $defaults['type'] : 'home',
                'source' => $raw,
            )));
        }
    }

    if (isset($data['templates']) && is_array($data['templates'])) {
        $list = $data['templates'];
        // 兼容 {"templates":{"key":{...}}}
        if (!isset($list[0]) && $list) {
            $tmp = array();
            foreach ($list as $k => $v) {
                if (is_array($v)) {
                    $v['key'] = isset($v['key']) ? $v['key'] : $k;
                    $tmp[] = $v;
                }
            }
            $list = $tmp;
        }
    } elseif (isset($data['key']) || isset($data['source'])) {
        $list = array($data);
    } else {
        $list = is_array($data) ? $data : array();
    }

    $meta = tpl_meta();
    $builtin = tpl_builtin();
    $added = $updated = $renamed = $skipped = 0;
    $errors = array();

    foreach ($list as $i => $item) {
        if (!is_array($item)) {
            $errors[] = '第 ' . ($i + 1) . ' 项不是对象';
            continue;
        }
        $source = (string)($item['source'] ?? ($item['code'] ?? ''));
        if (trim($source) === '') {
            $errors[] = '第 ' . ($i + 1) . ' 项：缺少模板源码';
            continue;
        }
        $name = trim((string)($item['name'] ?? ''));
        $desc = trim((string)($item['desc'] ?? ''));
        $type = (($item['type'] ?? 'home') === 'resume') ? 'resume' : 'home';
        $en = trim((string)($item['en'] ?? ''));
        $key = tpl_normalize_key((string)($item['key'] ?? ''));
        if ($key === '') {
            $key = tpl_normalize_key($en !== '' ? $en : $name);
        }
        if ($key === '') {
            $key = 'tpl_' . substr(md5($source), 0, 8);
        }

        $isBuiltin = isset($builtin['home'][$key]) || isset($builtin['resume'][$key]);
        $exists = isset($meta['custom'][$key]);

        if ($isBuiltin && $mode !== 'overwrite') {
            if ($mode === 'skip') {
                $skipped++;
                continue;
            }
            $key = tpl_unique_key($key);
            $renamed++;
        } elseif ($exists && $mode === 'skip') {
            $skipped++;
            continue;
        } elseif ($exists && $mode === 'rename') {
            $key = tpl_unique_key($key);
            $renamed++;
        }

        list($ok, $msg) = tpl_put($key, $name !== '' ? $name : $key, $desc, $type, $source, $en);
        if (!$ok) {
            $errors[] = '第 ' . ($i + 1) . ' 项：' . $msg;
            continue;
        }
        if ($msg === 'updated') {
            $updated++;
        } else {
            $added++;
        }
    }
    return array($added, $updated, $renamed, $skipped, $errors);
}
