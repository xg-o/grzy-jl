<?php
/**
 * 内联 SVG 图标库（零外部依赖）
 * icon('name', ['class'=>'x','size'=>16])
 */

function icon($name, $opts = array())
{
    static $paths = null;
    if ($paths === null) {
        $paths = array(
            /* 偏好控件 */
            'sun'     => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
            'moon'    => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
            'auto'    => '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8"/><path d="M12 8.5v4.5l3 1.8"/>',
            'palette' => '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.8-.8 1.8-1.7 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.8 1.8-1.8H16a5 5 0 0 0 5-5c0-3.3-4-5-9-5z"/><circle cx="7.5" cy="11" r="1.1"/><circle cx="11" cy="7" r="1.1"/><circle cx="15.5" cy="8.5" r="1.1"/>',
            'globe'   => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18z"/>',
            'check'   => '<path d="M20 6L9 17l-5-5"/>',
            'close'   => '<path d="M18 6L6 18M6 6l12 12"/>',
            'add'     => '<path d="M12 5v14M5 12h14"/>',
            'search'  => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
            'edit'    => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
            'upload'  => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 9l5-5 5 5"/><path d="M12 4v12"/>',
            'refresh' => '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>',
            'eye'     => '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/>',

            /* 联系方式 */
            'phone'   => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
            'mail'    => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 6 10-6"/>',
            'pin'     => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="2.6"/>',
            'link'    => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
            'cake'    => '<path d="M4 21h16"/><path d="M3 18h18v-6H3z"/><path d="M12 12V8"/><circle cx="12" cy="6.5" r="1"/><path d="M7 12V8"/><circle cx="7" cy="6.5" r="1"/><path d="M17 12V8"/><circle cx="17" cy="6.5" r="1"/>',

            /* 社交 */
            'github'  => '<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.9a3.4 3.4 0 0 0-1-2.6c3-.3 6-1.5 6-6.5a5 5 0 0 0-1.4-3.5 4.6 4.6 0 0 0-.1-3.5s-1.4-.4-4.5 1.7a12 12 0 0 0-6 0C5.9.4 4.5.8 4.5.8a4.6 4.6 0 0 0-.1 3.5A5 5 0 0 0 3 7.8c0 5 3 6.2 6 6.5a3.4 3.4 0 0 0-1 2.6V22"/>',
            'linkedin'=> '<rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/><rect x="9" y="9" width="4" height="12"/><path d="M15 21v-6a3 3 0 0 1 6 0v6"/><path d="M15 12v9"/>',
            'weibo'   => '<circle cx="10" cy="16" r="5"/><path d="M16 5.5A5.5 5.5 0 0 1 21 11"/><path d="M15.5 8.5a2.5 2.5 0 0 1 2.5 2.5"/><path d="M3 20a5 5 0 0 1 3-6"/>',
            'wechat'  => '<path d="M8.5 4C5 4 2.5 6.2 2.5 9c0 1.6.8 3 2.2 4L4 15l2.2-1.2c.7.2 1.5.3 2.3.3"/><path d="M15.5 9.5c0-2.6-2.2-4.7-5-4.7"/><path d="M21.5 15c0-2.5-2.3-4.5-5.2-4.5-2.8 0-5.2 2-5.2 4.5 0 2.5 2.4 4.5 5.2 4.5.7 0 1.4-.1 2-.4l2 1-.5-1.7c1-.8 1.7-2 1.7-3.4z"/>',
            'qq'      => '<path d="M4 13c0-4 3.6-7 8-7s8 3 8 7"/><path d="M12 6.5C9 4 5 4.5 4 8c-.6 2 .5 4.6 3 5.5 1.6.6 3 1.6 3.6 2.5"/><path d="M12 6.5c3-2.5 7-2 8 1.5.6 2-.5 4.6-3 5.5-1.6.6-3 1.6-3.6 2.5"/><path d="M9.5 19.5l1.2 2 2.5-1.2"/>',

            /* 内容区块 */
            'briefcase' => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M2 13h20"/>',
            'folder'    => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
            'star'      => '<path d="M12 2.5l2.9 5.9 6.6.9-4.8 4.6 1.2 6.5L12 17.3 6.1 20.4l1.2-6.5L2.5 9.3l6.6-.9z"/>',
            'award'     => '<circle cx="12" cy="9" r="6"/><path d="M8.2 14.3L7 22l5-3 5 3-1.2-7.7"/>',
            'school'    => '<path d="M22 9L12 4 2 9l10 5 10-5z"/><path d="M6 11.5V17c0 1.5 3 3 6 3s6-1.5 6-3v-5.5"/>',
            'image'     => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
            'user'      => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
            'target'    => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4"/>',
            'print'     => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>',
            'arrow-left'=> '<path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/>',

            /* 设备 / 网络 / 电量 */
            'monitor'   => '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
            'smartphone'=> '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M11 18h2"/>',
            'wifi'      => '<path d="M5 12.5a10 10 0 0 1 14 0"/><path d="M8.5 16a5.5 5.5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/>',
            'battery'   => '<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 11v2"/><path d="M5 10v4"/>',
            'gauge'     => '<path d="M12 14l4-4"/><path d="M3.5 18a10 10 0 1 1 17 0"/>',
            'chart'     => '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>',
            'clock'     => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
            'globe2'    => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18z"/>',
            'shield'    => '<path d="M12 2l8 3.5v6c0 5-3.4 9.2-8 10.5-4.6-1.3-8-5.5-8-10.5v-6z"/>',
            'database'  => '<ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
            'sliders'   => '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3"/><path d="M1 14h6M9 8h6M17 16h6"/>',
            'layout'    => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
            'download'  => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
            'trash'     => '<path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
            'key'       => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3L20 3l1.5 1.5L13 14.5"/>',
        );
    }
    if (!isset($paths[$name])) {
        $name = 'user';
    }
    $size = isset($opts['size']) ? (int)$opts['size'] : 16;
    $cls = 'ico' . (isset($opts['class']) ? ' ' . $opts['class'] : '');
    $style = isset($opts['style']) ? ' style="' . e($opts['style']) . '"' : '';
    return '<svg class="' . e($cls) . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24"'
        . ' fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"'
        . $style . ' aria-hidden="true">' . $paths[$name] . '</svg>';
}

/**
 * 根据 UA 猜测设备类型，返回图标名
 */
function device_icon($ua)
{
    $ua = strtolower((string)$ua);
    if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false) {
        return 'monitor';
    }
    if (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) {
        return 'smartphone';
    }
    return 'monitor';
}
