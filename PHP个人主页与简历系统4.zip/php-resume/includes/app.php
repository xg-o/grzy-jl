<?php
/**
 * 应用引导：常量 / 配置读写 / 存储工厂 / 会话
 */

define('APP_ROOT', dirname(__DIR__));
define('CONFIG_DIR', APP_ROOT . '/config');
define('CONFIG_FILE', CONFIG_DIR . '/config.php');
define('DATA_DIR', APP_ROOT . '/data');
define('UPLOAD_DIR', DATA_DIR . '/uploads');
define('TPL_DIR', APP_ROOT . '/templates');
define('LOCK_FILE', DATA_DIR . '/installed.lock');
define('APP_VERSION', '1.0.0');

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    session_start();
}

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/theme.php';
require_once __DIR__ . '/tracking.php';
require_once __DIR__ . '/platform.php';
require_once __DIR__ . '/tplmgr.php';

/**
 * 读取配置（带静态缓存）
 */
function load_config()
{
    if (!isset($GLOBALS['__cfg'])) {
        if (is_file(CONFIG_FILE)) {
            $data = include CONFIG_FILE;
            $GLOBALS['__cfg'] = is_array($data) ? $data : array();
        } else {
            $GLOBALS['__cfg'] = array();
        }
    }
    return $GLOBALS['__cfg'];
}

/**
 * 重置配置缓存（保存配置后调用，确保读到最新内容）
 */
function config_reset()
{
    unset($GLOBALS['__cfg']);
}

/**
 * 保存配置（原子写入）
 */
function save_config(array $cfg)
{
    if (!is_dir(CONFIG_DIR)) {
        @mkdir(CONFIG_DIR, 0755, true);
    }
    $content = "<?php\n/**\n * 系统配置文件（由安装程序自动生成）\n * 生成时间：" . date('Y-m-d H:i:s') . "\n */\nreturn " . var_export($cfg, true) . ";\n";
    $tmp = CONFIG_FILE . '.tmp';
    if (file_put_contents($tmp, $content, LOCK_EX) === false) {
        return false;
    }
    rename($tmp, CONFIG_FILE);
    // 同步内存缓存，避免后续代码仍用旧配置
    $GLOBALS['__cfg'] = $cfg;
    unset($GLOBALS['__store']);
    return true;
}

/**
 * 更新配置中的某个片段
 */
function update_config(array $patch)
{
    $cfg = load_config();
    foreach ($patch as $k => $v) {
        $cfg[$k] = $v;
    }
    save_config($cfg);
}

function is_installed()
{
    return is_file(CONFIG_FILE) && is_file(LOCK_FILE);
}

/**
 * 获取存储实例
 */
function storage()
{
    if (!isset($GLOBALS['__store'])) {
        $cfg = load_config();
        $GLOBALS['__store'] = StorageFactory::create($cfg);
    }
    return $GLOBALS['__store'];
}

/**
 * 重置存储实例（切换存储方式后需要调用）
 */
function storage_reset()
{
    unset($GLOBALS['__store']);
}

/**
 * 读取业务数据（profile / settings）
 */
function get_data($key, $default = array())
{
    $data = storage()->get($key, null);
    if (!is_array($data)) {
        $data = $default;
    }
    if ($key === 'profile') {
        $data = array_merge(default_profile(), $data);
    } elseif ($key === 'settings') {
        $data = array_merge(default_settings(), $data);
    }
    return $data;
}

function save_data($key, array $value)
{
    return storage()->set($key, $value);
}

/**
 * 站点根目录 URL（兼容子目录部署）
 */
function app_root_url()
{
    $script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/index.php';
    $dir = str_replace('\\', '/', dirname($script));
    if (basename($dir) === 'admin') {
        $dir = dirname($dir);
    }
    $dir = ($dir === '/' || $dir === '.' || $dir === '\\') ? '' : $dir;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    return $scheme . '://' . $host . $dir;
}

function app_url($path = '')
{
    return app_root_url() . ($path === '' ? '' : '/' . ltrim($path, '/'));
}
